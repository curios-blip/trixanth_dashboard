// Overwritten at runtime by the dashboard web_server when it is given a rover_host.
// Leave empty to use the host the page was served from (or VITE_ROVER_HOST).
window.__TRIXANTH_HOST__ = ''
