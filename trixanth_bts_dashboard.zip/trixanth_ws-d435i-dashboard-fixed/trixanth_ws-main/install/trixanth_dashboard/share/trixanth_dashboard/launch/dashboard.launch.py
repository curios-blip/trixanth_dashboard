"""Ground-station dashboard: rosbridge + video server + launch manager + web page.

  ros2 launch trixanth_dashboard dashboard.launch.py
  ros2 launch trixanth_dashboard dashboard.launch.py rover_host:=192.168.10.2   # on the base laptop

Start this first. Missions are then started from the dashboard's Launches panel (the launch
manager passes rosbridge:=false to the mission launch files, so there is only one bridge).
If you start a mission from a terminal instead, add rosbridge:=false to it, or start this
with rosbridge:=false.
"""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, LogInfo, OpaqueFunction
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch_xml.launch_description_sources import XMLLaunchDescriptionSource


def _check_interfaces(_context):
    """rosbridge can only (de)serialise trixanth_interfaces messages if the package is sourced."""
    try:
        from ament_index_python.packages import get_package_prefix

        get_package_prefix("trixanth_interfaces")
        return []
    except Exception:
        return [LogInfo(msg=(
            "\n*** trixanth_interfaces is not built or not sourced in this terminal. ***\n"
            "The dashboard cannot read /mission/state, /perception/*, /recon/entry or call /set_mode without it.\n"
            "Fix:  colcon build --packages-select trixanth_interfaces && source install/setup.bash\n"
            "then start this launch again from the same terminal.\n"))]


def generate_launch_description():
    return LaunchDescription([
        OpaqueFunction(function=_check_interfaces),
        DeclareLaunchArgument("rosbridge", default_value="true", description="start rosbridge on :9090"),
        DeclareLaunchArgument("video", default_value="true", description="start web_video_server on :8080"),
        DeclareLaunchArgument("launch_manager", default_value="true", description="start the launch manager on :8000"),
        DeclareLaunchArgument("web", default_value="true", description="serve the dashboard page"),
        DeclareLaunchArgument("web_port", default_value="5173"),
        DeclareLaunchArgument("rover_host", default_value="",
                              description="rover address for a page served from another machine (empty = same host)"),

        IncludeLaunchDescription(
            XMLLaunchDescriptionSource(PathJoinSubstitution(
                [FindPackageShare("rosbridge_server"), "launch", "rosbridge_websocket_launch.xml"])),
            condition=IfCondition(LaunchConfiguration("rosbridge"))),
        Node(package="web_video_server", executable="web_video_server", name="web_video_server",
             parameters=[{"port": 8080}], condition=IfCondition(LaunchConfiguration("video"))),
        # Colour-mapped copy of the D435i depth image (web_video_server cannot stream raw 16UC1 depth).
        Node(package="trixanth_dashboard", executable="depth_preview", name="depth_preview", output="screen",
             condition=IfCondition(LaunchConfiguration("video"))),
        Node(package="trixanth_dashboard", executable="launch_manager", output="screen",
             arguments=["--port", "8000"], condition=IfCondition(LaunchConfiguration("launch_manager"))),
        Node(package="trixanth_dashboard", executable="web_server", output="screen",
             arguments=["--port", LaunchConfiguration("web_port"),
                        "--rover-host", LaunchConfiguration("rover_host")],
             condition=IfCondition(LaunchConfiguration("web"))),
    ])
