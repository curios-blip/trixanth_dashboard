// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from trixanth_interfaces:msg/MissionState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/mission_state.h"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__MISSION_STATE__STRUCT_H_
#define TRIXANTH_INTERFACES__MSG__DETAIL__MISSION_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'MODE_IDLE'.
enum
{
  trixanth_interfaces__msg__MissionState__MODE_IDLE = 0
};

/// Constant 'MODE_MANUAL'.
enum
{
  trixanth_interfaces__msg__MissionState__MODE_MANUAL = 1
};

/// Constant 'MODE_AUTONOMOUS'.
enum
{
  trixanth_interfaces__msg__MissionState__MODE_AUTONOMOUS = 2
};

/// Constant 'MODE_ESTOP'.
enum
{
  trixanth_interfaces__msg__MissionState__MODE_ESTOP = 3
};

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'mission'
// Member 'stage'
// Member 'alert'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/MissionState in the package trixanth_interfaces.
/**
  * Published by trixanth_mission/mission_monitor at 2 Hz and on every change.
 */
typedef struct trixanth_interfaces__msg__MissionState
{
  std_msgs__msg__Header header;
  uint8_t mode;
  /// "rado" | "abex" | "idmo" | ""
  rosidl_runtime_c__String mission;
  /// e.g. "recon", "delivery", or FSM state name
  rosidl_runtime_c__String stage;
  /// mission clock running
  bool running;
  /// seconds since mission start
  float elapsed_s;
  /// current allowed mission length (25 min, or 15 if the 30% gate failed)
  float limit_s;
  /// points logged so far (operator-entered, see ScoreEvent)
  float points;
  /// max points for this mission (from config; UNKNOWN until Table 1.2)
  float points_max;
  /// true after minute 15 if the 30% gate passed
  bool bonus_unlocked;
  /// human-readable warning for the dashboard, empty when none
  rosidl_runtime_c__String alert;
} trixanth_interfaces__msg__MissionState;

// Struct for a sequence of trixanth_interfaces__msg__MissionState.
typedef struct trixanth_interfaces__msg__MissionState__Sequence
{
  trixanth_interfaces__msg__MissionState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} trixanth_interfaces__msg__MissionState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__MISSION_STATE__STRUCT_H_
