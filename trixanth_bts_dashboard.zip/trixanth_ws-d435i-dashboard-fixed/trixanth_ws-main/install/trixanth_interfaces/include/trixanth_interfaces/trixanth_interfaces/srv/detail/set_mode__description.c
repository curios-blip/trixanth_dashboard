// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from trixanth_interfaces:srv/SetMode.idl
// generated code does not contain a copyright notice

#include "trixanth_interfaces/srv/detail/set_mode__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_trixanth_interfaces
const rosidl_type_hash_t *
trixanth_interfaces__srv__SetMode__get_type_hash(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xe7, 0x6c, 0x58, 0x3f, 0x1e, 0x28, 0x0a, 0x34,
      0xcb, 0xfc, 0xe9, 0xbc, 0x70, 0x89, 0x32, 0x11,
      0x45, 0x86, 0x9d, 0xc1, 0x11, 0x6a, 0x96, 0xcb,
      0x14, 0x25, 0xe6, 0x40, 0x43, 0x45, 0x44, 0x8e,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_trixanth_interfaces
const rosidl_type_hash_t *
trixanth_interfaces__srv__SetMode_Request__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x37, 0xfa, 0x93, 0x9c, 0x6e, 0x28, 0x5d, 0x3c,
      0x5d, 0x45, 0x04, 0x55, 0x47, 0xc5, 0x84, 0x98,
      0xcc, 0x0e, 0xa5, 0x12, 0xbd, 0x78, 0x0e, 0xc2,
      0xc5, 0xa9, 0x96, 0xb0, 0x84, 0x4c, 0x1f, 0xf3,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_trixanth_interfaces
const rosidl_type_hash_t *
trixanth_interfaces__srv__SetMode_Response__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x11, 0xb2, 0xed, 0x0c, 0x87, 0xd6, 0xde, 0x66,
      0x07, 0xea, 0x73, 0x6f, 0x28, 0xee, 0x23, 0xb6,
      0x22, 0x14, 0x12, 0x09, 0xe6, 0xf4, 0x7a, 0x6b,
      0x14, 0x99, 0x5b, 0x00, 0xbc, 0x3f, 0xba, 0xeb,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_trixanth_interfaces
const rosidl_type_hash_t *
trixanth_interfaces__srv__SetMode_Event__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xc8, 0x6f, 0xf9, 0xe5, 0x1f, 0x57, 0x28, 0x97,
      0x9e, 0xca, 0x0b, 0xce, 0x54, 0xb7, 0x15, 0x13,
      0x59, 0x6b, 0x18, 0xce, 0x46, 0x90, 0xea, 0x66,
      0x2c, 0x5a, 0xfb, 0x53, 0xaa, 0x46, 0x4a, 0xe9,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "service_msgs/msg/detail/service_event_info__functions.h"
#include "builtin_interfaces/msg/detail/time__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t service_msgs__msg__ServiceEventInfo__EXPECTED_HASH = {1, {
    0x41, 0xbc, 0xbb, 0xe0, 0x7a, 0x75, 0xc9, 0xb5,
    0x2b, 0xc9, 0x6b, 0xfd, 0x5c, 0x24, 0xd7, 0xf0,
    0xfc, 0x0a, 0x08, 0xc0, 0xcb, 0x79, 0x21, 0xb3,
    0x37, 0x3c, 0x57, 0x32, 0x34, 0x5a, 0x6f, 0x45,
  }};
#endif

static char trixanth_interfaces__srv__SetMode__TYPE_NAME[] = "trixanth_interfaces/srv/SetMode";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char service_msgs__msg__ServiceEventInfo__TYPE_NAME[] = "service_msgs/msg/ServiceEventInfo";
static char trixanth_interfaces__srv__SetMode_Event__TYPE_NAME[] = "trixanth_interfaces/srv/SetMode_Event";
static char trixanth_interfaces__srv__SetMode_Request__TYPE_NAME[] = "trixanth_interfaces/srv/SetMode_Request";
static char trixanth_interfaces__srv__SetMode_Response__TYPE_NAME[] = "trixanth_interfaces/srv/SetMode_Response";

// Define type names, field names, and default values
static char trixanth_interfaces__srv__SetMode__FIELD_NAME__request_message[] = "request_message";
static char trixanth_interfaces__srv__SetMode__FIELD_NAME__response_message[] = "response_message";
static char trixanth_interfaces__srv__SetMode__FIELD_NAME__event_message[] = "event_message";

static rosidl_runtime_c__type_description__Field trixanth_interfaces__srv__SetMode__FIELDS[] = {
  {
    {trixanth_interfaces__srv__SetMode__FIELD_NAME__request_message, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {trixanth_interfaces__srv__SetMode_Request__TYPE_NAME, 39, 39},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__srv__SetMode__FIELD_NAME__response_message, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {trixanth_interfaces__srv__SetMode_Response__TYPE_NAME, 40, 40},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__srv__SetMode__FIELD_NAME__event_message, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {trixanth_interfaces__srv__SetMode_Event__TYPE_NAME, 37, 37},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription trixanth_interfaces__srv__SetMode__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__srv__SetMode_Event__TYPE_NAME, 37, 37},
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__srv__SetMode_Request__TYPE_NAME, 39, 39},
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__srv__SetMode_Response__TYPE_NAME, 40, 40},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
trixanth_interfaces__srv__SetMode__get_type_description(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {trixanth_interfaces__srv__SetMode__TYPE_NAME, 31, 31},
      {trixanth_interfaces__srv__SetMode__FIELDS, 3, 3},
    },
    {trixanth_interfaces__srv__SetMode__REFERENCED_TYPE_DESCRIPTIONS, 5, 5},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&service_msgs__msg__ServiceEventInfo__EXPECTED_HASH, service_msgs__msg__ServiceEventInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = service_msgs__msg__ServiceEventInfo__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[2].fields = trixanth_interfaces__srv__SetMode_Event__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[3].fields = trixanth_interfaces__srv__SetMode_Request__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[4].fields = trixanth_interfaces__srv__SetMode_Response__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char trixanth_interfaces__srv__SetMode_Request__FIELD_NAME__mode[] = "mode";

static rosidl_runtime_c__type_description__Field trixanth_interfaces__srv__SetMode_Request__FIELDS[] = {
  {
    {trixanth_interfaces__srv__SetMode_Request__FIELD_NAME__mode, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
trixanth_interfaces__srv__SetMode_Request__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {trixanth_interfaces__srv__SetMode_Request__TYPE_NAME, 39, 39},
      {trixanth_interfaces__srv__SetMode_Request__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char trixanth_interfaces__srv__SetMode_Response__FIELD_NAME__success[] = "success";
static char trixanth_interfaces__srv__SetMode_Response__FIELD_NAME__message[] = "message";

static rosidl_runtime_c__type_description__Field trixanth_interfaces__srv__SetMode_Response__FIELDS[] = {
  {
    {trixanth_interfaces__srv__SetMode_Response__FIELD_NAME__success, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__srv__SetMode_Response__FIELD_NAME__message, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
trixanth_interfaces__srv__SetMode_Response__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {trixanth_interfaces__srv__SetMode_Response__TYPE_NAME, 40, 40},
      {trixanth_interfaces__srv__SetMode_Response__FIELDS, 2, 2},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char trixanth_interfaces__srv__SetMode_Event__FIELD_NAME__info[] = "info";
static char trixanth_interfaces__srv__SetMode_Event__FIELD_NAME__request[] = "request";
static char trixanth_interfaces__srv__SetMode_Event__FIELD_NAME__response[] = "response";

static rosidl_runtime_c__type_description__Field trixanth_interfaces__srv__SetMode_Event__FIELDS[] = {
  {
    {trixanth_interfaces__srv__SetMode_Event__FIELD_NAME__info, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__srv__SetMode_Event__FIELD_NAME__request, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_BOUNDED_SEQUENCE,
      1,
      0,
      {trixanth_interfaces__srv__SetMode_Request__TYPE_NAME, 39, 39},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__srv__SetMode_Event__FIELD_NAME__response, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_BOUNDED_SEQUENCE,
      1,
      0,
      {trixanth_interfaces__srv__SetMode_Response__TYPE_NAME, 40, 40},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription trixanth_interfaces__srv__SetMode_Event__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__srv__SetMode_Request__TYPE_NAME, 39, 39},
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__srv__SetMode_Response__TYPE_NAME, 40, 40},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
trixanth_interfaces__srv__SetMode_Event__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {trixanth_interfaces__srv__SetMode_Event__TYPE_NAME, 37, 37},
      {trixanth_interfaces__srv__SetMode_Event__FIELDS, 3, 3},
    },
    {trixanth_interfaces__srv__SetMode_Event__REFERENCED_TYPE_DESCRIPTIONS, 4, 4},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&service_msgs__msg__ServiceEventInfo__EXPECTED_HASH, service_msgs__msg__ServiceEventInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = service_msgs__msg__ServiceEventInfo__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[2].fields = trixanth_interfaces__srv__SetMode_Request__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[3].fields = trixanth_interfaces__srv__SetMode_Response__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "uint8 MODE_IDLE=0\n"
  "uint8 MODE_MANUAL=1\n"
  "uint8 MODE_AUTONOMOUS=2\n"
  "uint8 MODE_ESTOP=3\n"
  "uint8 mode\n"
  "---\n"
  "bool success\n"
  "string message";

static char srv_encoding[] = "srv";
static char implicit_encoding[] = "implicit";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
trixanth_interfaces__srv__SetMode__get_individual_type_description_source(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {trixanth_interfaces__srv__SetMode__TYPE_NAME, 31, 31},
    {srv_encoding, 3, 3},
    {toplevel_type_raw_source, 124, 124},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
trixanth_interfaces__srv__SetMode_Request__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {trixanth_interfaces__srv__SetMode_Request__TYPE_NAME, 39, 39},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
trixanth_interfaces__srv__SetMode_Response__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {trixanth_interfaces__srv__SetMode_Response__TYPE_NAME, 40, 40},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
trixanth_interfaces__srv__SetMode_Event__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {trixanth_interfaces__srv__SetMode_Event__TYPE_NAME, 37, 37},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
trixanth_interfaces__srv__SetMode__get_type_description_sources(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[6];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 6, 6};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *trixanth_interfaces__srv__SetMode__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *service_msgs__msg__ServiceEventInfo__get_individual_type_description_source(NULL);
    sources[3] = *trixanth_interfaces__srv__SetMode_Event__get_individual_type_description_source(NULL);
    sources[4] = *trixanth_interfaces__srv__SetMode_Request__get_individual_type_description_source(NULL);
    sources[5] = *trixanth_interfaces__srv__SetMode_Response__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
trixanth_interfaces__srv__SetMode_Request__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *trixanth_interfaces__srv__SetMode_Request__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
trixanth_interfaces__srv__SetMode_Response__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *trixanth_interfaces__srv__SetMode_Response__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
trixanth_interfaces__srv__SetMode_Event__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[5];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 5, 5};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *trixanth_interfaces__srv__SetMode_Event__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *service_msgs__msg__ServiceEventInfo__get_individual_type_description_source(NULL);
    sources[3] = *trixanth_interfaces__srv__SetMode_Request__get_individual_type_description_source(NULL);
    sources[4] = *trixanth_interfaces__srv__SetMode_Response__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
