// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from trixanth_interfaces:msg/ScoreEvent.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/score_event.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__SCORE_EVENT__STRUCT_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__SCORE_EVENT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__trixanth_interfaces__msg__ScoreEvent __attribute__((deprecated))
#else
# define DEPRECATED__trixanth_interfaces__msg__ScoreEvent __declspec(deprecated)
#endif

namespace trixanth_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ScoreEvent_
{
  using Type = ScoreEvent_<ContainerAllocator>;

  explicit ScoreEvent_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->task = "";
      this->points = 0.0f;
    }
  }

  explicit ScoreEvent_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    task(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->task = "";
      this->points = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _task_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _task_type task;
  using _points_type =
    float;
  _points_type points;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__task(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->task = _arg;
    return *this;
  }
  Type & set__points(
    const float & _arg)
  {
    this->points = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    trixanth_interfaces::msg::ScoreEvent_<ContainerAllocator> *;
  using ConstRawPtr =
    const trixanth_interfaces::msg::ScoreEvent_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<trixanth_interfaces::msg::ScoreEvent_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<trixanth_interfaces::msg::ScoreEvent_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      trixanth_interfaces::msg::ScoreEvent_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<trixanth_interfaces::msg::ScoreEvent_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      trixanth_interfaces::msg::ScoreEvent_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<trixanth_interfaces::msg::ScoreEvent_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<trixanth_interfaces::msg::ScoreEvent_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<trixanth_interfaces::msg::ScoreEvent_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__trixanth_interfaces__msg__ScoreEvent
    std::shared_ptr<trixanth_interfaces::msg::ScoreEvent_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__trixanth_interfaces__msg__ScoreEvent
    std::shared_ptr<trixanth_interfaces::msg::ScoreEvent_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ScoreEvent_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->task != other.task) {
      return false;
    }
    if (this->points != other.points) {
      return false;
    }
    return true;
  }
  bool operator!=(const ScoreEvent_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ScoreEvent_

// alias to use template instance with default allocator
using ScoreEvent =
  trixanth_interfaces::msg::ScoreEvent_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace trixanth_interfaces

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__SCORE_EVENT__STRUCT_HPP_
