// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from trixanth_interfaces:srv/StartMission.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/srv/start_mission.hpp"


#ifndef TRIXANTH_INTERFACES__SRV__DETAIL__START_MISSION__BUILDER_HPP_
#define TRIXANTH_INTERFACES__SRV__DETAIL__START_MISSION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "trixanth_interfaces/srv/detail/start_mission__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace trixanth_interfaces
{

namespace srv
{

namespace builder
{

class Init_StartMission_Request_points_max
{
public:
  explicit Init_StartMission_Request_points_max(::trixanth_interfaces::srv::StartMission_Request & msg)
  : msg_(msg)
  {}
  ::trixanth_interfaces::srv::StartMission_Request points_max(::trixanth_interfaces::srv::StartMission_Request::_points_max_type arg)
  {
    msg_.points_max = std::move(arg);
    return std::move(msg_);
  }

private:
  ::trixanth_interfaces::srv::StartMission_Request msg_;
};

class Init_StartMission_Request_mission
{
public:
  Init_StartMission_Request_mission()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_StartMission_Request_points_max mission(::trixanth_interfaces::srv::StartMission_Request::_mission_type arg)
  {
    msg_.mission = std::move(arg);
    return Init_StartMission_Request_points_max(msg_);
  }

private:
  ::trixanth_interfaces::srv::StartMission_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::trixanth_interfaces::srv::StartMission_Request>()
{
  return trixanth_interfaces::srv::builder::Init_StartMission_Request_mission();
}

}  // namespace trixanth_interfaces


namespace trixanth_interfaces
{

namespace srv
{

namespace builder
{

class Init_StartMission_Response_message
{
public:
  explicit Init_StartMission_Response_message(::trixanth_interfaces::srv::StartMission_Response & msg)
  : msg_(msg)
  {}
  ::trixanth_interfaces::srv::StartMission_Response message(::trixanth_interfaces::srv::StartMission_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::trixanth_interfaces::srv::StartMission_Response msg_;
};

class Init_StartMission_Response_success
{
public:
  Init_StartMission_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_StartMission_Response_message success(::trixanth_interfaces::srv::StartMission_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_StartMission_Response_message(msg_);
  }

private:
  ::trixanth_interfaces::srv::StartMission_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::trixanth_interfaces::srv::StartMission_Response>()
{
  return trixanth_interfaces::srv::builder::Init_StartMission_Response_success();
}

}  // namespace trixanth_interfaces


namespace trixanth_interfaces
{

namespace srv
{

namespace builder
{

class Init_StartMission_Event_response
{
public:
  explicit Init_StartMission_Event_response(::trixanth_interfaces::srv::StartMission_Event & msg)
  : msg_(msg)
  {}
  ::trixanth_interfaces::srv::StartMission_Event response(::trixanth_interfaces::srv::StartMission_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::trixanth_interfaces::srv::StartMission_Event msg_;
};

class Init_StartMission_Event_request
{
public:
  explicit Init_StartMission_Event_request(::trixanth_interfaces::srv::StartMission_Event & msg)
  : msg_(msg)
  {}
  Init_StartMission_Event_response request(::trixanth_interfaces::srv::StartMission_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_StartMission_Event_response(msg_);
  }

private:
  ::trixanth_interfaces::srv::StartMission_Event msg_;
};

class Init_StartMission_Event_info
{
public:
  Init_StartMission_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_StartMission_Event_request info(::trixanth_interfaces::srv::StartMission_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_StartMission_Event_request(msg_);
  }

private:
  ::trixanth_interfaces::srv::StartMission_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::trixanth_interfaces::srv::StartMission_Event>()
{
  return trixanth_interfaces::srv::builder::Init_StartMission_Event_info();
}

}  // namespace trixanth_interfaces

#endif  // TRIXANTH_INTERFACES__SRV__DETAIL__START_MISSION__BUILDER_HPP_
