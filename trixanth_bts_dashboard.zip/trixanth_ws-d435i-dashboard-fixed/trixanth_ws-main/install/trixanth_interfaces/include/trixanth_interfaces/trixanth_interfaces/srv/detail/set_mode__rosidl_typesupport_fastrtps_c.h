// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from trixanth_interfaces:srv/SetMode.idl
// generated code does not contain a copyright notice
#ifndef TRIXANTH_INTERFACES__SRV__DETAIL__SET_MODE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define TRIXANTH_INTERFACES__SRV__DETAIL__SET_MODE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "trixanth_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "trixanth_interfaces/srv/detail/set_mode__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
bool cdr_serialize_trixanth_interfaces__srv__SetMode_Request(
  const trixanth_interfaces__srv__SetMode_Request * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
bool cdr_deserialize_trixanth_interfaces__srv__SetMode_Request(
  eprosima::fastcdr::Cdr &,
  trixanth_interfaces__srv__SetMode_Request * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t get_serialized_size_trixanth_interfaces__srv__SetMode_Request(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t max_serialized_size_trixanth_interfaces__srv__SetMode_Request(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
bool cdr_serialize_key_trixanth_interfaces__srv__SetMode_Request(
  const trixanth_interfaces__srv__SetMode_Request * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t get_serialized_size_key_trixanth_interfaces__srv__SetMode_Request(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t max_serialized_size_key_trixanth_interfaces__srv__SetMode_Request(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, trixanth_interfaces, srv, SetMode_Request)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "trixanth_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "trixanth_interfaces/srv/detail/set_mode__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
bool cdr_serialize_trixanth_interfaces__srv__SetMode_Response(
  const trixanth_interfaces__srv__SetMode_Response * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
bool cdr_deserialize_trixanth_interfaces__srv__SetMode_Response(
  eprosima::fastcdr::Cdr &,
  trixanth_interfaces__srv__SetMode_Response * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t get_serialized_size_trixanth_interfaces__srv__SetMode_Response(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t max_serialized_size_trixanth_interfaces__srv__SetMode_Response(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
bool cdr_serialize_key_trixanth_interfaces__srv__SetMode_Response(
  const trixanth_interfaces__srv__SetMode_Response * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t get_serialized_size_key_trixanth_interfaces__srv__SetMode_Response(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t max_serialized_size_key_trixanth_interfaces__srv__SetMode_Response(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, trixanth_interfaces, srv, SetMode_Response)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "trixanth_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "trixanth_interfaces/srv/detail/set_mode__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
bool cdr_serialize_trixanth_interfaces__srv__SetMode_Event(
  const trixanth_interfaces__srv__SetMode_Event * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
bool cdr_deserialize_trixanth_interfaces__srv__SetMode_Event(
  eprosima::fastcdr::Cdr &,
  trixanth_interfaces__srv__SetMode_Event * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t get_serialized_size_trixanth_interfaces__srv__SetMode_Event(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t max_serialized_size_trixanth_interfaces__srv__SetMode_Event(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
bool cdr_serialize_key_trixanth_interfaces__srv__SetMode_Event(
  const trixanth_interfaces__srv__SetMode_Event * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t get_serialized_size_key_trixanth_interfaces__srv__SetMode_Event(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t max_serialized_size_key_trixanth_interfaces__srv__SetMode_Event(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, trixanth_interfaces, srv, SetMode_Event)();

#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "trixanth_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, trixanth_interfaces, srv, SetMode)();

#ifdef __cplusplus
}
#endif

#endif  // TRIXANTH_INTERFACES__SRV__DETAIL__SET_MODE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
