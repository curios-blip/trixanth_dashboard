// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from trixanth_interfaces:msg/MarkerObservation.idl
// generated code does not contain a copyright notice

#include "trixanth_interfaces/msg/detail/marker_observation__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_trixanth_interfaces
const rosidl_type_hash_t *
trixanth_interfaces__msg__MarkerObservation__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x3a, 0x33, 0x67, 0xf5, 0xf9, 0xa8, 0x70, 0xbf,
      0x03, 0x3d, 0xf4, 0x48, 0x2d, 0x03, 0x8e, 0x74,
      0x65, 0x81, 0xc9, 0xa1, 0x91, 0xf4, 0x8e, 0x07,
      0x1b, 0x44, 0x59, 0xd1, 0x34, 0x72, 0x09, 0x7c,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "std_msgs/msg/detail/header__functions.h"
#include "builtin_interfaces/msg/detail/time__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t std_msgs__msg__Header__EXPECTED_HASH = {1, {
    0xf4, 0x9f, 0xb3, 0xae, 0x2c, 0xf0, 0x70, 0xf7,
    0x93, 0x64, 0x5f, 0xf7, 0x49, 0x68, 0x3a, 0xc6,
    0xb0, 0x62, 0x03, 0xe4, 0x1c, 0x89, 0x1e, 0x17,
    0x70, 0x1b, 0x1c, 0xb5, 0x97, 0xce, 0x6a, 0x01,
  }};
#endif

static char trixanth_interfaces__msg__MarkerObservation__TYPE_NAME[] = "trixanth_interfaces/msg/MarkerObservation";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char std_msgs__msg__Header__TYPE_NAME[] = "std_msgs/msg/Header";

// Define type names, field names, and default values
static char trixanth_interfaces__msg__MarkerObservation__FIELD_NAME__header[] = "header";
static char trixanth_interfaces__msg__MarkerObservation__FIELD_NAME__colour[] = "colour";
static char trixanth_interfaces__msg__MarkerObservation__FIELD_NAME__visible[] = "visible";
static char trixanth_interfaces__msg__MarkerObservation__FIELD_NAME__bearing_rad[] = "bearing_rad";
static char trixanth_interfaces__msg__MarkerObservation__FIELD_NAME__area_ratio[] = "area_ratio";
static char trixanth_interfaces__msg__MarkerObservation__FIELD_NAME__range_m[] = "range_m";

static rosidl_runtime_c__type_description__Field trixanth_interfaces__msg__MarkerObservation__FIELDS[] = {
  {
    {trixanth_interfaces__msg__MarkerObservation__FIELD_NAME__header, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MarkerObservation__FIELD_NAME__colour, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MarkerObservation__FIELD_NAME__visible, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MarkerObservation__FIELD_NAME__bearing_rad, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MarkerObservation__FIELD_NAME__area_ratio, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MarkerObservation__FIELD_NAME__range_m, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription trixanth_interfaces__msg__MarkerObservation__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
trixanth_interfaces__msg__MarkerObservation__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {trixanth_interfaces__msg__MarkerObservation__TYPE_NAME, 41, 41},
      {trixanth_interfaces__msg__MarkerObservation__FIELDS, 6, 6},
    },
    {trixanth_interfaces__msg__MarkerObservation__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&std_msgs__msg__Header__EXPECTED_HASH, std_msgs__msg__Header__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = std_msgs__msg__Header__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# A coloured delivery marker seen by the front camera.\n"
  "std_msgs/Header header\n"
  "string colour\n"
  "bool visible\n"
  "float32 bearing_rad     # + is left of the image centre (REP 103)\n"
  "float32 area_ratio      # blob area / image area, a rough proximity cue\n"
  "float32 range_m         # from depth if available, else NaN";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
trixanth_interfaces__msg__MarkerObservation__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {trixanth_interfaces__msg__MarkerObservation__TYPE_NAME, 41, 41},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 303, 303},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
trixanth_interfaces__msg__MarkerObservation__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *trixanth_interfaces__msg__MarkerObservation__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *std_msgs__msg__Header__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
