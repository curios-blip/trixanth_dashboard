// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from trixanth_interfaces:msg/ReconEntry.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/recon_entry.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__TRAITS_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "trixanth_interfaces/msg/detail/recon_entry__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace trixanth_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const ReconEntry & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: id
  {
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << ", ";
  }

  // member: label
  {
    out << "label: ";
    rosidl_generator_traits::value_to_yaml(msg.label, out);
    out << ", ";
  }

  // member: confidence
  {
    out << "confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.confidence, out);
    out << ", ";
  }

  // member: latitude
  {
    out << "latitude: ";
    rosidl_generator_traits::value_to_yaml(msg.latitude, out);
    out << ", ";
  }

  // member: longitude
  {
    out << "longitude: ";
    rosidl_generator_traits::value_to_yaml(msg.longitude, out);
    out << ", ";
  }

  // member: altitude
  {
    out << "altitude: ";
    rosidl_generator_traits::value_to_yaml(msg.altitude, out);
    out << ", ";
  }

  // member: horizontal_accuracy_m
  {
    out << "horizontal_accuracy_m: ";
    rosidl_generator_traits::value_to_yaml(msg.horizontal_accuracy_m, out);
    out << ", ";
  }

  // member: image_path
  {
    out << "image_path: ";
    rosidl_generator_traits::value_to_yaml(msg.image_path, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ReconEntry & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << "\n";
  }

  // member: label
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "label: ";
    rosidl_generator_traits::value_to_yaml(msg.label, out);
    out << "\n";
  }

  // member: confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.confidence, out);
    out << "\n";
  }

  // member: latitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "latitude: ";
    rosidl_generator_traits::value_to_yaml(msg.latitude, out);
    out << "\n";
  }

  // member: longitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "longitude: ";
    rosidl_generator_traits::value_to_yaml(msg.longitude, out);
    out << "\n";
  }

  // member: altitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "altitude: ";
    rosidl_generator_traits::value_to_yaml(msg.altitude, out);
    out << "\n";
  }

  // member: horizontal_accuracy_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "horizontal_accuracy_m: ";
    rosidl_generator_traits::value_to_yaml(msg.horizontal_accuracy_m, out);
    out << "\n";
  }

  // member: image_path
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "image_path: ";
    rosidl_generator_traits::value_to_yaml(msg.image_path, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ReconEntry & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace trixanth_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use trixanth_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const trixanth_interfaces::msg::ReconEntry & msg,
  std::ostream & out, size_t indentation = 0)
{
  trixanth_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use trixanth_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const trixanth_interfaces::msg::ReconEntry & msg)
{
  return trixanth_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<trixanth_interfaces::msg::ReconEntry>()
{
  return "trixanth_interfaces::msg::ReconEntry";
}

template<>
inline const char * name<trixanth_interfaces::msg::ReconEntry>()
{
  return "trixanth_interfaces/msg/ReconEntry";
}

template<>
struct has_fixed_size<trixanth_interfaces::msg::ReconEntry>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<trixanth_interfaces::msg::ReconEntry>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<trixanth_interfaces::msg::ReconEntry>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__TRAITS_HPP_
