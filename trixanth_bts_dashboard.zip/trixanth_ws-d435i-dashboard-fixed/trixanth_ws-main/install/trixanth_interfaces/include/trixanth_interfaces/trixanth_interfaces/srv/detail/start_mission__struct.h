// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from trixanth_interfaces:srv/StartMission.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/srv/start_mission.h"


#ifndef TRIXANTH_INTERFACES__SRV__DETAIL__START_MISSION__STRUCT_H_
#define TRIXANTH_INTERFACES__SRV__DETAIL__START_MISSION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'mission'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/StartMission in the package trixanth_interfaces.
typedef struct trixanth_interfaces__srv__StartMission_Request
{
  /// "rado" | "abex" | "idmo"
  rosidl_runtime_c__String mission;
  /// leave 0 if unknown
  float points_max;
} trixanth_interfaces__srv__StartMission_Request;

// Struct for a sequence of trixanth_interfaces__srv__StartMission_Request.
typedef struct trixanth_interfaces__srv__StartMission_Request__Sequence
{
  trixanth_interfaces__srv__StartMission_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} trixanth_interfaces__srv__StartMission_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'message'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in srv/StartMission in the package trixanth_interfaces.
typedef struct trixanth_interfaces__srv__StartMission_Response
{
  bool success;
  rosidl_runtime_c__String message;
} trixanth_interfaces__srv__StartMission_Response;

// Struct for a sequence of trixanth_interfaces__srv__StartMission_Response.
typedef struct trixanth_interfaces__srv__StartMission_Response__Sequence
{
  trixanth_interfaces__srv__StartMission_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} trixanth_interfaces__srv__StartMission_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  trixanth_interfaces__srv__StartMission_Event__request__MAX_SIZE = 1
};
// response
enum
{
  trixanth_interfaces__srv__StartMission_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/StartMission in the package trixanth_interfaces.
typedef struct trixanth_interfaces__srv__StartMission_Event
{
  service_msgs__msg__ServiceEventInfo info;
  trixanth_interfaces__srv__StartMission_Request__Sequence request;
  trixanth_interfaces__srv__StartMission_Response__Sequence response;
} trixanth_interfaces__srv__StartMission_Event;

// Struct for a sequence of trixanth_interfaces__srv__StartMission_Event.
typedef struct trixanth_interfaces__srv__StartMission_Event__Sequence
{
  trixanth_interfaces__srv__StartMission_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} trixanth_interfaces__srv__StartMission_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRIXANTH_INTERFACES__SRV__DETAIL__START_MISSION__STRUCT_H_
