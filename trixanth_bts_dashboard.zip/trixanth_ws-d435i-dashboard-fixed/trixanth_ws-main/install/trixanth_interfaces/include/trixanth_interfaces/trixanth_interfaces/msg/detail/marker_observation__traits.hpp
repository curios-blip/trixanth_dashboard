// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from trixanth_interfaces:msg/MarkerObservation.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/marker_observation.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__MARKER_OBSERVATION__TRAITS_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__MARKER_OBSERVATION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "trixanth_interfaces/msg/detail/marker_observation__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace trixanth_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const MarkerObservation & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: colour
  {
    out << "colour: ";
    rosidl_generator_traits::value_to_yaml(msg.colour, out);
    out << ", ";
  }

  // member: visible
  {
    out << "visible: ";
    rosidl_generator_traits::value_to_yaml(msg.visible, out);
    out << ", ";
  }

  // member: bearing_rad
  {
    out << "bearing_rad: ";
    rosidl_generator_traits::value_to_yaml(msg.bearing_rad, out);
    out << ", ";
  }

  // member: area_ratio
  {
    out << "area_ratio: ";
    rosidl_generator_traits::value_to_yaml(msg.area_ratio, out);
    out << ", ";
  }

  // member: range_m
  {
    out << "range_m: ";
    rosidl_generator_traits::value_to_yaml(msg.range_m, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MarkerObservation & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: colour
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "colour: ";
    rosidl_generator_traits::value_to_yaml(msg.colour, out);
    out << "\n";
  }

  // member: visible
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "visible: ";
    rosidl_generator_traits::value_to_yaml(msg.visible, out);
    out << "\n";
  }

  // member: bearing_rad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "bearing_rad: ";
    rosidl_generator_traits::value_to_yaml(msg.bearing_rad, out);
    out << "\n";
  }

  // member: area_ratio
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "area_ratio: ";
    rosidl_generator_traits::value_to_yaml(msg.area_ratio, out);
    out << "\n";
  }

  // member: range_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "range_m: ";
    rosidl_generator_traits::value_to_yaml(msg.range_m, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MarkerObservation & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace trixanth_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use trixanth_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const trixanth_interfaces::msg::MarkerObservation & msg,
  std::ostream & out, size_t indentation = 0)
{
  trixanth_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use trixanth_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const trixanth_interfaces::msg::MarkerObservation & msg)
{
  return trixanth_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<trixanth_interfaces::msg::MarkerObservation>()
{
  return "trixanth_interfaces::msg::MarkerObservation";
}

template<>
inline const char * name<trixanth_interfaces::msg::MarkerObservation>()
{
  return "trixanth_interfaces/msg/MarkerObservation";
}

template<>
struct has_fixed_size<trixanth_interfaces::msg::MarkerObservation>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<trixanth_interfaces::msg::MarkerObservation>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<trixanth_interfaces::msg::MarkerObservation>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__MARKER_OBSERVATION__TRAITS_HPP_
