// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from trixanth_interfaces:msg/DetectionArray.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/detection_array.h"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION_ARRAY__STRUCT_H_
#define TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION_ARRAY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'detections'
#include "trixanth_interfaces/msg/detail/detection__struct.h"

/// Struct defined in msg/DetectionArray in the package trixanth_interfaces.
typedef struct trixanth_interfaces__msg__DetectionArray
{
  std_msgs__msg__Header header;
  trixanth_interfaces__msg__Detection__Sequence detections;
} trixanth_interfaces__msg__DetectionArray;

// Struct for a sequence of trixanth_interfaces__msg__DetectionArray.
typedef struct trixanth_interfaces__msg__DetectionArray__Sequence
{
  trixanth_interfaces__msg__DetectionArray * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} trixanth_interfaces__msg__DetectionArray__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION_ARRAY__STRUCT_H_
