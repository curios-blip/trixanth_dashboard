// generated from rosidl_generator_c/resource/idl.h.em
// with input from trixanth_interfaces:msg/ScoreEvent.idl
// generated code does not contain a copyright notice

#ifndef TRIXANTH_INTERFACES__MSG__SCORE_EVENT_H_
#define TRIXANTH_INTERFACES__MSG__SCORE_EVENT_H_

#include "trixanth_interfaces/msg/detail/score_event__struct.h"
#include "trixanth_interfaces/msg/detail/score_event__functions.h"
#include "trixanth_interfaces/msg/detail/score_event__type_support.h"

#endif  // TRIXANTH_INTERFACES__MSG__SCORE_EVENT_H_
