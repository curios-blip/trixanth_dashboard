// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from trixanth_interfaces:msg/Detection.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/detection.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION__BUILDER_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "trixanth_interfaces/msg/detail/detection__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace trixanth_interfaces
{

namespace msg
{

namespace builder
{

class Init_Detection_position
{
public:
  explicit Init_Detection_position(::trixanth_interfaces::msg::Detection & msg)
  : msg_(msg)
  {}
  ::trixanth_interfaces::msg::Detection position(::trixanth_interfaces::msg::Detection::_position_type arg)
  {
    msg_.position = std::move(arg);
    return std::move(msg_);
  }

private:
  ::trixanth_interfaces::msg::Detection msg_;
};

class Init_Detection_h
{
public:
  explicit Init_Detection_h(::trixanth_interfaces::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_position h(::trixanth_interfaces::msg::Detection::_h_type arg)
  {
    msg_.h = std::move(arg);
    return Init_Detection_position(msg_);
  }

private:
  ::trixanth_interfaces::msg::Detection msg_;
};

class Init_Detection_w
{
public:
  explicit Init_Detection_w(::trixanth_interfaces::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_h w(::trixanth_interfaces::msg::Detection::_w_type arg)
  {
    msg_.w = std::move(arg);
    return Init_Detection_h(msg_);
  }

private:
  ::trixanth_interfaces::msg::Detection msg_;
};

class Init_Detection_y
{
public:
  explicit Init_Detection_y(::trixanth_interfaces::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_w y(::trixanth_interfaces::msg::Detection::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_Detection_w(msg_);
  }

private:
  ::trixanth_interfaces::msg::Detection msg_;
};

class Init_Detection_x
{
public:
  explicit Init_Detection_x(::trixanth_interfaces::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_y x(::trixanth_interfaces::msg::Detection::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_Detection_y(msg_);
  }

private:
  ::trixanth_interfaces::msg::Detection msg_;
};

class Init_Detection_confidence
{
public:
  explicit Init_Detection_confidence(::trixanth_interfaces::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_x confidence(::trixanth_interfaces::msg::Detection::_confidence_type arg)
  {
    msg_.confidence = std::move(arg);
    return Init_Detection_x(msg_);
  }

private:
  ::trixanth_interfaces::msg::Detection msg_;
};

class Init_Detection_label
{
public:
  Init_Detection_label()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Detection_confidence label(::trixanth_interfaces::msg::Detection::_label_type arg)
  {
    msg_.label = std::move(arg);
    return Init_Detection_confidence(msg_);
  }

private:
  ::trixanth_interfaces::msg::Detection msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::trixanth_interfaces::msg::Detection>()
{
  return trixanth_interfaces::msg::builder::Init_Detection_label();
}

}  // namespace trixanth_interfaces

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION__BUILDER_HPP_
