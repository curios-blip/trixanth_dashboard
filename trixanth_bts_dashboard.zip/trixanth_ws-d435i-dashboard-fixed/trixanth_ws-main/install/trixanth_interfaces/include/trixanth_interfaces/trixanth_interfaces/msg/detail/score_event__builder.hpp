// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from trixanth_interfaces:msg/ScoreEvent.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/score_event.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__SCORE_EVENT__BUILDER_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__SCORE_EVENT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "trixanth_interfaces/msg/detail/score_event__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace trixanth_interfaces
{

namespace msg
{

namespace builder
{

class Init_ScoreEvent_points
{
public:
  explicit Init_ScoreEvent_points(::trixanth_interfaces::msg::ScoreEvent & msg)
  : msg_(msg)
  {}
  ::trixanth_interfaces::msg::ScoreEvent points(::trixanth_interfaces::msg::ScoreEvent::_points_type arg)
  {
    msg_.points = std::move(arg);
    return std::move(msg_);
  }

private:
  ::trixanth_interfaces::msg::ScoreEvent msg_;
};

class Init_ScoreEvent_task
{
public:
  explicit Init_ScoreEvent_task(::trixanth_interfaces::msg::ScoreEvent & msg)
  : msg_(msg)
  {}
  Init_ScoreEvent_points task(::trixanth_interfaces::msg::ScoreEvent::_task_type arg)
  {
    msg_.task = std::move(arg);
    return Init_ScoreEvent_points(msg_);
  }

private:
  ::trixanth_interfaces::msg::ScoreEvent msg_;
};

class Init_ScoreEvent_header
{
public:
  Init_ScoreEvent_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ScoreEvent_task header(::trixanth_interfaces::msg::ScoreEvent::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ScoreEvent_task(msg_);
  }

private:
  ::trixanth_interfaces::msg::ScoreEvent msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::trixanth_interfaces::msg::ScoreEvent>()
{
  return trixanth_interfaces::msg::builder::Init_ScoreEvent_header();
}

}  // namespace trixanth_interfaces

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__SCORE_EVENT__BUILDER_HPP_
