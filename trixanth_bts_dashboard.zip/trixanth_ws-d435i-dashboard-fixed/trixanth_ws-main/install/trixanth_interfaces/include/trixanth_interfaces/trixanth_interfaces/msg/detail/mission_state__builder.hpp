// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from trixanth_interfaces:msg/MissionState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/mission_state.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__MISSION_STATE__BUILDER_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__MISSION_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "trixanth_interfaces/msg/detail/mission_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace trixanth_interfaces
{

namespace msg
{

namespace builder
{

class Init_MissionState_alert
{
public:
  explicit Init_MissionState_alert(::trixanth_interfaces::msg::MissionState & msg)
  : msg_(msg)
  {}
  ::trixanth_interfaces::msg::MissionState alert(::trixanth_interfaces::msg::MissionState::_alert_type arg)
  {
    msg_.alert = std::move(arg);
    return std::move(msg_);
  }

private:
  ::trixanth_interfaces::msg::MissionState msg_;
};

class Init_MissionState_bonus_unlocked
{
public:
  explicit Init_MissionState_bonus_unlocked(::trixanth_interfaces::msg::MissionState & msg)
  : msg_(msg)
  {}
  Init_MissionState_alert bonus_unlocked(::trixanth_interfaces::msg::MissionState::_bonus_unlocked_type arg)
  {
    msg_.bonus_unlocked = std::move(arg);
    return Init_MissionState_alert(msg_);
  }

private:
  ::trixanth_interfaces::msg::MissionState msg_;
};

class Init_MissionState_points_max
{
public:
  explicit Init_MissionState_points_max(::trixanth_interfaces::msg::MissionState & msg)
  : msg_(msg)
  {}
  Init_MissionState_bonus_unlocked points_max(::trixanth_interfaces::msg::MissionState::_points_max_type arg)
  {
    msg_.points_max = std::move(arg);
    return Init_MissionState_bonus_unlocked(msg_);
  }

private:
  ::trixanth_interfaces::msg::MissionState msg_;
};

class Init_MissionState_points
{
public:
  explicit Init_MissionState_points(::trixanth_interfaces::msg::MissionState & msg)
  : msg_(msg)
  {}
  Init_MissionState_points_max points(::trixanth_interfaces::msg::MissionState::_points_type arg)
  {
    msg_.points = std::move(arg);
    return Init_MissionState_points_max(msg_);
  }

private:
  ::trixanth_interfaces::msg::MissionState msg_;
};

class Init_MissionState_limit_s
{
public:
  explicit Init_MissionState_limit_s(::trixanth_interfaces::msg::MissionState & msg)
  : msg_(msg)
  {}
  Init_MissionState_points limit_s(::trixanth_interfaces::msg::MissionState::_limit_s_type arg)
  {
    msg_.limit_s = std::move(arg);
    return Init_MissionState_points(msg_);
  }

private:
  ::trixanth_interfaces::msg::MissionState msg_;
};

class Init_MissionState_elapsed_s
{
public:
  explicit Init_MissionState_elapsed_s(::trixanth_interfaces::msg::MissionState & msg)
  : msg_(msg)
  {}
  Init_MissionState_limit_s elapsed_s(::trixanth_interfaces::msg::MissionState::_elapsed_s_type arg)
  {
    msg_.elapsed_s = std::move(arg);
    return Init_MissionState_limit_s(msg_);
  }

private:
  ::trixanth_interfaces::msg::MissionState msg_;
};

class Init_MissionState_running
{
public:
  explicit Init_MissionState_running(::trixanth_interfaces::msg::MissionState & msg)
  : msg_(msg)
  {}
  Init_MissionState_elapsed_s running(::trixanth_interfaces::msg::MissionState::_running_type arg)
  {
    msg_.running = std::move(arg);
    return Init_MissionState_elapsed_s(msg_);
  }

private:
  ::trixanth_interfaces::msg::MissionState msg_;
};

class Init_MissionState_stage
{
public:
  explicit Init_MissionState_stage(::trixanth_interfaces::msg::MissionState & msg)
  : msg_(msg)
  {}
  Init_MissionState_running stage(::trixanth_interfaces::msg::MissionState::_stage_type arg)
  {
    msg_.stage = std::move(arg);
    return Init_MissionState_running(msg_);
  }

private:
  ::trixanth_interfaces::msg::MissionState msg_;
};

class Init_MissionState_mission
{
public:
  explicit Init_MissionState_mission(::trixanth_interfaces::msg::MissionState & msg)
  : msg_(msg)
  {}
  Init_MissionState_stage mission(::trixanth_interfaces::msg::MissionState::_mission_type arg)
  {
    msg_.mission = std::move(arg);
    return Init_MissionState_stage(msg_);
  }

private:
  ::trixanth_interfaces::msg::MissionState msg_;
};

class Init_MissionState_mode
{
public:
  explicit Init_MissionState_mode(::trixanth_interfaces::msg::MissionState & msg)
  : msg_(msg)
  {}
  Init_MissionState_mission mode(::trixanth_interfaces::msg::MissionState::_mode_type arg)
  {
    msg_.mode = std::move(arg);
    return Init_MissionState_mission(msg_);
  }

private:
  ::trixanth_interfaces::msg::MissionState msg_;
};

class Init_MissionState_header
{
public:
  Init_MissionState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MissionState_mode header(::trixanth_interfaces::msg::MissionState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_MissionState_mode(msg_);
  }

private:
  ::trixanth_interfaces::msg::MissionState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::trixanth_interfaces::msg::MissionState>()
{
  return trixanth_interfaces::msg::builder::Init_MissionState_header();
}

}  // namespace trixanth_interfaces

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__MISSION_STATE__BUILDER_HPP_
