// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from trixanth_interfaces:msg/MissionState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/mission_state.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__MISSION_STATE__TRAITS_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__MISSION_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "trixanth_interfaces/msg/detail/mission_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace trixanth_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const MissionState & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: mode
  {
    out << "mode: ";
    rosidl_generator_traits::value_to_yaml(msg.mode, out);
    out << ", ";
  }

  // member: mission
  {
    out << "mission: ";
    rosidl_generator_traits::value_to_yaml(msg.mission, out);
    out << ", ";
  }

  // member: stage
  {
    out << "stage: ";
    rosidl_generator_traits::value_to_yaml(msg.stage, out);
    out << ", ";
  }

  // member: running
  {
    out << "running: ";
    rosidl_generator_traits::value_to_yaml(msg.running, out);
    out << ", ";
  }

  // member: elapsed_s
  {
    out << "elapsed_s: ";
    rosidl_generator_traits::value_to_yaml(msg.elapsed_s, out);
    out << ", ";
  }

  // member: limit_s
  {
    out << "limit_s: ";
    rosidl_generator_traits::value_to_yaml(msg.limit_s, out);
    out << ", ";
  }

  // member: points
  {
    out << "points: ";
    rosidl_generator_traits::value_to_yaml(msg.points, out);
    out << ", ";
  }

  // member: points_max
  {
    out << "points_max: ";
    rosidl_generator_traits::value_to_yaml(msg.points_max, out);
    out << ", ";
  }

  // member: bonus_unlocked
  {
    out << "bonus_unlocked: ";
    rosidl_generator_traits::value_to_yaml(msg.bonus_unlocked, out);
    out << ", ";
  }

  // member: alert
  {
    out << "alert: ";
    rosidl_generator_traits::value_to_yaml(msg.alert, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MissionState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mode: ";
    rosidl_generator_traits::value_to_yaml(msg.mode, out);
    out << "\n";
  }

  // member: mission
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mission: ";
    rosidl_generator_traits::value_to_yaml(msg.mission, out);
    out << "\n";
  }

  // member: stage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stage: ";
    rosidl_generator_traits::value_to_yaml(msg.stage, out);
    out << "\n";
  }

  // member: running
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "running: ";
    rosidl_generator_traits::value_to_yaml(msg.running, out);
    out << "\n";
  }

  // member: elapsed_s
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "elapsed_s: ";
    rosidl_generator_traits::value_to_yaml(msg.elapsed_s, out);
    out << "\n";
  }

  // member: limit_s
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "limit_s: ";
    rosidl_generator_traits::value_to_yaml(msg.limit_s, out);
    out << "\n";
  }

  // member: points
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "points: ";
    rosidl_generator_traits::value_to_yaml(msg.points, out);
    out << "\n";
  }

  // member: points_max
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "points_max: ";
    rosidl_generator_traits::value_to_yaml(msg.points_max, out);
    out << "\n";
  }

  // member: bonus_unlocked
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "bonus_unlocked: ";
    rosidl_generator_traits::value_to_yaml(msg.bonus_unlocked, out);
    out << "\n";
  }

  // member: alert
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alert: ";
    rosidl_generator_traits::value_to_yaml(msg.alert, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MissionState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace trixanth_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use trixanth_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const trixanth_interfaces::msg::MissionState & msg,
  std::ostream & out, size_t indentation = 0)
{
  trixanth_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use trixanth_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const trixanth_interfaces::msg::MissionState & msg)
{
  return trixanth_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<trixanth_interfaces::msg::MissionState>()
{
  return "trixanth_interfaces::msg::MissionState";
}

template<>
inline const char * name<trixanth_interfaces::msg::MissionState>()
{
  return "trixanth_interfaces/msg/MissionState";
}

template<>
struct has_fixed_size<trixanth_interfaces::msg::MissionState>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<trixanth_interfaces::msg::MissionState>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<trixanth_interfaces::msg::MissionState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__MISSION_STATE__TRAITS_HPP_
