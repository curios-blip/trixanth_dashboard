// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from trixanth_interfaces:msg/MarkerObservation.idl
// generated code does not contain a copyright notice
#include "trixanth_interfaces/msg/detail/marker_observation__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `colour`
#include "rosidl_runtime_c/string_functions.h"

bool
trixanth_interfaces__msg__MarkerObservation__init(trixanth_interfaces__msg__MarkerObservation * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    trixanth_interfaces__msg__MarkerObservation__fini(msg);
    return false;
  }
  // colour
  if (!rosidl_runtime_c__String__init(&msg->colour)) {
    trixanth_interfaces__msg__MarkerObservation__fini(msg);
    return false;
  }
  // visible
  // bearing_rad
  // area_ratio
  // range_m
  return true;
}

void
trixanth_interfaces__msg__MarkerObservation__fini(trixanth_interfaces__msg__MarkerObservation * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // colour
  rosidl_runtime_c__String__fini(&msg->colour);
  // visible
  // bearing_rad
  // area_ratio
  // range_m
}

bool
trixanth_interfaces__msg__MarkerObservation__are_equal(const trixanth_interfaces__msg__MarkerObservation * lhs, const trixanth_interfaces__msg__MarkerObservation * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // colour
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->colour), &(rhs->colour)))
  {
    return false;
  }
  // visible
  if (lhs->visible != rhs->visible) {
    return false;
  }
  // bearing_rad
  if (lhs->bearing_rad != rhs->bearing_rad) {
    return false;
  }
  // area_ratio
  if (lhs->area_ratio != rhs->area_ratio) {
    return false;
  }
  // range_m
  if (lhs->range_m != rhs->range_m) {
    return false;
  }
  return true;
}

bool
trixanth_interfaces__msg__MarkerObservation__copy(
  const trixanth_interfaces__msg__MarkerObservation * input,
  trixanth_interfaces__msg__MarkerObservation * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // colour
  if (!rosidl_runtime_c__String__copy(
      &(input->colour), &(output->colour)))
  {
    return false;
  }
  // visible
  output->visible = input->visible;
  // bearing_rad
  output->bearing_rad = input->bearing_rad;
  // area_ratio
  output->area_ratio = input->area_ratio;
  // range_m
  output->range_m = input->range_m;
  return true;
}

trixanth_interfaces__msg__MarkerObservation *
trixanth_interfaces__msg__MarkerObservation__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  trixanth_interfaces__msg__MarkerObservation * msg = (trixanth_interfaces__msg__MarkerObservation *)allocator.allocate(sizeof(trixanth_interfaces__msg__MarkerObservation), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(trixanth_interfaces__msg__MarkerObservation));
  bool success = trixanth_interfaces__msg__MarkerObservation__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
trixanth_interfaces__msg__MarkerObservation__destroy(trixanth_interfaces__msg__MarkerObservation * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    trixanth_interfaces__msg__MarkerObservation__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
trixanth_interfaces__msg__MarkerObservation__Sequence__init(trixanth_interfaces__msg__MarkerObservation__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  trixanth_interfaces__msg__MarkerObservation * data = NULL;

  if (size) {
    data = (trixanth_interfaces__msg__MarkerObservation *)allocator.zero_allocate(size, sizeof(trixanth_interfaces__msg__MarkerObservation), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = trixanth_interfaces__msg__MarkerObservation__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        trixanth_interfaces__msg__MarkerObservation__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
trixanth_interfaces__msg__MarkerObservation__Sequence__fini(trixanth_interfaces__msg__MarkerObservation__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      trixanth_interfaces__msg__MarkerObservation__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

trixanth_interfaces__msg__MarkerObservation__Sequence *
trixanth_interfaces__msg__MarkerObservation__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  trixanth_interfaces__msg__MarkerObservation__Sequence * array = (trixanth_interfaces__msg__MarkerObservation__Sequence *)allocator.allocate(sizeof(trixanth_interfaces__msg__MarkerObservation__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = trixanth_interfaces__msg__MarkerObservation__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
trixanth_interfaces__msg__MarkerObservation__Sequence__destroy(trixanth_interfaces__msg__MarkerObservation__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    trixanth_interfaces__msg__MarkerObservation__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
trixanth_interfaces__msg__MarkerObservation__Sequence__are_equal(const trixanth_interfaces__msg__MarkerObservation__Sequence * lhs, const trixanth_interfaces__msg__MarkerObservation__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!trixanth_interfaces__msg__MarkerObservation__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
trixanth_interfaces__msg__MarkerObservation__Sequence__copy(
  const trixanth_interfaces__msg__MarkerObservation__Sequence * input,
  trixanth_interfaces__msg__MarkerObservation__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(trixanth_interfaces__msg__MarkerObservation);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    trixanth_interfaces__msg__MarkerObservation * data =
      (trixanth_interfaces__msg__MarkerObservation *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!trixanth_interfaces__msg__MarkerObservation__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          trixanth_interfaces__msg__MarkerObservation__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!trixanth_interfaces__msg__MarkerObservation__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
