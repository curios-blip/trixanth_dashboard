// generated from rosidl_generator_c/resource/idl.h.em
// with input from trixanth_interfaces:msg/DetectionArray.idl
// generated code does not contain a copyright notice

#ifndef TRIXANTH_INTERFACES__MSG__DETECTION_ARRAY_H_
#define TRIXANTH_INTERFACES__MSG__DETECTION_ARRAY_H_

#include "trixanth_interfaces/msg/detail/detection_array__struct.h"
#include "trixanth_interfaces/msg/detail/detection_array__functions.h"
#include "trixanth_interfaces/msg/detail/detection_array__type_support.h"

#endif  // TRIXANTH_INTERFACES__MSG__DETECTION_ARRAY_H_
