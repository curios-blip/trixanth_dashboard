// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from trixanth_interfaces:srv/SetMode.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/srv/set_mode.hpp"


#ifndef TRIXANTH_INTERFACES__SRV__DETAIL__SET_MODE__BUILDER_HPP_
#define TRIXANTH_INTERFACES__SRV__DETAIL__SET_MODE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "trixanth_interfaces/srv/detail/set_mode__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace trixanth_interfaces
{

namespace srv
{

namespace builder
{

class Init_SetMode_Request_mode
{
public:
  Init_SetMode_Request_mode()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::trixanth_interfaces::srv::SetMode_Request mode(::trixanth_interfaces::srv::SetMode_Request::_mode_type arg)
  {
    msg_.mode = std::move(arg);
    return std::move(msg_);
  }

private:
  ::trixanth_interfaces::srv::SetMode_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::trixanth_interfaces::srv::SetMode_Request>()
{
  return trixanth_interfaces::srv::builder::Init_SetMode_Request_mode();
}

}  // namespace trixanth_interfaces


namespace trixanth_interfaces
{

namespace srv
{

namespace builder
{

class Init_SetMode_Response_message
{
public:
  explicit Init_SetMode_Response_message(::trixanth_interfaces::srv::SetMode_Response & msg)
  : msg_(msg)
  {}
  ::trixanth_interfaces::srv::SetMode_Response message(::trixanth_interfaces::srv::SetMode_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::trixanth_interfaces::srv::SetMode_Response msg_;
};

class Init_SetMode_Response_success
{
public:
  Init_SetMode_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SetMode_Response_message success(::trixanth_interfaces::srv::SetMode_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_SetMode_Response_message(msg_);
  }

private:
  ::trixanth_interfaces::srv::SetMode_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::trixanth_interfaces::srv::SetMode_Response>()
{
  return trixanth_interfaces::srv::builder::Init_SetMode_Response_success();
}

}  // namespace trixanth_interfaces


namespace trixanth_interfaces
{

namespace srv
{

namespace builder
{

class Init_SetMode_Event_response
{
public:
  explicit Init_SetMode_Event_response(::trixanth_interfaces::srv::SetMode_Event & msg)
  : msg_(msg)
  {}
  ::trixanth_interfaces::srv::SetMode_Event response(::trixanth_interfaces::srv::SetMode_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::trixanth_interfaces::srv::SetMode_Event msg_;
};

class Init_SetMode_Event_request
{
public:
  explicit Init_SetMode_Event_request(::trixanth_interfaces::srv::SetMode_Event & msg)
  : msg_(msg)
  {}
  Init_SetMode_Event_response request(::trixanth_interfaces::srv::SetMode_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_SetMode_Event_response(msg_);
  }

private:
  ::trixanth_interfaces::srv::SetMode_Event msg_;
};

class Init_SetMode_Event_info
{
public:
  Init_SetMode_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SetMode_Event_request info(::trixanth_interfaces::srv::SetMode_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_SetMode_Event_request(msg_);
  }

private:
  ::trixanth_interfaces::srv::SetMode_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::trixanth_interfaces::srv::SetMode_Event>()
{
  return trixanth_interfaces::srv::builder::Init_SetMode_Event_info();
}

}  // namespace trixanth_interfaces

#endif  // TRIXANTH_INTERFACES__SRV__DETAIL__SET_MODE__BUILDER_HPP_
