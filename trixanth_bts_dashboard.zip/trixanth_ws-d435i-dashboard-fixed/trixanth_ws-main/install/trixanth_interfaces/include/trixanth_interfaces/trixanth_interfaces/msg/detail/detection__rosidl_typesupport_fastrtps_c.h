// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from trixanth_interfaces:msg/Detection.idl
// generated code does not contain a copyright notice
#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "trixanth_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "trixanth_interfaces/msg/detail/detection__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
bool cdr_serialize_trixanth_interfaces__msg__Detection(
  const trixanth_interfaces__msg__Detection * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
bool cdr_deserialize_trixanth_interfaces__msg__Detection(
  eprosima::fastcdr::Cdr &,
  trixanth_interfaces__msg__Detection * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t get_serialized_size_trixanth_interfaces__msg__Detection(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t max_serialized_size_trixanth_interfaces__msg__Detection(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
bool cdr_serialize_key_trixanth_interfaces__msg__Detection(
  const trixanth_interfaces__msg__Detection * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t get_serialized_size_key_trixanth_interfaces__msg__Detection(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
size_t max_serialized_size_key_trixanth_interfaces__msg__Detection(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_trixanth_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, trixanth_interfaces, msg, Detection)();

#ifdef __cplusplus
}
#endif

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
