// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRIXANTH_INTERFACES__MSG__MARKER_OBSERVATION_HPP_
#define TRIXANTH_INTERFACES__MSG__MARKER_OBSERVATION_HPP_

#include "trixanth_interfaces/msg/detail/marker_observation__struct.hpp"
#include "trixanth_interfaces/msg/detail/marker_observation__builder.hpp"
#include "trixanth_interfaces/msg/detail/marker_observation__traits.hpp"
#include "trixanth_interfaces/msg/detail/marker_observation__type_support.hpp"

#endif  // TRIXANTH_INTERFACES__MSG__MARKER_OBSERVATION_HPP_
