// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from trixanth_interfaces:msg/Detection.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/detection.h"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION__STRUCT_H_
#define TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'label'
#include "rosidl_runtime_c/string.h"
// Member 'position'
#include "geometry_msgs/msg/detail/point__struct.h"

/// Struct defined in msg/Detection in the package trixanth_interfaces.
typedef struct trixanth_interfaces__msg__Detection
{
  rosidl_runtime_c__String label;
  float confidence;
  /// Bounding box in image pixels (top-left x/y, width, height)
  int32_t x;
  int32_t y;
  int32_t w;
  int32_t h;
  /// Position in the camera optical frame if depth was available, else NaN
  geometry_msgs__msg__Point position;
} trixanth_interfaces__msg__Detection;

// Struct for a sequence of trixanth_interfaces__msg__Detection.
typedef struct trixanth_interfaces__msg__Detection__Sequence
{
  trixanth_interfaces__msg__Detection * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} trixanth_interfaces__msg__Detection__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION__STRUCT_H_
