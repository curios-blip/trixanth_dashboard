// generated from rosidl_generator_c/resource/idl.h.em
// with input from trixanth_interfaces:msg/MissionState.idl
// generated code does not contain a copyright notice

#ifndef TRIXANTH_INTERFACES__MSG__MISSION_STATE_H_
#define TRIXANTH_INTERFACES__MSG__MISSION_STATE_H_

#include "trixanth_interfaces/msg/detail/mission_state__struct.h"
#include "trixanth_interfaces/msg/detail/mission_state__functions.h"
#include "trixanth_interfaces/msg/detail/mission_state__type_support.h"

#endif  // TRIXANTH_INTERFACES__MSG__MISSION_STATE_H_
