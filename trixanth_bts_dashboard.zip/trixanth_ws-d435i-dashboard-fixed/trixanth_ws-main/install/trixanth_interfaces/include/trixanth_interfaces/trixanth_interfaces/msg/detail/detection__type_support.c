// generated from rosidl_generator_c/resource/idl__type_support.c.em
// with input from trixanth_interfaces:msg/Detection.idl
// generated code does not contain a copyright notice

#include <string.h>

#include "trixanth_interfaces/msg/detail/detection__type_support.h"
#include "trixanth_interfaces/msg/detail/detection__functions.h"
#include "rosidl_typesupport_interface/macros.h"
#include "trixanth_interfaces/msg/detail/detection__struct.h"

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}
#endif
