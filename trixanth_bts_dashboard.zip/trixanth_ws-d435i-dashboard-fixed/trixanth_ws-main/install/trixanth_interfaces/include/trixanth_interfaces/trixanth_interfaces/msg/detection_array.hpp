// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRIXANTH_INTERFACES__MSG__DETECTION_ARRAY_HPP_
#define TRIXANTH_INTERFACES__MSG__DETECTION_ARRAY_HPP_

#include "trixanth_interfaces/msg/detail/detection_array__struct.hpp"
#include "trixanth_interfaces/msg/detail/detection_array__builder.hpp"
#include "trixanth_interfaces/msg/detail/detection_array__traits.hpp"
#include "trixanth_interfaces/msg/detail/detection_array__type_support.hpp"

#endif  // TRIXANTH_INTERFACES__MSG__DETECTION_ARRAY_HPP_
