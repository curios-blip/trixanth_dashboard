// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from trixanth_interfaces:msg/MissionState.idl
// generated code does not contain a copyright notice

#include "trixanth_interfaces/msg/detail/mission_state__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_trixanth_interfaces
const rosidl_type_hash_t *
trixanth_interfaces__msg__MissionState__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x02, 0xbc, 0x73, 0x8c, 0xf5, 0x43, 0x33, 0x44,
      0xc6, 0x90, 0xb4, 0xd8, 0x5d, 0xc6, 0x89, 0x56,
      0x56, 0xf7, 0x22, 0xb1, 0xe5, 0x2a, 0x6e, 0xaf,
      0xab, 0x36, 0x52, 0xca, 0x5a, 0xdc, 0x14, 0x4a,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "std_msgs/msg/detail/header__functions.h"
#include "builtin_interfaces/msg/detail/time__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t std_msgs__msg__Header__EXPECTED_HASH = {1, {
    0xf4, 0x9f, 0xb3, 0xae, 0x2c, 0xf0, 0x70, 0xf7,
    0x93, 0x64, 0x5f, 0xf7, 0x49, 0x68, 0x3a, 0xc6,
    0xb0, 0x62, 0x03, 0xe4, 0x1c, 0x89, 0x1e, 0x17,
    0x70, 0x1b, 0x1c, 0xb5, 0x97, 0xce, 0x6a, 0x01,
  }};
#endif

static char trixanth_interfaces__msg__MissionState__TYPE_NAME[] = "trixanth_interfaces/msg/MissionState";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char std_msgs__msg__Header__TYPE_NAME[] = "std_msgs/msg/Header";

// Define type names, field names, and default values
static char trixanth_interfaces__msg__MissionState__FIELD_NAME__header[] = "header";
static char trixanth_interfaces__msg__MissionState__FIELD_NAME__mode[] = "mode";
static char trixanth_interfaces__msg__MissionState__FIELD_NAME__mission[] = "mission";
static char trixanth_interfaces__msg__MissionState__FIELD_NAME__stage[] = "stage";
static char trixanth_interfaces__msg__MissionState__FIELD_NAME__running[] = "running";
static char trixanth_interfaces__msg__MissionState__FIELD_NAME__elapsed_s[] = "elapsed_s";
static char trixanth_interfaces__msg__MissionState__FIELD_NAME__limit_s[] = "limit_s";
static char trixanth_interfaces__msg__MissionState__FIELD_NAME__points[] = "points";
static char trixanth_interfaces__msg__MissionState__FIELD_NAME__points_max[] = "points_max";
static char trixanth_interfaces__msg__MissionState__FIELD_NAME__bonus_unlocked[] = "bonus_unlocked";
static char trixanth_interfaces__msg__MissionState__FIELD_NAME__alert[] = "alert";

static rosidl_runtime_c__type_description__Field trixanth_interfaces__msg__MissionState__FIELDS[] = {
  {
    {trixanth_interfaces__msg__MissionState__FIELD_NAME__header, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MissionState__FIELD_NAME__mode, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MissionState__FIELD_NAME__mission, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MissionState__FIELD_NAME__stage, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MissionState__FIELD_NAME__running, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MissionState__FIELD_NAME__elapsed_s, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MissionState__FIELD_NAME__limit_s, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MissionState__FIELD_NAME__points, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MissionState__FIELD_NAME__points_max, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MissionState__FIELD_NAME__bonus_unlocked, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__MissionState__FIELD_NAME__alert, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription trixanth_interfaces__msg__MissionState__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
trixanth_interfaces__msg__MissionState__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {trixanth_interfaces__msg__MissionState__TYPE_NAME, 36, 36},
      {trixanth_interfaces__msg__MissionState__FIELDS, 11, 11},
    },
    {trixanth_interfaces__msg__MissionState__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&std_msgs__msg__Header__EXPECTED_HASH, std_msgs__msg__Header__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = std_msgs__msg__Header__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# Published by trixanth_mission/mission_monitor at 2 Hz and on every change.\n"
  "uint8 MODE_IDLE=0\n"
  "uint8 MODE_MANUAL=1\n"
  "uint8 MODE_AUTONOMOUS=2\n"
  "uint8 MODE_ESTOP=3\n"
  "\n"
  "std_msgs/Header header\n"
  "uint8 mode\n"
  "string mission          # \"rado\" | \"abex\" | \"idmo\" | \"\"\n"
  "string stage            # e.g. \"recon\", \"delivery\", or FSM state name\n"
  "bool running            # mission clock running\n"
  "float32 elapsed_s       # seconds since mission start\n"
  "float32 limit_s         # current allowed mission length (25 min, or 15 if the 30% gate failed)\n"
  "float32 points          # points logged so far (operator-entered, see ScoreEvent)\n"
  "float32 points_max      # max points for this mission (from config; UNKNOWN until Table 1.2)\n"
  "bool bonus_unlocked     # true after minute 15 if the 30% gate passed\n"
  "string alert            # human-readable warning for the dashboard, empty when none";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
trixanth_interfaces__msg__MissionState__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {trixanth_interfaces__msg__MissionState__TYPE_NAME, 36, 36},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 846, 846},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
trixanth_interfaces__msg__MissionState__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *trixanth_interfaces__msg__MissionState__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *std_msgs__msg__Header__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
