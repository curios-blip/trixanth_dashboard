// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRIXANTH_INTERFACES__MSG__SCORE_EVENT_HPP_
#define TRIXANTH_INTERFACES__MSG__SCORE_EVENT_HPP_

#include "trixanth_interfaces/msg/detail/score_event__struct.hpp"
#include "trixanth_interfaces/msg/detail/score_event__builder.hpp"
#include "trixanth_interfaces/msg/detail/score_event__traits.hpp"
#include "trixanth_interfaces/msg/detail/score_event__type_support.hpp"

#endif  // TRIXANTH_INTERFACES__MSG__SCORE_EVENT_HPP_
