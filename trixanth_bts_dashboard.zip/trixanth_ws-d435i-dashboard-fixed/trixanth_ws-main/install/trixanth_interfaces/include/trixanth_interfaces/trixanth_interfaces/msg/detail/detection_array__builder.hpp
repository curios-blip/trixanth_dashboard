// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from trixanth_interfaces:msg/DetectionArray.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/detection_array.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION_ARRAY__BUILDER_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION_ARRAY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "trixanth_interfaces/msg/detail/detection_array__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace trixanth_interfaces
{

namespace msg
{

namespace builder
{

class Init_DetectionArray_detections
{
public:
  explicit Init_DetectionArray_detections(::trixanth_interfaces::msg::DetectionArray & msg)
  : msg_(msg)
  {}
  ::trixanth_interfaces::msg::DetectionArray detections(::trixanth_interfaces::msg::DetectionArray::_detections_type arg)
  {
    msg_.detections = std::move(arg);
    return std::move(msg_);
  }

private:
  ::trixanth_interfaces::msg::DetectionArray msg_;
};

class Init_DetectionArray_header
{
public:
  Init_DetectionArray_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DetectionArray_detections header(::trixanth_interfaces::msg::DetectionArray::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_DetectionArray_detections(msg_);
  }

private:
  ::trixanth_interfaces::msg::DetectionArray msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::trixanth_interfaces::msg::DetectionArray>()
{
  return trixanth_interfaces::msg::builder::Init_DetectionArray_header();
}

}  // namespace trixanth_interfaces

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION_ARRAY__BUILDER_HPP_
