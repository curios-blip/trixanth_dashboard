// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRIXANTH_INTERFACES__MSG__DETECTION_HPP_
#define TRIXANTH_INTERFACES__MSG__DETECTION_HPP_

#include "trixanth_interfaces/msg/detail/detection__struct.hpp"
#include "trixanth_interfaces/msg/detail/detection__builder.hpp"
#include "trixanth_interfaces/msg/detail/detection__traits.hpp"
#include "trixanth_interfaces/msg/detail/detection__type_support.hpp"

#endif  // TRIXANTH_INTERFACES__MSG__DETECTION_HPP_
