// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from trixanth_interfaces:msg/Detection.idl
// generated code does not contain a copyright notice

#include "trixanth_interfaces/msg/detail/detection__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_trixanth_interfaces
const rosidl_type_hash_t *
trixanth_interfaces__msg__Detection__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x8a, 0xe9, 0xf6, 0x14, 0x42, 0xe6, 0x42, 0x80,
      0xc4, 0x66, 0x64, 0xcf, 0x19, 0xce, 0x28, 0x15,
      0xc9, 0x40, 0xb7, 0xe8, 0xc8, 0xbc, 0xd1, 0x38,
      0xc7, 0xd8, 0x4b, 0x21, 0x19, 0x1c, 0x8c, 0x8c,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "geometry_msgs/msg/detail/point__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t geometry_msgs__msg__Point__EXPECTED_HASH = {1, {
    0x69, 0x63, 0x08, 0x48, 0x42, 0xa9, 0xb0, 0x44,
    0x94, 0xd6, 0xb2, 0x94, 0x1d, 0x11, 0x44, 0x47,
    0x08, 0xd8, 0x92, 0xda, 0x2f, 0x4b, 0x09, 0x84,
    0x3b, 0x9c, 0x43, 0xf4, 0x2a, 0x7f, 0x68, 0x81,
  }};
#endif

static char trixanth_interfaces__msg__Detection__TYPE_NAME[] = "trixanth_interfaces/msg/Detection";
static char geometry_msgs__msg__Point__TYPE_NAME[] = "geometry_msgs/msg/Point";

// Define type names, field names, and default values
static char trixanth_interfaces__msg__Detection__FIELD_NAME__label[] = "label";
static char trixanth_interfaces__msg__Detection__FIELD_NAME__confidence[] = "confidence";
static char trixanth_interfaces__msg__Detection__FIELD_NAME__x[] = "x";
static char trixanth_interfaces__msg__Detection__FIELD_NAME__y[] = "y";
static char trixanth_interfaces__msg__Detection__FIELD_NAME__w[] = "w";
static char trixanth_interfaces__msg__Detection__FIELD_NAME__h[] = "h";
static char trixanth_interfaces__msg__Detection__FIELD_NAME__position[] = "position";

static rosidl_runtime_c__type_description__Field trixanth_interfaces__msg__Detection__FIELDS[] = {
  {
    {trixanth_interfaces__msg__Detection__FIELD_NAME__label, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__Detection__FIELD_NAME__confidence, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__Detection__FIELD_NAME__x, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__Detection__FIELD_NAME__y, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__Detection__FIELD_NAME__w, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__Detection__FIELD_NAME__h, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {trixanth_interfaces__msg__Detection__FIELD_NAME__position, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {geometry_msgs__msg__Point__TYPE_NAME, 23, 23},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription trixanth_interfaces__msg__Detection__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {geometry_msgs__msg__Point__TYPE_NAME, 23, 23},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
trixanth_interfaces__msg__Detection__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {trixanth_interfaces__msg__Detection__TYPE_NAME, 33, 33},
      {trixanth_interfaces__msg__Detection__FIELDS, 7, 7},
    },
    {trixanth_interfaces__msg__Detection__REFERENCED_TYPE_DESCRIPTIONS, 1, 1},
  };
  if (!constructed) {
    assert(0 == memcmp(&geometry_msgs__msg__Point__EXPECTED_HASH, geometry_msgs__msg__Point__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = geometry_msgs__msg__Point__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "string label\n"
  "float32 confidence\n"
  "# Bounding box in image pixels (top-left x/y, width, height)\n"
  "int32 x\n"
  "int32 y\n"
  "int32 w\n"
  "int32 h\n"
  "# Position in the camera optical frame if depth was available, else NaN\n"
  "geometry_msgs/Point position";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
trixanth_interfaces__msg__Detection__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {trixanth_interfaces__msg__Detection__TYPE_NAME, 33, 33},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 226, 226},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
trixanth_interfaces__msg__Detection__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[2];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 2, 2};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *trixanth_interfaces__msg__Detection__get_individual_type_description_source(NULL),
    sources[1] = *geometry_msgs__msg__Point__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
