// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from trixanth_interfaces:msg/ReconEntry.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/recon_entry.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__STRUCT_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__trixanth_interfaces__msg__ReconEntry __attribute__((deprecated))
#else
# define DEPRECATED__trixanth_interfaces__msg__ReconEntry __declspec(deprecated)
#endif

namespace trixanth_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ReconEntry_
{
  using Type = ReconEntry_<ContainerAllocator>;

  explicit ReconEntry_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->id = 0ul;
      this->label = "";
      this->confidence = 0.0f;
      this->latitude = 0.0;
      this->longitude = 0.0;
      this->altitude = 0.0;
      this->horizontal_accuracy_m = 0.0f;
      this->image_path = "";
    }
  }

  explicit ReconEntry_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    label(_alloc),
    image_path(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->id = 0ul;
      this->label = "";
      this->confidence = 0.0f;
      this->latitude = 0.0;
      this->longitude = 0.0;
      this->altitude = 0.0;
      this->horizontal_accuracy_m = 0.0f;
      this->image_path = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _id_type =
    uint32_t;
  _id_type id;
  using _label_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _label_type label;
  using _confidence_type =
    float;
  _confidence_type confidence;
  using _latitude_type =
    double;
  _latitude_type latitude;
  using _longitude_type =
    double;
  _longitude_type longitude;
  using _altitude_type =
    double;
  _altitude_type altitude;
  using _horizontal_accuracy_m_type =
    float;
  _horizontal_accuracy_m_type horizontal_accuracy_m;
  using _image_path_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _image_path_type image_path;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__id(
    const uint32_t & _arg)
  {
    this->id = _arg;
    return *this;
  }
  Type & set__label(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->label = _arg;
    return *this;
  }
  Type & set__confidence(
    const float & _arg)
  {
    this->confidence = _arg;
    return *this;
  }
  Type & set__latitude(
    const double & _arg)
  {
    this->latitude = _arg;
    return *this;
  }
  Type & set__longitude(
    const double & _arg)
  {
    this->longitude = _arg;
    return *this;
  }
  Type & set__altitude(
    const double & _arg)
  {
    this->altitude = _arg;
    return *this;
  }
  Type & set__horizontal_accuracy_m(
    const float & _arg)
  {
    this->horizontal_accuracy_m = _arg;
    return *this;
  }
  Type & set__image_path(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->image_path = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    trixanth_interfaces::msg::ReconEntry_<ContainerAllocator> *;
  using ConstRawPtr =
    const trixanth_interfaces::msg::ReconEntry_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<trixanth_interfaces::msg::ReconEntry_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<trixanth_interfaces::msg::ReconEntry_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      trixanth_interfaces::msg::ReconEntry_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<trixanth_interfaces::msg::ReconEntry_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      trixanth_interfaces::msg::ReconEntry_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<trixanth_interfaces::msg::ReconEntry_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<trixanth_interfaces::msg::ReconEntry_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<trixanth_interfaces::msg::ReconEntry_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__trixanth_interfaces__msg__ReconEntry
    std::shared_ptr<trixanth_interfaces::msg::ReconEntry_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__trixanth_interfaces__msg__ReconEntry
    std::shared_ptr<trixanth_interfaces::msg::ReconEntry_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ReconEntry_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->id != other.id) {
      return false;
    }
    if (this->label != other.label) {
      return false;
    }
    if (this->confidence != other.confidence) {
      return false;
    }
    if (this->latitude != other.latitude) {
      return false;
    }
    if (this->longitude != other.longitude) {
      return false;
    }
    if (this->altitude != other.altitude) {
      return false;
    }
    if (this->horizontal_accuracy_m != other.horizontal_accuracy_m) {
      return false;
    }
    if (this->image_path != other.image_path) {
      return false;
    }
    return true;
  }
  bool operator!=(const ReconEntry_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ReconEntry_

// alias to use template instance with default allocator
using ReconEntry =
  trixanth_interfaces::msg::ReconEntry_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace trixanth_interfaces

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__STRUCT_HPP_
