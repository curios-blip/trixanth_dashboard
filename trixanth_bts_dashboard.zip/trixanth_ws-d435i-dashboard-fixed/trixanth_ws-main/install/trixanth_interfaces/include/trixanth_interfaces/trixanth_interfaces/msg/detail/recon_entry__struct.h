// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from trixanth_interfaces:msg/ReconEntry.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/recon_entry.h"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__STRUCT_H_
#define TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'label'
// Member 'image_path'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/ReconEntry in the package trixanth_interfaces.
/**
  * One documented object from the RADO recon stage (rule 3.3.1).
 */
typedef struct trixanth_interfaces__msg__ReconEntry
{
  std_msgs__msg__Header header;
  uint32_t id;
  rosidl_runtime_c__String label;
  float confidence;
  /// WGS 84, decimal degrees
  double latitude;
  double longitude;
  double altitude;
  float horizontal_accuracy_m;
  /// saved photo on the rover
  rosidl_runtime_c__String image_path;
} trixanth_interfaces__msg__ReconEntry;

// Struct for a sequence of trixanth_interfaces__msg__ReconEntry.
typedef struct trixanth_interfaces__msg__ReconEntry__Sequence
{
  trixanth_interfaces__msg__ReconEntry * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} trixanth_interfaces__msg__ReconEntry__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__STRUCT_H_
