// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from trixanth_interfaces:msg/DetectionArray.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/detection_array.h"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION_ARRAY__TYPE_SUPPORT_H_
#define TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION_ARRAY__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "trixanth_interfaces/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_trixanth_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  trixanth_interfaces,
  msg,
  DetectionArray
)(void);

#ifdef __cplusplus
}
#endif

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__DETECTION_ARRAY__TYPE_SUPPORT_H_
