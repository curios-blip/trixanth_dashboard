// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from trixanth_interfaces:msg/MarkerObservation.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/marker_observation.h"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__MARKER_OBSERVATION__STRUCT_H_
#define TRIXANTH_INTERFACES__MSG__DETAIL__MARKER_OBSERVATION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'colour'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/MarkerObservation in the package trixanth_interfaces.
/**
  * A coloured delivery marker seen by the front camera.
 */
typedef struct trixanth_interfaces__msg__MarkerObservation
{
  std_msgs__msg__Header header;
  rosidl_runtime_c__String colour;
  bool visible;
  /// + is left of the image centre (REP 103)
  float bearing_rad;
  /// blob area / image area, a rough proximity cue
  float area_ratio;
  /// from depth if available, else NaN
  float range_m;
} trixanth_interfaces__msg__MarkerObservation;

// Struct for a sequence of trixanth_interfaces__msg__MarkerObservation.
typedef struct trixanth_interfaces__msg__MarkerObservation__Sequence
{
  trixanth_interfaces__msg__MarkerObservation * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} trixanth_interfaces__msg__MarkerObservation__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__MARKER_OBSERVATION__STRUCT_H_
