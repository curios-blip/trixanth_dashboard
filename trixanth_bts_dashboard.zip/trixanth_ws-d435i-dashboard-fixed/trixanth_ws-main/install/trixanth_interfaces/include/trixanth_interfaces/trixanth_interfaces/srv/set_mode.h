// generated from rosidl_generator_c/resource/idl.h.em
// with input from trixanth_interfaces:srv/SetMode.idl
// generated code does not contain a copyright notice

#ifndef TRIXANTH_INTERFACES__SRV__SET_MODE_H_
#define TRIXANTH_INTERFACES__SRV__SET_MODE_H_

#include "trixanth_interfaces/srv/detail/set_mode__struct.h"
#include "trixanth_interfaces/srv/detail/set_mode__functions.h"
#include "trixanth_interfaces/srv/detail/set_mode__type_support.h"

#endif  // TRIXANTH_INTERFACES__SRV__SET_MODE_H_
