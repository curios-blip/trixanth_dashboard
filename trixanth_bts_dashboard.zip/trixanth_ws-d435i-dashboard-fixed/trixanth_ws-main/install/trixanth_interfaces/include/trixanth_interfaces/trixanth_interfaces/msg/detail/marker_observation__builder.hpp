// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from trixanth_interfaces:msg/MarkerObservation.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/marker_observation.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__MARKER_OBSERVATION__BUILDER_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__MARKER_OBSERVATION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "trixanth_interfaces/msg/detail/marker_observation__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace trixanth_interfaces
{

namespace msg
{

namespace builder
{

class Init_MarkerObservation_range_m
{
public:
  explicit Init_MarkerObservation_range_m(::trixanth_interfaces::msg::MarkerObservation & msg)
  : msg_(msg)
  {}
  ::trixanth_interfaces::msg::MarkerObservation range_m(::trixanth_interfaces::msg::MarkerObservation::_range_m_type arg)
  {
    msg_.range_m = std::move(arg);
    return std::move(msg_);
  }

private:
  ::trixanth_interfaces::msg::MarkerObservation msg_;
};

class Init_MarkerObservation_area_ratio
{
public:
  explicit Init_MarkerObservation_area_ratio(::trixanth_interfaces::msg::MarkerObservation & msg)
  : msg_(msg)
  {}
  Init_MarkerObservation_range_m area_ratio(::trixanth_interfaces::msg::MarkerObservation::_area_ratio_type arg)
  {
    msg_.area_ratio = std::move(arg);
    return Init_MarkerObservation_range_m(msg_);
  }

private:
  ::trixanth_interfaces::msg::MarkerObservation msg_;
};

class Init_MarkerObservation_bearing_rad
{
public:
  explicit Init_MarkerObservation_bearing_rad(::trixanth_interfaces::msg::MarkerObservation & msg)
  : msg_(msg)
  {}
  Init_MarkerObservation_area_ratio bearing_rad(::trixanth_interfaces::msg::MarkerObservation::_bearing_rad_type arg)
  {
    msg_.bearing_rad = std::move(arg);
    return Init_MarkerObservation_area_ratio(msg_);
  }

private:
  ::trixanth_interfaces::msg::MarkerObservation msg_;
};

class Init_MarkerObservation_visible
{
public:
  explicit Init_MarkerObservation_visible(::trixanth_interfaces::msg::MarkerObservation & msg)
  : msg_(msg)
  {}
  Init_MarkerObservation_bearing_rad visible(::trixanth_interfaces::msg::MarkerObservation::_visible_type arg)
  {
    msg_.visible = std::move(arg);
    return Init_MarkerObservation_bearing_rad(msg_);
  }

private:
  ::trixanth_interfaces::msg::MarkerObservation msg_;
};

class Init_MarkerObservation_colour
{
public:
  explicit Init_MarkerObservation_colour(::trixanth_interfaces::msg::MarkerObservation & msg)
  : msg_(msg)
  {}
  Init_MarkerObservation_visible colour(::trixanth_interfaces::msg::MarkerObservation::_colour_type arg)
  {
    msg_.colour = std::move(arg);
    return Init_MarkerObservation_visible(msg_);
  }

private:
  ::trixanth_interfaces::msg::MarkerObservation msg_;
};

class Init_MarkerObservation_header
{
public:
  Init_MarkerObservation_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MarkerObservation_colour header(::trixanth_interfaces::msg::MarkerObservation::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_MarkerObservation_colour(msg_);
  }

private:
  ::trixanth_interfaces::msg::MarkerObservation msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::trixanth_interfaces::msg::MarkerObservation>()
{
  return trixanth_interfaces::msg::builder::Init_MarkerObservation_header();
}

}  // namespace trixanth_interfaces

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__MARKER_OBSERVATION__BUILDER_HPP_
