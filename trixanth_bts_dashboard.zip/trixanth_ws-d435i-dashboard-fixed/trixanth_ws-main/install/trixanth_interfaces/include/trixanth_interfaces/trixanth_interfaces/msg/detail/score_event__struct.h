// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from trixanth_interfaces:msg/ScoreEvent.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/score_event.h"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__SCORE_EVENT__STRUCT_H_
#define TRIXANTH_INTERFACES__MSG__DETAIL__SCORE_EVENT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'task'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/ScoreEvent in the package trixanth_interfaces.
/**
  * Operator or FSM logs that a sub-task earned points (estimated).
 */
typedef struct trixanth_interfaces__msg__ScoreEvent
{
  std_msgs__msg__Header header;
  rosidl_runtime_c__String task;
  float points;
} trixanth_interfaces__msg__ScoreEvent;

// Struct for a sequence of trixanth_interfaces__msg__ScoreEvent.
typedef struct trixanth_interfaces__msg__ScoreEvent__Sequence
{
  trixanth_interfaces__msg__ScoreEvent * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} trixanth_interfaces__msg__ScoreEvent__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__SCORE_EVENT__STRUCT_H_
