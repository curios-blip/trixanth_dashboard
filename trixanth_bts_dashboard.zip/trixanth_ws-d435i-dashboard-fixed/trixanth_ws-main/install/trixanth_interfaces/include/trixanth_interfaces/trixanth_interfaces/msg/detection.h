// generated from rosidl_generator_c/resource/idl.h.em
// with input from trixanth_interfaces:msg/Detection.idl
// generated code does not contain a copyright notice

#ifndef TRIXANTH_INTERFACES__MSG__DETECTION_H_
#define TRIXANTH_INTERFACES__MSG__DETECTION_H_

#include "trixanth_interfaces/msg/detail/detection__struct.h"
#include "trixanth_interfaces/msg/detail/detection__functions.h"
#include "trixanth_interfaces/msg/detail/detection__type_support.h"

#endif  // TRIXANTH_INTERFACES__MSG__DETECTION_H_
