// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from trixanth_interfaces:msg/ScoreEvent.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "trixanth_interfaces/msg/detail/score_event__rosidl_typesupport_introspection_c.h"
#include "trixanth_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "trixanth_interfaces/msg/detail/score_event__functions.h"
#include "trixanth_interfaces/msg/detail/score_event__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `task`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  trixanth_interfaces__msg__ScoreEvent__init(message_memory);
}

void trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_fini_function(void * message_memory)
{
  trixanth_interfaces__msg__ScoreEvent__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_message_member_array[3] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(trixanth_interfaces__msg__ScoreEvent, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "task",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(trixanth_interfaces__msg__ScoreEvent, task),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "points",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(trixanth_interfaces__msg__ScoreEvent, points),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_message_members = {
  "trixanth_interfaces__msg",  // message namespace
  "ScoreEvent",  // message name
  3,  // number of fields
  sizeof(trixanth_interfaces__msg__ScoreEvent),
  false,  // has_any_key_member_
  trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_message_member_array,  // message members
  trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_init_function,  // function to initialize message memory (memory has to be allocated)
  trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_message_type_support_handle = {
  0,
  &trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_message_members,
  get_message_typesupport_handle_function,
  &trixanth_interfaces__msg__ScoreEvent__get_type_hash,
  &trixanth_interfaces__msg__ScoreEvent__get_type_description,
  &trixanth_interfaces__msg__ScoreEvent__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_trixanth_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, trixanth_interfaces, msg, ScoreEvent)() {
  trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_message_type_support_handle.typesupport_identifier) {
    trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &trixanth_interfaces__msg__ScoreEvent__rosidl_typesupport_introspection_c__ScoreEvent_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
