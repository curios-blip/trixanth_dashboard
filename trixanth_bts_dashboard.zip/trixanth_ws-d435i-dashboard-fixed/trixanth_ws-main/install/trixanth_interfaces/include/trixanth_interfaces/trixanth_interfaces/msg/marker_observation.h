// generated from rosidl_generator_c/resource/idl.h.em
// with input from trixanth_interfaces:msg/MarkerObservation.idl
// generated code does not contain a copyright notice

#ifndef TRIXANTH_INTERFACES__MSG__MARKER_OBSERVATION_H_
#define TRIXANTH_INTERFACES__MSG__MARKER_OBSERVATION_H_

#include "trixanth_interfaces/msg/detail/marker_observation__struct.h"
#include "trixanth_interfaces/msg/detail/marker_observation__functions.h"
#include "trixanth_interfaces/msg/detail/marker_observation__type_support.h"

#endif  // TRIXANTH_INTERFACES__MSG__MARKER_OBSERVATION_H_
