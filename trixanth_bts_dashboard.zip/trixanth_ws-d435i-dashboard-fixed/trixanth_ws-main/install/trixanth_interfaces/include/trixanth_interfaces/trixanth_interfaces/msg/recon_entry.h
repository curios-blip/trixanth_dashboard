// generated from rosidl_generator_c/resource/idl.h.em
// with input from trixanth_interfaces:msg/ReconEntry.idl
// generated code does not contain a copyright notice

#ifndef TRIXANTH_INTERFACES__MSG__RECON_ENTRY_H_
#define TRIXANTH_INTERFACES__MSG__RECON_ENTRY_H_

#include "trixanth_interfaces/msg/detail/recon_entry__struct.h"
#include "trixanth_interfaces/msg/detail/recon_entry__functions.h"
#include "trixanth_interfaces/msg/detail/recon_entry__type_support.h"

#endif  // TRIXANTH_INTERFACES__MSG__RECON_ENTRY_H_
