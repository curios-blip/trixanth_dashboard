// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from trixanth_interfaces:msg/MissionState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/mission_state.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__MISSION_STATE__STRUCT_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__MISSION_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__trixanth_interfaces__msg__MissionState __attribute__((deprecated))
#else
# define DEPRECATED__trixanth_interfaces__msg__MissionState __declspec(deprecated)
#endif

namespace trixanth_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct MissionState_
{
  using Type = MissionState_<ContainerAllocator>;

  explicit MissionState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->mode = 0;
      this->mission = "";
      this->stage = "";
      this->running = false;
      this->elapsed_s = 0.0f;
      this->limit_s = 0.0f;
      this->points = 0.0f;
      this->points_max = 0.0f;
      this->bonus_unlocked = false;
      this->alert = "";
    }
  }

  explicit MissionState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    mission(_alloc),
    stage(_alloc),
    alert(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->mode = 0;
      this->mission = "";
      this->stage = "";
      this->running = false;
      this->elapsed_s = 0.0f;
      this->limit_s = 0.0f;
      this->points = 0.0f;
      this->points_max = 0.0f;
      this->bonus_unlocked = false;
      this->alert = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _mode_type =
    uint8_t;
  _mode_type mode;
  using _mission_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _mission_type mission;
  using _stage_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _stage_type stage;
  using _running_type =
    bool;
  _running_type running;
  using _elapsed_s_type =
    float;
  _elapsed_s_type elapsed_s;
  using _limit_s_type =
    float;
  _limit_s_type limit_s;
  using _points_type =
    float;
  _points_type points;
  using _points_max_type =
    float;
  _points_max_type points_max;
  using _bonus_unlocked_type =
    bool;
  _bonus_unlocked_type bonus_unlocked;
  using _alert_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _alert_type alert;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__mode(
    const uint8_t & _arg)
  {
    this->mode = _arg;
    return *this;
  }
  Type & set__mission(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->mission = _arg;
    return *this;
  }
  Type & set__stage(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->stage = _arg;
    return *this;
  }
  Type & set__running(
    const bool & _arg)
  {
    this->running = _arg;
    return *this;
  }
  Type & set__elapsed_s(
    const float & _arg)
  {
    this->elapsed_s = _arg;
    return *this;
  }
  Type & set__limit_s(
    const float & _arg)
  {
    this->limit_s = _arg;
    return *this;
  }
  Type & set__points(
    const float & _arg)
  {
    this->points = _arg;
    return *this;
  }
  Type & set__points_max(
    const float & _arg)
  {
    this->points_max = _arg;
    return *this;
  }
  Type & set__bonus_unlocked(
    const bool & _arg)
  {
    this->bonus_unlocked = _arg;
    return *this;
  }
  Type & set__alert(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->alert = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t MODE_IDLE =
    0u;
  static constexpr uint8_t MODE_MANUAL =
    1u;
  static constexpr uint8_t MODE_AUTONOMOUS =
    2u;
  static constexpr uint8_t MODE_ESTOP =
    3u;

  // pointer types
  using RawPtr =
    trixanth_interfaces::msg::MissionState_<ContainerAllocator> *;
  using ConstRawPtr =
    const trixanth_interfaces::msg::MissionState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<trixanth_interfaces::msg::MissionState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<trixanth_interfaces::msg::MissionState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      trixanth_interfaces::msg::MissionState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<trixanth_interfaces::msg::MissionState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      trixanth_interfaces::msg::MissionState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<trixanth_interfaces::msg::MissionState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<trixanth_interfaces::msg::MissionState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<trixanth_interfaces::msg::MissionState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__trixanth_interfaces__msg__MissionState
    std::shared_ptr<trixanth_interfaces::msg::MissionState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__trixanth_interfaces__msg__MissionState
    std::shared_ptr<trixanth_interfaces::msg::MissionState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MissionState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->mode != other.mode) {
      return false;
    }
    if (this->mission != other.mission) {
      return false;
    }
    if (this->stage != other.stage) {
      return false;
    }
    if (this->running != other.running) {
      return false;
    }
    if (this->elapsed_s != other.elapsed_s) {
      return false;
    }
    if (this->limit_s != other.limit_s) {
      return false;
    }
    if (this->points != other.points) {
      return false;
    }
    if (this->points_max != other.points_max) {
      return false;
    }
    if (this->bonus_unlocked != other.bonus_unlocked) {
      return false;
    }
    if (this->alert != other.alert) {
      return false;
    }
    return true;
  }
  bool operator!=(const MissionState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MissionState_

// alias to use template instance with default allocator
using MissionState =
  trixanth_interfaces::msg::MissionState_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t MissionState_<ContainerAllocator>::MODE_IDLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t MissionState_<ContainerAllocator>::MODE_MANUAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t MissionState_<ContainerAllocator>::MODE_AUTONOMOUS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t MissionState_<ContainerAllocator>::MODE_ESTOP;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace trixanth_interfaces

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__MISSION_STATE__STRUCT_HPP_
