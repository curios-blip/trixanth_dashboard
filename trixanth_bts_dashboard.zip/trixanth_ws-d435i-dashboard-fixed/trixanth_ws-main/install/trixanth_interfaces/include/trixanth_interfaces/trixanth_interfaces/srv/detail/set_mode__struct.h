// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from trixanth_interfaces:srv/SetMode.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/srv/set_mode.h"


#ifndef TRIXANTH_INTERFACES__SRV__DETAIL__SET_MODE__STRUCT_H_
#define TRIXANTH_INTERFACES__SRV__DETAIL__SET_MODE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'MODE_IDLE'.
enum
{
  trixanth_interfaces__srv__SetMode_Request__MODE_IDLE = 0
};

/// Constant 'MODE_MANUAL'.
enum
{
  trixanth_interfaces__srv__SetMode_Request__MODE_MANUAL = 1
};

/// Constant 'MODE_AUTONOMOUS'.
enum
{
  trixanth_interfaces__srv__SetMode_Request__MODE_AUTONOMOUS = 2
};

/// Constant 'MODE_ESTOP'.
enum
{
  trixanth_interfaces__srv__SetMode_Request__MODE_ESTOP = 3
};

/// Struct defined in srv/SetMode in the package trixanth_interfaces.
typedef struct trixanth_interfaces__srv__SetMode_Request
{
  uint8_t mode;
} trixanth_interfaces__srv__SetMode_Request;

// Struct for a sequence of trixanth_interfaces__srv__SetMode_Request.
typedef struct trixanth_interfaces__srv__SetMode_Request__Sequence
{
  trixanth_interfaces__srv__SetMode_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} trixanth_interfaces__srv__SetMode_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/SetMode in the package trixanth_interfaces.
typedef struct trixanth_interfaces__srv__SetMode_Response
{
  bool success;
  rosidl_runtime_c__String message;
} trixanth_interfaces__srv__SetMode_Response;

// Struct for a sequence of trixanth_interfaces__srv__SetMode_Response.
typedef struct trixanth_interfaces__srv__SetMode_Response__Sequence
{
  trixanth_interfaces__srv__SetMode_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} trixanth_interfaces__srv__SetMode_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  trixanth_interfaces__srv__SetMode_Event__request__MAX_SIZE = 1
};
// response
enum
{
  trixanth_interfaces__srv__SetMode_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/SetMode in the package trixanth_interfaces.
typedef struct trixanth_interfaces__srv__SetMode_Event
{
  service_msgs__msg__ServiceEventInfo info;
  trixanth_interfaces__srv__SetMode_Request__Sequence request;
  trixanth_interfaces__srv__SetMode_Response__Sequence response;
} trixanth_interfaces__srv__SetMode_Event;

// Struct for a sequence of trixanth_interfaces__srv__SetMode_Event.
typedef struct trixanth_interfaces__srv__SetMode_Event__Sequence
{
  trixanth_interfaces__srv__SetMode_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} trixanth_interfaces__srv__SetMode_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRIXANTH_INTERFACES__SRV__DETAIL__SET_MODE__STRUCT_H_
