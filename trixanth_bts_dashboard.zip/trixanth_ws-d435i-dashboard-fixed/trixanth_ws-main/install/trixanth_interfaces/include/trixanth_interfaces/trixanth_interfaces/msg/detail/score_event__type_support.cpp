// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from trixanth_interfaces:msg/ScoreEvent.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "trixanth_interfaces/msg/detail/score_event__functions.h"
#include "trixanth_interfaces/msg/detail/score_event__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace trixanth_interfaces
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void ScoreEvent_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) trixanth_interfaces::msg::ScoreEvent(_init);
}

void ScoreEvent_fini_function(void * message_memory)
{
  auto typed_message = static_cast<trixanth_interfaces::msg::ScoreEvent *>(message_memory);
  typed_message->~ScoreEvent();
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember ScoreEvent_message_member_array[3] = {
  {
    "header",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<std_msgs::msg::Header>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(trixanth_interfaces::msg::ScoreEvent, header),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "task",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(trixanth_interfaces::msg::ScoreEvent, task),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "points",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(trixanth_interfaces::msg::ScoreEvent, points),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers ScoreEvent_message_members = {
  "trixanth_interfaces::msg",  // message namespace
  "ScoreEvent",  // message name
  3,  // number of fields
  sizeof(trixanth_interfaces::msg::ScoreEvent),
  false,  // has_any_key_member_
  ScoreEvent_message_member_array,  // message members
  ScoreEvent_init_function,  // function to initialize message memory (memory has to be allocated)
  ScoreEvent_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t ScoreEvent_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &ScoreEvent_message_members,
  get_message_typesupport_handle_function,
  &trixanth_interfaces__msg__ScoreEvent__get_type_hash,
  &trixanth_interfaces__msg__ScoreEvent__get_type_description,
  &trixanth_interfaces__msg__ScoreEvent__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace trixanth_interfaces


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<trixanth_interfaces::msg::ScoreEvent>()
{
  return &::trixanth_interfaces::msg::rosidl_typesupport_introspection_cpp::ScoreEvent_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, trixanth_interfaces, msg, ScoreEvent)() {
  return &::trixanth_interfaces::msg::rosidl_typesupport_introspection_cpp::ScoreEvent_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
