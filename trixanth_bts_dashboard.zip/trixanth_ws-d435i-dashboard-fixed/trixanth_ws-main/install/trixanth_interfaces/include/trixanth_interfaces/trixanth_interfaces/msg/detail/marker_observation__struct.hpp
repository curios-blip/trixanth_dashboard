// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from trixanth_interfaces:msg/MarkerObservation.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/marker_observation.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__MARKER_OBSERVATION__STRUCT_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__MARKER_OBSERVATION__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__trixanth_interfaces__msg__MarkerObservation __attribute__((deprecated))
#else
# define DEPRECATED__trixanth_interfaces__msg__MarkerObservation __declspec(deprecated)
#endif

namespace trixanth_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct MarkerObservation_
{
  using Type = MarkerObservation_<ContainerAllocator>;

  explicit MarkerObservation_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->colour = "";
      this->visible = false;
      this->bearing_rad = 0.0f;
      this->area_ratio = 0.0f;
      this->range_m = 0.0f;
    }
  }

  explicit MarkerObservation_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    colour(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->colour = "";
      this->visible = false;
      this->bearing_rad = 0.0f;
      this->area_ratio = 0.0f;
      this->range_m = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _colour_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _colour_type colour;
  using _visible_type =
    bool;
  _visible_type visible;
  using _bearing_rad_type =
    float;
  _bearing_rad_type bearing_rad;
  using _area_ratio_type =
    float;
  _area_ratio_type area_ratio;
  using _range_m_type =
    float;
  _range_m_type range_m;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__colour(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->colour = _arg;
    return *this;
  }
  Type & set__visible(
    const bool & _arg)
  {
    this->visible = _arg;
    return *this;
  }
  Type & set__bearing_rad(
    const float & _arg)
  {
    this->bearing_rad = _arg;
    return *this;
  }
  Type & set__area_ratio(
    const float & _arg)
  {
    this->area_ratio = _arg;
    return *this;
  }
  Type & set__range_m(
    const float & _arg)
  {
    this->range_m = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    trixanth_interfaces::msg::MarkerObservation_<ContainerAllocator> *;
  using ConstRawPtr =
    const trixanth_interfaces::msg::MarkerObservation_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<trixanth_interfaces::msg::MarkerObservation_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<trixanth_interfaces::msg::MarkerObservation_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      trixanth_interfaces::msg::MarkerObservation_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<trixanth_interfaces::msg::MarkerObservation_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      trixanth_interfaces::msg::MarkerObservation_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<trixanth_interfaces::msg::MarkerObservation_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<trixanth_interfaces::msg::MarkerObservation_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<trixanth_interfaces::msg::MarkerObservation_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__trixanth_interfaces__msg__MarkerObservation
    std::shared_ptr<trixanth_interfaces::msg::MarkerObservation_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__trixanth_interfaces__msg__MarkerObservation
    std::shared_ptr<trixanth_interfaces::msg::MarkerObservation_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MarkerObservation_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->colour != other.colour) {
      return false;
    }
    if (this->visible != other.visible) {
      return false;
    }
    if (this->bearing_rad != other.bearing_rad) {
      return false;
    }
    if (this->area_ratio != other.area_ratio) {
      return false;
    }
    if (this->range_m != other.range_m) {
      return false;
    }
    return true;
  }
  bool operator!=(const MarkerObservation_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MarkerObservation_

// alias to use template instance with default allocator
using MarkerObservation =
  trixanth_interfaces::msg::MarkerObservation_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace trixanth_interfaces

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__MARKER_OBSERVATION__STRUCT_HPP_
