// generated from rosidl_generator_c/resource/idl__type_support.c.em
// with input from trixanth_interfaces:msg/MarkerObservation.idl
// generated code does not contain a copyright notice

#include <string.h>

#include "trixanth_interfaces/msg/detail/marker_observation__type_support.h"
#include "trixanth_interfaces/msg/detail/marker_observation__struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "trixanth_interfaces/msg/detail/marker_observation__functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}
#endif
