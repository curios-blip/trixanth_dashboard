// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from trixanth_interfaces:msg/ReconEntry.idl
// generated code does not contain a copyright notice
#include "trixanth_interfaces/msg/detail/recon_entry__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `label`
// Member `image_path`
#include "rosidl_runtime_c/string_functions.h"

bool
trixanth_interfaces__msg__ReconEntry__init(trixanth_interfaces__msg__ReconEntry * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    trixanth_interfaces__msg__ReconEntry__fini(msg);
    return false;
  }
  // id
  // label
  if (!rosidl_runtime_c__String__init(&msg->label)) {
    trixanth_interfaces__msg__ReconEntry__fini(msg);
    return false;
  }
  // confidence
  // latitude
  // longitude
  // altitude
  // horizontal_accuracy_m
  // image_path
  if (!rosidl_runtime_c__String__init(&msg->image_path)) {
    trixanth_interfaces__msg__ReconEntry__fini(msg);
    return false;
  }
  return true;
}

void
trixanth_interfaces__msg__ReconEntry__fini(trixanth_interfaces__msg__ReconEntry * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // id
  // label
  rosidl_runtime_c__String__fini(&msg->label);
  // confidence
  // latitude
  // longitude
  // altitude
  // horizontal_accuracy_m
  // image_path
  rosidl_runtime_c__String__fini(&msg->image_path);
}

bool
trixanth_interfaces__msg__ReconEntry__are_equal(const trixanth_interfaces__msg__ReconEntry * lhs, const trixanth_interfaces__msg__ReconEntry * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // id
  if (lhs->id != rhs->id) {
    return false;
  }
  // label
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->label), &(rhs->label)))
  {
    return false;
  }
  // confidence
  if (lhs->confidence != rhs->confidence) {
    return false;
  }
  // latitude
  if (lhs->latitude != rhs->latitude) {
    return false;
  }
  // longitude
  if (lhs->longitude != rhs->longitude) {
    return false;
  }
  // altitude
  if (lhs->altitude != rhs->altitude) {
    return false;
  }
  // horizontal_accuracy_m
  if (lhs->horizontal_accuracy_m != rhs->horizontal_accuracy_m) {
    return false;
  }
  // image_path
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->image_path), &(rhs->image_path)))
  {
    return false;
  }
  return true;
}

bool
trixanth_interfaces__msg__ReconEntry__copy(
  const trixanth_interfaces__msg__ReconEntry * input,
  trixanth_interfaces__msg__ReconEntry * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // id
  output->id = input->id;
  // label
  if (!rosidl_runtime_c__String__copy(
      &(input->label), &(output->label)))
  {
    return false;
  }
  // confidence
  output->confidence = input->confidence;
  // latitude
  output->latitude = input->latitude;
  // longitude
  output->longitude = input->longitude;
  // altitude
  output->altitude = input->altitude;
  // horizontal_accuracy_m
  output->horizontal_accuracy_m = input->horizontal_accuracy_m;
  // image_path
  if (!rosidl_runtime_c__String__copy(
      &(input->image_path), &(output->image_path)))
  {
    return false;
  }
  return true;
}

trixanth_interfaces__msg__ReconEntry *
trixanth_interfaces__msg__ReconEntry__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  trixanth_interfaces__msg__ReconEntry * msg = (trixanth_interfaces__msg__ReconEntry *)allocator.allocate(sizeof(trixanth_interfaces__msg__ReconEntry), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(trixanth_interfaces__msg__ReconEntry));
  bool success = trixanth_interfaces__msg__ReconEntry__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
trixanth_interfaces__msg__ReconEntry__destroy(trixanth_interfaces__msg__ReconEntry * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    trixanth_interfaces__msg__ReconEntry__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
trixanth_interfaces__msg__ReconEntry__Sequence__init(trixanth_interfaces__msg__ReconEntry__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  trixanth_interfaces__msg__ReconEntry * data = NULL;

  if (size) {
    data = (trixanth_interfaces__msg__ReconEntry *)allocator.zero_allocate(size, sizeof(trixanth_interfaces__msg__ReconEntry), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = trixanth_interfaces__msg__ReconEntry__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        trixanth_interfaces__msg__ReconEntry__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
trixanth_interfaces__msg__ReconEntry__Sequence__fini(trixanth_interfaces__msg__ReconEntry__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      trixanth_interfaces__msg__ReconEntry__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

trixanth_interfaces__msg__ReconEntry__Sequence *
trixanth_interfaces__msg__ReconEntry__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  trixanth_interfaces__msg__ReconEntry__Sequence * array = (trixanth_interfaces__msg__ReconEntry__Sequence *)allocator.allocate(sizeof(trixanth_interfaces__msg__ReconEntry__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = trixanth_interfaces__msg__ReconEntry__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
trixanth_interfaces__msg__ReconEntry__Sequence__destroy(trixanth_interfaces__msg__ReconEntry__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    trixanth_interfaces__msg__ReconEntry__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
trixanth_interfaces__msg__ReconEntry__Sequence__are_equal(const trixanth_interfaces__msg__ReconEntry__Sequence * lhs, const trixanth_interfaces__msg__ReconEntry__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!trixanth_interfaces__msg__ReconEntry__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
trixanth_interfaces__msg__ReconEntry__Sequence__copy(
  const trixanth_interfaces__msg__ReconEntry__Sequence * input,
  trixanth_interfaces__msg__ReconEntry__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(trixanth_interfaces__msg__ReconEntry);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    trixanth_interfaces__msg__ReconEntry * data =
      (trixanth_interfaces__msg__ReconEntry *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!trixanth_interfaces__msg__ReconEntry__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          trixanth_interfaces__msg__ReconEntry__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!trixanth_interfaces__msg__ReconEntry__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
