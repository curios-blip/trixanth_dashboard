// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from trixanth_interfaces:msg/MissionState.idl
// generated code does not contain a copyright notice
#include "trixanth_interfaces/msg/detail/mission_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `mission`
// Member `stage`
// Member `alert`
#include "rosidl_runtime_c/string_functions.h"

bool
trixanth_interfaces__msg__MissionState__init(trixanth_interfaces__msg__MissionState * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    trixanth_interfaces__msg__MissionState__fini(msg);
    return false;
  }
  // mode
  // mission
  if (!rosidl_runtime_c__String__init(&msg->mission)) {
    trixanth_interfaces__msg__MissionState__fini(msg);
    return false;
  }
  // stage
  if (!rosidl_runtime_c__String__init(&msg->stage)) {
    trixanth_interfaces__msg__MissionState__fini(msg);
    return false;
  }
  // running
  // elapsed_s
  // limit_s
  // points
  // points_max
  // bonus_unlocked
  // alert
  if (!rosidl_runtime_c__String__init(&msg->alert)) {
    trixanth_interfaces__msg__MissionState__fini(msg);
    return false;
  }
  return true;
}

void
trixanth_interfaces__msg__MissionState__fini(trixanth_interfaces__msg__MissionState * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // mode
  // mission
  rosidl_runtime_c__String__fini(&msg->mission);
  // stage
  rosidl_runtime_c__String__fini(&msg->stage);
  // running
  // elapsed_s
  // limit_s
  // points
  // points_max
  // bonus_unlocked
  // alert
  rosidl_runtime_c__String__fini(&msg->alert);
}

bool
trixanth_interfaces__msg__MissionState__are_equal(const trixanth_interfaces__msg__MissionState * lhs, const trixanth_interfaces__msg__MissionState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // mode
  if (lhs->mode != rhs->mode) {
    return false;
  }
  // mission
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->mission), &(rhs->mission)))
  {
    return false;
  }
  // stage
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->stage), &(rhs->stage)))
  {
    return false;
  }
  // running
  if (lhs->running != rhs->running) {
    return false;
  }
  // elapsed_s
  if (lhs->elapsed_s != rhs->elapsed_s) {
    return false;
  }
  // limit_s
  if (lhs->limit_s != rhs->limit_s) {
    return false;
  }
  // points
  if (lhs->points != rhs->points) {
    return false;
  }
  // points_max
  if (lhs->points_max != rhs->points_max) {
    return false;
  }
  // bonus_unlocked
  if (lhs->bonus_unlocked != rhs->bonus_unlocked) {
    return false;
  }
  // alert
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->alert), &(rhs->alert)))
  {
    return false;
  }
  return true;
}

bool
trixanth_interfaces__msg__MissionState__copy(
  const trixanth_interfaces__msg__MissionState * input,
  trixanth_interfaces__msg__MissionState * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // mode
  output->mode = input->mode;
  // mission
  if (!rosidl_runtime_c__String__copy(
      &(input->mission), &(output->mission)))
  {
    return false;
  }
  // stage
  if (!rosidl_runtime_c__String__copy(
      &(input->stage), &(output->stage)))
  {
    return false;
  }
  // running
  output->running = input->running;
  // elapsed_s
  output->elapsed_s = input->elapsed_s;
  // limit_s
  output->limit_s = input->limit_s;
  // points
  output->points = input->points;
  // points_max
  output->points_max = input->points_max;
  // bonus_unlocked
  output->bonus_unlocked = input->bonus_unlocked;
  // alert
  if (!rosidl_runtime_c__String__copy(
      &(input->alert), &(output->alert)))
  {
    return false;
  }
  return true;
}

trixanth_interfaces__msg__MissionState *
trixanth_interfaces__msg__MissionState__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  trixanth_interfaces__msg__MissionState * msg = (trixanth_interfaces__msg__MissionState *)allocator.allocate(sizeof(trixanth_interfaces__msg__MissionState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(trixanth_interfaces__msg__MissionState));
  bool success = trixanth_interfaces__msg__MissionState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
trixanth_interfaces__msg__MissionState__destroy(trixanth_interfaces__msg__MissionState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    trixanth_interfaces__msg__MissionState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
trixanth_interfaces__msg__MissionState__Sequence__init(trixanth_interfaces__msg__MissionState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  trixanth_interfaces__msg__MissionState * data = NULL;

  if (size) {
    data = (trixanth_interfaces__msg__MissionState *)allocator.zero_allocate(size, sizeof(trixanth_interfaces__msg__MissionState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = trixanth_interfaces__msg__MissionState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        trixanth_interfaces__msg__MissionState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
trixanth_interfaces__msg__MissionState__Sequence__fini(trixanth_interfaces__msg__MissionState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      trixanth_interfaces__msg__MissionState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

trixanth_interfaces__msg__MissionState__Sequence *
trixanth_interfaces__msg__MissionState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  trixanth_interfaces__msg__MissionState__Sequence * array = (trixanth_interfaces__msg__MissionState__Sequence *)allocator.allocate(sizeof(trixanth_interfaces__msg__MissionState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = trixanth_interfaces__msg__MissionState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
trixanth_interfaces__msg__MissionState__Sequence__destroy(trixanth_interfaces__msg__MissionState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    trixanth_interfaces__msg__MissionState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
trixanth_interfaces__msg__MissionState__Sequence__are_equal(const trixanth_interfaces__msg__MissionState__Sequence * lhs, const trixanth_interfaces__msg__MissionState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!trixanth_interfaces__msg__MissionState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
trixanth_interfaces__msg__MissionState__Sequence__copy(
  const trixanth_interfaces__msg__MissionState__Sequence * input,
  trixanth_interfaces__msg__MissionState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(trixanth_interfaces__msg__MissionState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    trixanth_interfaces__msg__MissionState * data =
      (trixanth_interfaces__msg__MissionState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!trixanth_interfaces__msg__MissionState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          trixanth_interfaces__msg__MissionState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!trixanth_interfaces__msg__MissionState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
