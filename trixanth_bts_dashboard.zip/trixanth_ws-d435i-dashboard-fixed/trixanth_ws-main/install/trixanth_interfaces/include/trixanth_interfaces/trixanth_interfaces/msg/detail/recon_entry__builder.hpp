// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from trixanth_interfaces:msg/ReconEntry.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "trixanth_interfaces/msg/recon_entry.hpp"


#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__BUILDER_HPP_
#define TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "trixanth_interfaces/msg/detail/recon_entry__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace trixanth_interfaces
{

namespace msg
{

namespace builder
{

class Init_ReconEntry_image_path
{
public:
  explicit Init_ReconEntry_image_path(::trixanth_interfaces::msg::ReconEntry & msg)
  : msg_(msg)
  {}
  ::trixanth_interfaces::msg::ReconEntry image_path(::trixanth_interfaces::msg::ReconEntry::_image_path_type arg)
  {
    msg_.image_path = std::move(arg);
    return std::move(msg_);
  }

private:
  ::trixanth_interfaces::msg::ReconEntry msg_;
};

class Init_ReconEntry_horizontal_accuracy_m
{
public:
  explicit Init_ReconEntry_horizontal_accuracy_m(::trixanth_interfaces::msg::ReconEntry & msg)
  : msg_(msg)
  {}
  Init_ReconEntry_image_path horizontal_accuracy_m(::trixanth_interfaces::msg::ReconEntry::_horizontal_accuracy_m_type arg)
  {
    msg_.horizontal_accuracy_m = std::move(arg);
    return Init_ReconEntry_image_path(msg_);
  }

private:
  ::trixanth_interfaces::msg::ReconEntry msg_;
};

class Init_ReconEntry_altitude
{
public:
  explicit Init_ReconEntry_altitude(::trixanth_interfaces::msg::ReconEntry & msg)
  : msg_(msg)
  {}
  Init_ReconEntry_horizontal_accuracy_m altitude(::trixanth_interfaces::msg::ReconEntry::_altitude_type arg)
  {
    msg_.altitude = std::move(arg);
    return Init_ReconEntry_horizontal_accuracy_m(msg_);
  }

private:
  ::trixanth_interfaces::msg::ReconEntry msg_;
};

class Init_ReconEntry_longitude
{
public:
  explicit Init_ReconEntry_longitude(::trixanth_interfaces::msg::ReconEntry & msg)
  : msg_(msg)
  {}
  Init_ReconEntry_altitude longitude(::trixanth_interfaces::msg::ReconEntry::_longitude_type arg)
  {
    msg_.longitude = std::move(arg);
    return Init_ReconEntry_altitude(msg_);
  }

private:
  ::trixanth_interfaces::msg::ReconEntry msg_;
};

class Init_ReconEntry_latitude
{
public:
  explicit Init_ReconEntry_latitude(::trixanth_interfaces::msg::ReconEntry & msg)
  : msg_(msg)
  {}
  Init_ReconEntry_longitude latitude(::trixanth_interfaces::msg::ReconEntry::_latitude_type arg)
  {
    msg_.latitude = std::move(arg);
    return Init_ReconEntry_longitude(msg_);
  }

private:
  ::trixanth_interfaces::msg::ReconEntry msg_;
};

class Init_ReconEntry_confidence
{
public:
  explicit Init_ReconEntry_confidence(::trixanth_interfaces::msg::ReconEntry & msg)
  : msg_(msg)
  {}
  Init_ReconEntry_latitude confidence(::trixanth_interfaces::msg::ReconEntry::_confidence_type arg)
  {
    msg_.confidence = std::move(arg);
    return Init_ReconEntry_latitude(msg_);
  }

private:
  ::trixanth_interfaces::msg::ReconEntry msg_;
};

class Init_ReconEntry_label
{
public:
  explicit Init_ReconEntry_label(::trixanth_interfaces::msg::ReconEntry & msg)
  : msg_(msg)
  {}
  Init_ReconEntry_confidence label(::trixanth_interfaces::msg::ReconEntry::_label_type arg)
  {
    msg_.label = std::move(arg);
    return Init_ReconEntry_confidence(msg_);
  }

private:
  ::trixanth_interfaces::msg::ReconEntry msg_;
};

class Init_ReconEntry_id
{
public:
  explicit Init_ReconEntry_id(::trixanth_interfaces::msg::ReconEntry & msg)
  : msg_(msg)
  {}
  Init_ReconEntry_label id(::trixanth_interfaces::msg::ReconEntry::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_ReconEntry_label(msg_);
  }

private:
  ::trixanth_interfaces::msg::ReconEntry msg_;
};

class Init_ReconEntry_header
{
public:
  Init_ReconEntry_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ReconEntry_id header(::trixanth_interfaces::msg::ReconEntry::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ReconEntry_id(msg_);
  }

private:
  ::trixanth_interfaces::msg::ReconEntry msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::trixanth_interfaces::msg::ReconEntry>()
{
  return trixanth_interfaces::msg::builder::Init_ReconEntry_header();
}

}  // namespace trixanth_interfaces

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__BUILDER_HPP_
