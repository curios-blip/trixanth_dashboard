// generated from rosidl_typesupport_introspection_c/resource/idl__rosidl_typesupport_introspection_c.h.em
// with input from trixanth_interfaces:msg/ReconEntry.idl
// generated code does not contain a copyright notice

#ifndef TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
#define TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "trixanth_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"

ROSIDL_TYPESUPPORT_INTROSPECTION_C_PUBLIC_trixanth_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, trixanth_interfaces, msg, ReconEntry)();

#ifdef __cplusplus
}
#endif

#endif  // TRIXANTH_INTERFACES__MSG__DETAIL__RECON_ENTRY__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
