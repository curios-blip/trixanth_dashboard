# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(trixanth_interfaces_IDL_FILES "msg/MissionState.idl;msg/Detection.idl;msg/DetectionArray.idl;msg/ReconEntry.idl;msg/MarkerObservation.idl;msg/ScoreEvent.idl;srv/SetMode.idl;srv/StartMission.idl")
set(trixanth_interfaces_INTERFACE_FILES "msg/MissionState.msg;msg/Detection.msg;msg/DetectionArray.msg;msg/ReconEntry.msg;msg/MarkerObservation.msg;msg/ScoreEvent.msg;srv/SetMode.srv;srv/StartMission.srv")
