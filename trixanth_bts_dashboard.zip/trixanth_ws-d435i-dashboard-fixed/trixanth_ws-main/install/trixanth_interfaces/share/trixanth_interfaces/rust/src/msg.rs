#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to trixanth_interfaces__msg__MissionState
/// Published by trixanth_mission/mission_monitor at 2 Hz and on every change.

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MissionState {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mode: u8,

    /// "rado" | "abex" | "idmo" | ""
    pub mission: std::string::String,

    /// e.g. "recon", "delivery", or FSM state name
    pub stage: std::string::String,

    /// mission clock running
    pub running: bool,

    /// seconds since mission start
    pub elapsed_s: f32,

    /// current allowed mission length (25 min, or 15 if the 30% gate failed)
    pub limit_s: f32,

    /// points logged so far (operator-entered, see ScoreEvent)
    pub points: f32,

    /// max points for this mission (from config; UNKNOWN until Table 1.2)
    pub points_max: f32,

    /// true after minute 15 if the 30% gate passed
    pub bonus_unlocked: bool,

    /// human-readable warning for the dashboard, empty when none
    pub alert: std::string::String,

}

impl MissionState {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MODE_IDLE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MODE_MANUAL: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MODE_AUTONOMOUS: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MODE_ESTOP: u8 = 3;

}


impl Default for MissionState {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::MissionState::default())
  }
}

impl rosidl_runtime_rs::Message for MissionState {
  type RmwMsg = super::msg::rmw::MissionState;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        mode: msg.mode,
        mission: msg.mission.as_str().into(),
        stage: msg.stage.as_str().into(),
        running: msg.running,
        elapsed_s: msg.elapsed_s,
        limit_s: msg.limit_s,
        points: msg.points,
        points_max: msg.points_max,
        bonus_unlocked: msg.bonus_unlocked,
        alert: msg.alert.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      mode: msg.mode,
        mission: msg.mission.as_str().into(),
        stage: msg.stage.as_str().into(),
      running: msg.running,
      elapsed_s: msg.elapsed_s,
      limit_s: msg.limit_s,
      points: msg.points,
      points_max: msg.points_max,
      bonus_unlocked: msg.bonus_unlocked,
        alert: msg.alert.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      mode: msg.mode,
      mission: msg.mission.to_string(),
      stage: msg.stage.to_string(),
      running: msg.running,
      elapsed_s: msg.elapsed_s,
      limit_s: msg.limit_s,
      points: msg.points,
      points_max: msg.points_max,
      bonus_unlocked: msg.bonus_unlocked,
      alert: msg.alert.to_string(),
    }
  }
}


// Corresponds to trixanth_interfaces__msg__Detection

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Detection {

    // This member is not documented.
    #[allow(missing_docs)]
    pub label: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub confidence: f32,

    /// Bounding box in image pixels (top-left x/y, width, height)
    pub x: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub w: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub h: i32,

    /// Position in the camera optical frame if depth was available, else NaN
    pub position: geometry_msgs::msg::Point,

}



impl Default for Detection {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Detection::default())
  }
}

impl rosidl_runtime_rs::Message for Detection {
  type RmwMsg = super::msg::rmw::Detection;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        label: msg.label.as_str().into(),
        confidence: msg.confidence,
        x: msg.x,
        y: msg.y,
        w: msg.w,
        h: msg.h,
        position: geometry_msgs::msg::Point::into_rmw_message(std::borrow::Cow::Owned(msg.position)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        label: msg.label.as_str().into(),
      confidence: msg.confidence,
      x: msg.x,
      y: msg.y,
      w: msg.w,
      h: msg.h,
        position: geometry_msgs::msg::Point::into_rmw_message(std::borrow::Cow::Borrowed(&msg.position)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      label: msg.label.to_string(),
      confidence: msg.confidence,
      x: msg.x,
      y: msg.y,
      w: msg.w,
      h: msg.h,
      position: geometry_msgs::msg::Point::from_rmw_message(msg.position),
    }
  }
}


// Corresponds to trixanth_interfaces__msg__DetectionArray

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DetectionArray {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub detections: Vec<super::msg::Detection>,

}



impl Default for DetectionArray {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::DetectionArray::default())
  }
}

impl rosidl_runtime_rs::Message for DetectionArray {
  type RmwMsg = super::msg::rmw::DetectionArray;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        detections: msg.detections
          .into_iter()
          .map(|elem| super::msg::Detection::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        detections: msg.detections
          .iter()
          .map(|elem| super::msg::Detection::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      detections: msg.detections
          .into_iter()
          .map(super::msg::Detection::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to trixanth_interfaces__msg__ReconEntry
/// One documented object from the RADO recon stage (rule 3.3.1).

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ReconEntry {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub id: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub label: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub confidence: f32,

    /// WGS 84, decimal degrees
    pub latitude: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub longitude: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub altitude: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub horizontal_accuracy_m: f32,

    /// saved photo on the rover
    pub image_path: std::string::String,

}



impl Default for ReconEntry {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ReconEntry::default())
  }
}

impl rosidl_runtime_rs::Message for ReconEntry {
  type RmwMsg = super::msg::rmw::ReconEntry;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        id: msg.id,
        label: msg.label.as_str().into(),
        confidence: msg.confidence,
        latitude: msg.latitude,
        longitude: msg.longitude,
        altitude: msg.altitude,
        horizontal_accuracy_m: msg.horizontal_accuracy_m,
        image_path: msg.image_path.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      id: msg.id,
        label: msg.label.as_str().into(),
      confidence: msg.confidence,
      latitude: msg.latitude,
      longitude: msg.longitude,
      altitude: msg.altitude,
      horizontal_accuracy_m: msg.horizontal_accuracy_m,
        image_path: msg.image_path.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      id: msg.id,
      label: msg.label.to_string(),
      confidence: msg.confidence,
      latitude: msg.latitude,
      longitude: msg.longitude,
      altitude: msg.altitude,
      horizontal_accuracy_m: msg.horizontal_accuracy_m,
      image_path: msg.image_path.to_string(),
    }
  }
}


// Corresponds to trixanth_interfaces__msg__MarkerObservation
/// A coloured delivery marker seen by the front camera.

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MarkerObservation {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub colour: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub visible: bool,

    /// + is left of the image centre (REP 103)
    pub bearing_rad: f32,

    /// blob area / image area, a rough proximity cue
    pub area_ratio: f32,

    /// from depth if available, else NaN
    pub range_m: f32,

}



impl Default for MarkerObservation {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::MarkerObservation::default())
  }
}

impl rosidl_runtime_rs::Message for MarkerObservation {
  type RmwMsg = super::msg::rmw::MarkerObservation;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        colour: msg.colour.as_str().into(),
        visible: msg.visible,
        bearing_rad: msg.bearing_rad,
        area_ratio: msg.area_ratio,
        range_m: msg.range_m,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        colour: msg.colour.as_str().into(),
      visible: msg.visible,
      bearing_rad: msg.bearing_rad,
      area_ratio: msg.area_ratio,
      range_m: msg.range_m,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      colour: msg.colour.to_string(),
      visible: msg.visible,
      bearing_rad: msg.bearing_rad,
      area_ratio: msg.area_ratio,
      range_m: msg.range_m,
    }
  }
}


// Corresponds to trixanth_interfaces__msg__ScoreEvent
/// Operator or FSM logs that a sub-task earned points (estimated).

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ScoreEvent {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub task: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points: f32,

}



impl Default for ScoreEvent {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ScoreEvent::default())
  }
}

impl rosidl_runtime_rs::Message for ScoreEvent {
  type RmwMsg = super::msg::rmw::ScoreEvent;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        task: msg.task.as_str().into(),
        points: msg.points,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        task: msg.task.as_str().into(),
      points: msg.points,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      task: msg.task.to_string(),
      points: msg.points,
    }
  }
}


