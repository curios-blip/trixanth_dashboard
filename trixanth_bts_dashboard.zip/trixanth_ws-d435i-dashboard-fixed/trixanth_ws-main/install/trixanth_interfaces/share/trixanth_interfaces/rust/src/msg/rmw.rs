#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "trixanth_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__trixanth_interfaces__msg__MissionState() -> *const std::ffi::c_void;
}

#[link(name = "trixanth_interfaces__rosidl_generator_c")]
extern "C" {
    fn trixanth_interfaces__msg__MissionState__init(msg: *mut MissionState) -> bool;
    fn trixanth_interfaces__msg__MissionState__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<MissionState>, size: usize) -> bool;
    fn trixanth_interfaces__msg__MissionState__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<MissionState>);
    fn trixanth_interfaces__msg__MissionState__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<MissionState>, out_seq: *mut rosidl_runtime_rs::Sequence<MissionState>) -> bool;
}

// Corresponds to trixanth_interfaces__msg__MissionState
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// Published by trixanth_mission/mission_monitor at 2 Hz and on every change.

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MissionState {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mode: u8,

    /// "rado" | "abex" | "idmo" | ""
    pub mission: rosidl_runtime_rs::String,

    /// e.g. "recon", "delivery", or FSM state name
    pub stage: rosidl_runtime_rs::String,

    /// mission clock running
    pub running: bool,

    /// seconds since mission start
    pub elapsed_s: f32,

    /// current allowed mission length (25 min, or 15 if the 30% gate failed)
    pub limit_s: f32,

    /// points logged so far (operator-entered, see ScoreEvent)
    pub points: f32,

    /// max points for this mission (from config; UNKNOWN until Table 1.2)
    pub points_max: f32,

    /// true after minute 15 if the 30% gate passed
    pub bonus_unlocked: bool,

    /// human-readable warning for the dashboard, empty when none
    pub alert: rosidl_runtime_rs::String,

}

impl MissionState {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MODE_IDLE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MODE_MANUAL: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MODE_AUTONOMOUS: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MODE_ESTOP: u8 = 3;

}


impl Default for MissionState {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !trixanth_interfaces__msg__MissionState__init(&mut msg as *mut _) {
        panic!("Call to trixanth_interfaces__msg__MissionState__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for MissionState {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__MissionState__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__MissionState__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__MissionState__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for MissionState {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for MissionState where Self: Sized {
  const TYPE_NAME: &'static str = "trixanth_interfaces/msg/MissionState";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__trixanth_interfaces__msg__MissionState() }
  }
}


#[link(name = "trixanth_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__trixanth_interfaces__msg__Detection() -> *const std::ffi::c_void;
}

#[link(name = "trixanth_interfaces__rosidl_generator_c")]
extern "C" {
    fn trixanth_interfaces__msg__Detection__init(msg: *mut Detection) -> bool;
    fn trixanth_interfaces__msg__Detection__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Detection>, size: usize) -> bool;
    fn trixanth_interfaces__msg__Detection__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Detection>);
    fn trixanth_interfaces__msg__Detection__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Detection>, out_seq: *mut rosidl_runtime_rs::Sequence<Detection>) -> bool;
}

// Corresponds to trixanth_interfaces__msg__Detection
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Detection {

    // This member is not documented.
    #[allow(missing_docs)]
    pub label: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub confidence: f32,

    /// Bounding box in image pixels (top-left x/y, width, height)
    pub x: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub w: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub h: i32,

    /// Position in the camera optical frame if depth was available, else NaN
    pub position: geometry_msgs::msg::rmw::Point,

}



impl Default for Detection {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !trixanth_interfaces__msg__Detection__init(&mut msg as *mut _) {
        panic!("Call to trixanth_interfaces__msg__Detection__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Detection {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__Detection__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__Detection__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__Detection__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Detection {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Detection where Self: Sized {
  const TYPE_NAME: &'static str = "trixanth_interfaces/msg/Detection";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__trixanth_interfaces__msg__Detection() }
  }
}


#[link(name = "trixanth_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__trixanth_interfaces__msg__DetectionArray() -> *const std::ffi::c_void;
}

#[link(name = "trixanth_interfaces__rosidl_generator_c")]
extern "C" {
    fn trixanth_interfaces__msg__DetectionArray__init(msg: *mut DetectionArray) -> bool;
    fn trixanth_interfaces__msg__DetectionArray__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<DetectionArray>, size: usize) -> bool;
    fn trixanth_interfaces__msg__DetectionArray__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<DetectionArray>);
    fn trixanth_interfaces__msg__DetectionArray__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<DetectionArray>, out_seq: *mut rosidl_runtime_rs::Sequence<DetectionArray>) -> bool;
}

// Corresponds to trixanth_interfaces__msg__DetectionArray
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DetectionArray {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub detections: rosidl_runtime_rs::Sequence<super::super::msg::rmw::Detection>,

}



impl Default for DetectionArray {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !trixanth_interfaces__msg__DetectionArray__init(&mut msg as *mut _) {
        panic!("Call to trixanth_interfaces__msg__DetectionArray__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for DetectionArray {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__DetectionArray__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__DetectionArray__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__DetectionArray__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for DetectionArray {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for DetectionArray where Self: Sized {
  const TYPE_NAME: &'static str = "trixanth_interfaces/msg/DetectionArray";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__trixanth_interfaces__msg__DetectionArray() }
  }
}


#[link(name = "trixanth_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__trixanth_interfaces__msg__ReconEntry() -> *const std::ffi::c_void;
}

#[link(name = "trixanth_interfaces__rosidl_generator_c")]
extern "C" {
    fn trixanth_interfaces__msg__ReconEntry__init(msg: *mut ReconEntry) -> bool;
    fn trixanth_interfaces__msg__ReconEntry__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ReconEntry>, size: usize) -> bool;
    fn trixanth_interfaces__msg__ReconEntry__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ReconEntry>);
    fn trixanth_interfaces__msg__ReconEntry__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ReconEntry>, out_seq: *mut rosidl_runtime_rs::Sequence<ReconEntry>) -> bool;
}

// Corresponds to trixanth_interfaces__msg__ReconEntry
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// One documented object from the RADO recon stage (rule 3.3.1).

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ReconEntry {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub id: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub label: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub confidence: f32,

    /// WGS 84, decimal degrees
    pub latitude: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub longitude: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub altitude: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub horizontal_accuracy_m: f32,

    /// saved photo on the rover
    pub image_path: rosidl_runtime_rs::String,

}



impl Default for ReconEntry {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !trixanth_interfaces__msg__ReconEntry__init(&mut msg as *mut _) {
        panic!("Call to trixanth_interfaces__msg__ReconEntry__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ReconEntry {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__ReconEntry__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__ReconEntry__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__ReconEntry__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ReconEntry {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ReconEntry where Self: Sized {
  const TYPE_NAME: &'static str = "trixanth_interfaces/msg/ReconEntry";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__trixanth_interfaces__msg__ReconEntry() }
  }
}


#[link(name = "trixanth_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__trixanth_interfaces__msg__MarkerObservation() -> *const std::ffi::c_void;
}

#[link(name = "trixanth_interfaces__rosidl_generator_c")]
extern "C" {
    fn trixanth_interfaces__msg__MarkerObservation__init(msg: *mut MarkerObservation) -> bool;
    fn trixanth_interfaces__msg__MarkerObservation__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<MarkerObservation>, size: usize) -> bool;
    fn trixanth_interfaces__msg__MarkerObservation__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<MarkerObservation>);
    fn trixanth_interfaces__msg__MarkerObservation__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<MarkerObservation>, out_seq: *mut rosidl_runtime_rs::Sequence<MarkerObservation>) -> bool;
}

// Corresponds to trixanth_interfaces__msg__MarkerObservation
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// A coloured delivery marker seen by the front camera.

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MarkerObservation {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub colour: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub visible: bool,

    /// + is left of the image centre (REP 103)
    pub bearing_rad: f32,

    /// blob area / image area, a rough proximity cue
    pub area_ratio: f32,

    /// from depth if available, else NaN
    pub range_m: f32,

}



impl Default for MarkerObservation {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !trixanth_interfaces__msg__MarkerObservation__init(&mut msg as *mut _) {
        panic!("Call to trixanth_interfaces__msg__MarkerObservation__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for MarkerObservation {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__MarkerObservation__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__MarkerObservation__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__MarkerObservation__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for MarkerObservation {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for MarkerObservation where Self: Sized {
  const TYPE_NAME: &'static str = "trixanth_interfaces/msg/MarkerObservation";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__trixanth_interfaces__msg__MarkerObservation() }
  }
}


#[link(name = "trixanth_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__trixanth_interfaces__msg__ScoreEvent() -> *const std::ffi::c_void;
}

#[link(name = "trixanth_interfaces__rosidl_generator_c")]
extern "C" {
    fn trixanth_interfaces__msg__ScoreEvent__init(msg: *mut ScoreEvent) -> bool;
    fn trixanth_interfaces__msg__ScoreEvent__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ScoreEvent>, size: usize) -> bool;
    fn trixanth_interfaces__msg__ScoreEvent__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ScoreEvent>);
    fn trixanth_interfaces__msg__ScoreEvent__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ScoreEvent>, out_seq: *mut rosidl_runtime_rs::Sequence<ScoreEvent>) -> bool;
}

// Corresponds to trixanth_interfaces__msg__ScoreEvent
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// Operator or FSM logs that a sub-task earned points (estimated).

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ScoreEvent {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub task: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub points: f32,

}



impl Default for ScoreEvent {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !trixanth_interfaces__msg__ScoreEvent__init(&mut msg as *mut _) {
        panic!("Call to trixanth_interfaces__msg__ScoreEvent__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ScoreEvent {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__ScoreEvent__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__ScoreEvent__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { trixanth_interfaces__msg__ScoreEvent__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ScoreEvent {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ScoreEvent where Self: Sized {
  const TYPE_NAME: &'static str = "trixanth_interfaces/msg/ScoreEvent";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__trixanth_interfaces__msg__ScoreEvent() }
  }
}


