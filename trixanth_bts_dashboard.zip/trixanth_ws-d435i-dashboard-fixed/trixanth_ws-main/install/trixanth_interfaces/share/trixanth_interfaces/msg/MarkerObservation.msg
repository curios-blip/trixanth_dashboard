# A coloured delivery marker seen by the front camera.
std_msgs/Header header
string colour
bool visible
float32 bearing_rad     # + is left of the image centre (REP 103)
float32 area_ratio      # blob area / image area, a rough proximity cue
float32 range_m         # from depth if available, else NaN
