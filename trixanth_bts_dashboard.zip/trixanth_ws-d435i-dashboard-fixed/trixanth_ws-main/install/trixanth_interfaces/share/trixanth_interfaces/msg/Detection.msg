string label
float32 confidence
# Bounding box in image pixels (top-left x/y, width, height)
int32 x
int32 y
int32 w
int32 h
# Position in the camera optical frame if depth was available, else NaN
geometry_msgs/Point position
