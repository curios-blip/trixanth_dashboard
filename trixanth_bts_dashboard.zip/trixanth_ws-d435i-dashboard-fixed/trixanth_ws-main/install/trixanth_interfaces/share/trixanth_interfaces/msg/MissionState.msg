# Published by trixanth_mission/mission_monitor at 2 Hz and on every change.
uint8 MODE_IDLE=0
uint8 MODE_MANUAL=1
uint8 MODE_AUTONOMOUS=2
uint8 MODE_ESTOP=3

std_msgs/Header header
uint8 mode
string mission          # "rado" | "abex" | "idmo" | ""
string stage            # e.g. "recon", "delivery", or FSM state name
bool running            # mission clock running
float32 elapsed_s       # seconds since mission start
float32 limit_s         # current allowed mission length (25 min, or 15 if the 30% gate failed)
float32 points          # points logged so far (operator-entered, see ScoreEvent)
float32 points_max      # max points for this mission (from config; UNKNOWN until Table 1.2)
bool bonus_unlocked     # true after minute 15 if the 30% gate passed
string alert            # human-readable warning for the dashboard, empty when none
