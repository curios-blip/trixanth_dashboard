# One documented object from the RADO recon stage (rule 3.3.1).
std_msgs/Header header
uint32 id
string label
float32 confidence
float64 latitude        # WGS 84, decimal degrees
float64 longitude
float64 altitude
float32 horizontal_accuracy_m
string image_path       # saved photo on the rover
