# Operator or FSM logs that a sub-task earned points (estimated).
std_msgs/Header header
string task
float32 points
