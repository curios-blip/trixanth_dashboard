# trixanth_ws

ROS 2 Jazzy workspace for **Team Trixanth**, SPROS International Rover Challenge 2027. One package per job, so each subsystem can be built, tested and replaced on its own.

## Packages

| Package | Job | Main nodes / files |
| --- | --- | --- |
| `trixanth_interfaces` | Custom messages and services | `MissionState`, `DetectionArray`, `ReconEntry`, `MarkerObservation`, `ScoreEvent`, `SetMode`, `StartMission` |
| `trixanth_description` | Robot model | **Add your URDF** as `urdf/trixanth.urdf.xacro` (frames and sim plugins listed in `urdf/README.md`) |
| `trixanth_hardware` | Teensy and ESP32 serial bridges, GPS driver, udev rules | `base_bridge`, `sensor_bridge` |
| `trixanth_localization` | Dual EKF + navsat_transform | `config/ekf.yaml` |
| `trixanth_navigation` | Nav2 (SMAC Hybrid-A*, MPPI), GPS goals | `config/nav2_params.yaml`, `gps_goal` |
| `trixanth_obstacle_avoidance` | Rocks, drops and slopes from depth; collision monitor | `traversability_node`, `config/collision_monitor.yaml` |
| `trixanth_red_zone` | Red no-go zones as lethal costmap obstacles (rule 3.0) | `red_zone_node` |
| `trixanth_perception` | YOLOv8n objects, delivery-marker colour | `object_detector`, `marker_detector` |
| `trixanth_comms` | Mode owner, manual/autonomous command lockout, link heartbeat | `command_gate`, `link_monitor`, `ground_heartbeat` |
| `trixanth_mission` | IRC timing rules, RADO delivery FSM, recon logging | `mission_monitor`, `rado_fsm`, `recon_logger` |
| `trixanth_science` | ABEx site logs, annotated panoramas, mission report | `site_logger`, `panorama`, `abex_report` |
| `trixanth_sim` | Gazebo Harmonic test field with ramps, drops, red zones, markers | `worlds/sproscape_lite.sdf`, `sim.launch.py` |
| `trixanth_dashboard` | Ground-station web dashboard, its launch manager and web server | `dashboard.launch.py`, `launch_manager`, `web_server` |
| `trixanth_bringup` | One launch file per mission | `rado`, `abex`, `idmo`, `robot`, `sim_rado` |

`firmware/` holds the Teensy 4.1 and ESP32 sketches (Arduino/Teensyduino). It sits outside `src/` so colcon ignores it.

## Setup

```bash
# ROS 2 Jazzy on Ubuntu 24.04 (Jetson: JetPack 6 + Jazzy from source or a container)
sudo apt install python3-colcon-common-extensions python3-rosdep ros-jazzy-navigation2 ros-jazzy-nav2-bringup \
  ros-jazzy-robot-localization ros-jazzy-nmea-navsat-driver ros-jazzy-realsense2-camera \
  ros-jazzy-rosbridge-server ros-jazzy-ros-gz ros-jazzy-xacro ros-jazzy-cv-bridge
pip install -r requirements.txt

cd ~/trixanth_ws    # this repo's root
rosdep install --from-paths src --ignore-src -y
colcon build --symlink-install
source install/setup.bash
```

On the Jetson, also set `export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST` in `~/.bashrc` (see CONNECTIONS.md).

## Run

```bash
ros2 launch trixanth_bringup sim_rado.launch.py     # simulation (needs your URDF)
ros2 launch trixanth_bringup rado.launch.py deliveries_file:=/path/to/today.yaml
ros2 launch trixanth_bringup abex.launch.py
ros2 launch trixanth_bringup idmo.launch.py
```

RADO delivery, per object: pick up in MANUAL → `ros2 service call /rado/start_delivery std_srvs/srv/Trigger` → the rover switches itself to AUTONOMOUS (the team leader tells the judge) → drives, finds the marker, places, backs off → returns to MANUAL.

## Interfaces other teams plug into

- **Arm (manipulation team):** subscribe `/arm/command` (`std_msgs/String`, `"place"`), publish `/arm/status` `"done"` when finished.
- **Dashboard:** via rosbridge. Publish `/ground/heartbeat` at 5 Hz and joystick on `/cmd_vel_teleop`. Show `/mission/state`, `/mission/alert`, `/trixanth/mode_event` (with a sound), `/rado/status`, `/recon/entry`. Call `/set_mode`, `/mission/start`, `/rado/start_delivery`, `/recon/capture`, `/abex/*`.

## Placeholders to replace

- Robot dimensions and footprint: `nav2_params.yaml` and `collision_monitor.yaml` (keep them in sync with the URDF).
- Wheel radius, track width, encoder ticks: `trixanth_hardware/config/hardware.yaml` and the Teensy firmware.
- Hardware parts marked **(assumed)** in CONNECTIONS.md.
- Marker colour presets once the official colours are released: `trixanth_perception/colour.py`.
- YOLO model path: `trixanth_perception/config/perception.yaml`.

See **TESTING.md** for what to test and how, and **CONNECTIONS.md** for wiring.

