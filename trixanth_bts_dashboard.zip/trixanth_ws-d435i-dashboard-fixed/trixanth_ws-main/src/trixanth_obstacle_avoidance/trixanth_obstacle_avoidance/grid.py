"""Pure-numpy terrain classification, kept free of ROS so it can be unit tested."""
import numpy as np


def quat_to_matrix(x, y, z, w):
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def classify(points, cell=0.1, step_max=0.20, drop_max=0.30, slope_max_deg=25.0,
             min_points=3, x_range=(0.3, 8.0), y_half=4.0):
    """Return (N, 2) array of obstacle cell centres (x, y) in the same frame as `points`.

    points : (N, 3) array in a robot-aligned frame with z up and ground near z=0.
    A cell is an obstacle if:
      - its height spread (max - min) is above step_max         -> rock, boulder, step
      - its mean height is below -drop_max                      -> drop, hole, crater
      - the height difference to a neighbouring cell implies a slope above slope_max_deg
    """
    if points.size == 0:
        return np.empty((0, 2))
    p = points[(points[:, 0] > x_range[0]) & (points[:, 0] < x_range[1]) & (np.abs(points[:, 1]) < y_half)]
    if p.size == 0:
        return np.empty((0, 2))

    nx = int(np.ceil((x_range[1] - x_range[0]) / cell))
    ny = int(np.ceil(2 * y_half / cell))
    ix = np.clip(((p[:, 0] - x_range[0]) / cell).astype(int), 0, nx - 1)
    iy = np.clip(((p[:, 1] + y_half) / cell).astype(int), 0, ny - 1)
    flat = ix * ny + iy

    count = np.bincount(flat, minlength=nx * ny)
    zsum = np.bincount(flat, weights=p[:, 2], minlength=nx * ny)
    zmax = np.full(nx * ny, -np.inf)
    zmin = np.full(nx * ny, np.inf)
    np.maximum.at(zmax, flat, p[:, 2])
    np.minimum.at(zmin, flat, p[:, 2])

    valid = count >= min_points
    mean = np.where(valid, zsum / np.maximum(count, 1), np.nan)

    obstacle = np.zeros(nx * ny, dtype=bool)
    obstacle |= valid & ((zmax - zmin) > step_max)
    obstacle |= valid & (mean < -drop_max)

    # slope between neighbouring cells (x and y directions)
    m = mean.reshape(nx, ny)
    tan_max = np.tan(np.radians(slope_max_deg))
    with np.errstate(invalid="ignore"):
        gx = np.abs(np.diff(m, axis=0)) / cell
        gy = np.abs(np.diff(m, axis=1)) / cell
    steep = np.zeros((nx, ny), dtype=bool)
    sx = np.nan_to_num(gx, nan=0.0) > tan_max
    sy = np.nan_to_num(gy, nan=0.0) > tan_max
    steep[1:, :] |= sx
    steep[:-1, :] |= sx
    steep[:, 1:] |= sy
    steep[:, :-1] |= sy
    obstacle |= steep.reshape(-1) & valid

    idx = np.nonzero(obstacle)[0]
    cx = x_range[0] + (idx // ny + 0.5) * cell
    cy = -y_half + (idx % ny + 0.5) * cell
    return np.stack([cx, cy], axis=1)
