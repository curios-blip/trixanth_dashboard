"""Depth point cloud -> obstacle points for the Nav2 costmap and the collision monitor.

Subscribes  input cloud  (default /camera/depth/color/points, any frame)
Publishes   /traversability/obstacles (PointCloud2 in base_footprint, one point per obstacle cell, z = 0.1)

Catches rocks/steps (height spread), drops/holes (below ground) and slopes above the limit.
Tune the thresholds on analogue terrain; values below are starting points.
"""
import numpy as np
import rclpy
from rclpy.duration import Duration
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import PointCloud2
from sensor_msgs_py import point_cloud2
from std_msgs.msg import Header
from tf2_ros import Buffer, TransformException, TransformListener

from trixanth_obstacle_avoidance.grid import classify, quat_to_matrix


class Traversability(Node):
    def __init__(self):
        super().__init__("traversability")
        self.declare_parameter("input_topic", "/camera/depth/color/points")
        self.declare_parameter("target_frame", "base_footprint")
        self.declare_parameter("cell", 0.10)
        self.declare_parameter("step_max", 0.20)        # m, taller than this = rock/step
        self.declare_parameter("drop_max", 0.30)        # m, deeper than this = drop/hole
        self.declare_parameter("slope_max_deg", 25.0)
        self.declare_parameter("min_points", 3)
        self.declare_parameter("max_range", 8.0)
        self.declare_parameter("stride", 4)             # use every Nth point (Orin Nano CPU budget)

        g = self.get_parameter
        self.target = g("target_frame").value
        self.cfg = dict(cell=g("cell").value, step_max=g("step_max").value, drop_max=g("drop_max").value,
                        slope_max_deg=g("slope_max_deg").value, min_points=g("min_points").value,
                        x_range=(0.3, g("max_range").value))
        self.stride = max(1, int(g("stride").value))

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.pub = self.create_publisher(PointCloud2, "traversability/obstacles", 5)
        self.create_subscription(PointCloud2, g("input_topic").value, self.on_cloud, qos_profile_sensor_data)

    def on_cloud(self, msg: PointCloud2):
        try:
            t = self.tf_buffer.lookup_transform(self.target, msg.header.frame_id, msg.header.stamp,
                                                timeout=Duration(seconds=0.05))
        except TransformException as e:
            self.get_logger().warn(f"TF: {e}", throttle_duration_sec=2.0)
            return
        pts = point_cloud2.read_points_numpy(msg, field_names=("x", "y", "z"), skip_nans=True)
        if pts.size == 0:
            return
        pts = pts[:: self.stride].astype(np.float64)
        q = t.transform.rotation
        tr = t.transform.translation
        pts = pts @ quat_to_matrix(q.x, q.y, q.z, q.w).T + np.array([tr.x, tr.y, tr.z])

        cells = classify(pts, **self.cfg)
        out = np.zeros((len(cells), 3), dtype=np.float32)
        if len(cells):
            out[:, :2] = cells
            out[:, 2] = 0.1
        header = Header(stamp=msg.header.stamp, frame_id=self.target)
        self.pub.publish(point_cloud2.create_cloud_xyz32(header, out.tolist()))


def main():
    rclpy.init()
    node = Traversability()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
