# trixanth_obstacle_avoidance

Finds rocks, drops and steep slopes in the depth camera's point cloud, and runs Nav2's collision monitor as the last safety check on autonomous commands.

## `traversability_node`

| Direction | Topic | Type |
| --- | --- | --- |
| Sub | `/camera/depth/color/points` (param `input_topic`) | `PointCloud2` |
| Pub | `/traversability/obstacles` | `PointCloud2` in `base_footprint`, one point per obstacle cell at z = 0.1 |

Points are transformed to `base_footprint` and binned into a grid. A cell is an obstacle when:

| Hazard | Test | Parameter (default) |
| --- | --- | --- |
| Rock, boulder, step | height spread inside the cell | `step_max` (0.20 m) |
| Drop, hole, crater | cell mean below ground | `drop_max` (0.30 m) |
| Steep slope | height change to a neighbouring cell | `slope_max_deg` (25°) |

Other parameters: `cell` (0.10 m), `min_points` (3), `max_range` (8 m), `stride` (4; use every Nth point to save CPU).

The logic is in `grid.py` with no ROS imports, so it is unit-tested directly.

**Limit:** a drop edge that the camera cannot see into (no returns past the edge) is not marked by the drop test. Mount the camera high and tilted down, and test against a real ledge (TESTING.md F3).

## `collision_monitor` (Nav2)

`cmd_vel_smoothed → cmd_vel_auto`. Stops inside `StopZone` and slows to 40% inside `SlowZone` when traversability or red-zone points appear there. It only guards **autonomous** commands; teleop goes straight to `command_gate`. The `rado_fsm` marker approach also bypasses it on purpose (otherwise the marker post would stop the rover).

## Launch

```bash
ros2 launch trixanth_obstacle_avoidance obstacle_avoidance.launch.py [use_sim_time:=true] [cloud_topic:=...]
```

## Tune and test

```bash
colcon test --packages-select trixanth_obstacle_avoidance   # flat, rock, hole, gentle slope
```

In RViz show `/traversability/obstacles` over the camera cloud. On analogue terrain (TESTING.md F3), lower `step_max` until real rocks mark, then raise it until loose sand and small pebbles stop marking.
