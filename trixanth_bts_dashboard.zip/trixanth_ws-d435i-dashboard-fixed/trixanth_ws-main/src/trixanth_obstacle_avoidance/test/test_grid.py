import numpy as np

from trixanth_obstacle_avoidance.grid import classify


def flat_ground(n=4000, seed=0):
    rng = np.random.default_rng(seed)
    x = rng.uniform(0.5, 6.0, n)
    y = rng.uniform(-3.0, 3.0, n)
    z = rng.normal(0.0, 0.01, n)
    return np.stack([x, y, z], axis=1)


def test_flat_ground_is_free():
    assert len(classify(flat_ground())) == 0


def test_rock_is_obstacle():
    pts = flat_ground()
    rock = np.array([[3.05, 0.05, h] for h in np.linspace(0.0, 0.4, 20)])
    cells = classify(np.vstack([pts, rock]))
    assert any(abs(c[0] - 3.05) < 0.1 and abs(c[1] - 0.05) < 0.1 for c in cells)


def test_hole_is_obstacle():
    pts = flat_ground()
    hole = np.array([[2.05, -1.05, -0.6]] * 10)
    keep = ~((np.abs(pts[:, 0] - 2.05) < 0.05) & (np.abs(pts[:, 1] + 1.05) < 0.05))
    cells = classify(np.vstack([pts[keep], hole]))
    assert any(abs(c[0] - 2.05) < 0.1 and abs(c[1] + 1.05) < 0.1 for c in cells)


def test_gentle_slope_is_free():
    pts = flat_ground()
    pts[:, 2] = pts[:, 0] * np.tan(np.radians(10))   # 10 degree ramp
    assert len(classify(pts, slope_max_deg=25.0)) == 0
