"""Traversability extraction + Nav2 collision monitor."""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    cfg = PathJoinSubstitution([FindPackageShare("trixanth_obstacle_avoidance"), "config", "collision_monitor.yaml"])
    sim = LaunchConfiguration("use_sim_time")
    cloud = LaunchConfiguration("cloud_topic")
    return LaunchDescription([
        DeclareLaunchArgument("use_sim_time", default_value="false"),
        DeclareLaunchArgument("cloud_topic", default_value="/camera/depth/color/points"),
        Node(package="trixanth_obstacle_avoidance", executable="traversability_node", name="traversability",
             parameters=[cfg, {"use_sim_time": sim, "input_topic": cloud}], output="screen"),
        Node(package="nav2_collision_monitor", executable="collision_monitor", name="collision_monitor",
             parameters=[cfg, {"use_sim_time": sim}], output="screen"),
        Node(package="nav2_lifecycle_manager", executable="lifecycle_manager", name="lifecycle_manager_safety",
             parameters=[{"use_sim_time": sim, "autostart": True, "node_names": ["collision_monitor"]}],
             output="screen"),
    ])
