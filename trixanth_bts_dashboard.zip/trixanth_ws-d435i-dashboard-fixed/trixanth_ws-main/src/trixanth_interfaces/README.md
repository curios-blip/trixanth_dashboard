# trixanth_interfaces

Custom messages and services shared by every Trixanth package. This is the only CMake package in the workspace; everything else is `ament_python`.

## Messages

| Message | Published by | Used by | Purpose |
| --- | --- | --- | --- |
| `MissionState` | `mission_monitor` (2 Hz) | dashboard, `recon_logger` | Mission clock, stage, points, 30% gate, bonus unlock, latest alert |
| `Detection` | (inside `DetectionArray`) | | One object: label, confidence, bounding box, camera-frame position (NaN if no depth) |
| `DetectionArray` | `object_detector` | `recon_logger` | All detections in one image |
| `ReconEntry` | `recon_logger` | dashboard | One documented recon object: label, WGS 84 position, accuracy, saved photo path |
| `MarkerObservation` | `marker_detector` | `rado_fsm` | Delivery marker: visible, bearing (+ left), blob area ratio, range |
| `ScoreEvent` | dashboard / operator | `mission_monitor` | Points the judge just awarded (operator-entered estimate) |

Mode constants (in `MissionState` and `SetMode`): `IDLE=0`, `MANUAL=1`, `AUTONOMOUS=2`, `ESTOP=3`.

## Services

| Service | Server | Purpose |
| --- | --- | --- |
| `SetMode` | `command_gate` at `/set_mode` | Change drive mode; refused when unsafe (kill open, ESTOP straight to AUTONOMOUS) |
| `StartMission` | `mission_monitor` at `/mission/start` | Start the mission clock for `rado`, `abex` or `idmo`; `points_max` 0 if unknown |

## Build and check

```bash
colcon build --packages-select trixanth_interfaces
source install/setup.bash
ros2 interface show trixanth_interfaces/msg/MissionState
```

## Changing a message

Changing a field breaks every node and the dashboard that uses it. Rebuild the whole workspace afterwards (`colcon build`), and update the dashboard's rosbridge message handling at the same time.
