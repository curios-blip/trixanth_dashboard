from trixanth_mission.approach import approach_cmd
from trixanth_mission.mission_clock import MissionClock


def run(clock, seconds, step=1.0):
    alerts = []
    t = 0.0
    while t < seconds:
        alerts += clock.advance(step)
        t += step
    return alerts


def test_zero_points_aborts_at_7():
    c = MissionClock(mission="ido", points_max=100)
    run(c, 7 * 60)
    assert c.aborted and c.finished


def test_any_points_before_7_avoids_abort():
    c = MissionClock(points_max=100)
    run(c, 3 * 60)
    c.add_points(5)
    run(c, 5 * 60)
    assert not c.aborted


def test_exactly_30_percent_stops_at_15():
    c = MissionClock(points_max=100)
    c.add_points(30)               # rule says MORE than 30%
    run(c, 15 * 60)
    assert c.stopped_at_gate and c.finished and c.limit == 15 * 60


def test_above_30_percent_keeps_full_time_and_unlocks_bonus():
    c = MissionClock(points_max=100)
    c.add_points(31)
    run(c, 15 * 60)
    assert not c.stopped_at_gate and c.bonus_unlocked and c.limit == 25 * 60


def test_comms_penalty_halves_time():
    c = MissionClock(points_max=100, comms_penalty=True)
    assert c.limit == 12.5 * 60


def test_rado_stage_switch():
    c = MissionClock(mission="rado", points_max=100)
    c.add_points(40)
    assert c.stage() == "recon"
    alerts = run(c, 10 * 60)
    assert c.stage() == "delivery"
    assert any("recon over" in a for a in alerts)


def test_approach_turns_toward_marker_and_stops():
    v, w, done = approach_cmd(True, 0.3, 3.0, 0.02)
    assert w > 0 and v > 0 and not done
    v, w, done = approach_cmd(True, 0.0, 0.7, 0.05)
    assert done and v == 0
    v, w, done = approach_cmd(False, 0.0, float("nan"), 0.0)
    assert v == 0 and w == 0 and not done
