"""Mission monitor always; RADO FSM and recon logger when mission:=rado."""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import LaunchConfigurationEquals
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    share = FindPackageShare("trixanth_mission")
    cfg = PathJoinSubstitution([share, "config", "mission.yaml"])
    sim = LaunchConfiguration("use_sim_time")
    rado = LaunchConfigurationEquals("mission", "rado")
    return LaunchDescription([
        DeclareLaunchArgument("use_sim_time", default_value="false"),
        DeclareLaunchArgument("mission", default_value="rado", description="rado | abex | idmo"),
        DeclareLaunchArgument("deliveries_file",
                              default_value=PathJoinSubstitution([share, "config", "rado_deliveries.yaml"])),
        Node(package="trixanth_mission", executable="mission_monitor", parameters=[{"use_sim_time": sim}],
             output="screen"),
        Node(package="trixanth_mission", executable="rado_fsm", condition=rado, output="screen",
             parameters=[cfg, {"use_sim_time": sim, "deliveries_file": LaunchConfiguration("deliveries_file")}]),
        Node(package="trixanth_mission", executable="recon_logger", condition=rado, output="screen",
             parameters=[cfg, {"use_sim_time": sim}]),
    ])
