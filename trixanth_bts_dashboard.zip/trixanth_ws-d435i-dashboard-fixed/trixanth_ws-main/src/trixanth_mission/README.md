# trixanth_mission

Mission-level logic: the IRC timing rules, the RADO autonomous delivery state machine and recon documentation.

## `mission_monitor`

Tracks the rules in section 3.0 and warns operators before they bite.

| Rule | What the monitor does |
| --- | --- |
| 25 min per field mission | Clock and limit in `/mission/state` |
| No points in the first 7 min → abort | Warns at 5:00, marks aborted at 7:00 |
| **More than** 30% by 15 min, else stop at 15 | Warns at 12:00 with points still needed; exactly 30% fails |
| Bonus tasks only after 15 min | `bonus_unlocked` in the state |
| Comms penalty | `/mission/comms_penalty` halves the limit to 12:30 |
| RADO: 10 min recon, then 15 min delivery | `stage` switches `recon` → `delivery` |

| Interface | Name | Type |
| --- | --- | --- |
| Service | `/mission/start` | `StartMission` (`mission`, `points_max`; 0 = unknown) |
| Service | `/mission/stop`, `/mission/comms_penalty` | `std_srvs/Trigger` |
| Sub | `/mission/score` | `ScoreEvent` (operator logs points as the judge awards them) |
| Pub | `/mission/state` | `MissionState`, 2 Hz |
| Pub | `/mission/alert` | `String` for dashboard pop-ups |

Until Table 1.2 (points) is known, `points_max` is a guess and the 30% gate is only a warning. Rules live in `mission_clock.py` (unit-tested).

## `rado_fsm`

One autonomous delivery per service call. The operator picks the object up in MANUAL, then calls `/rado/start_delivery`; that is the last command sent.

```
IDLE → RESOLVE (lat/lon → map via /fromLL) → NAVIGATE (Nav2, 1 retry) → SEARCH (rotate until marker seen)
     → APPROACH (visual servo) → PLACE (/arm/command "place", wait /arm/status "done") → BACKOFF → DONE
any failure → FAILED; mode goes back to MANUAL so operators can finish (50% of delivery points)
```

| Interface | Name | Notes |
| --- | --- | --- |
| Service | `/rado/start_delivery` | Next pending delivery; must be in MANUAL |
| Service | `/rado/list` | Pending / done list |
| Service | `/rado/abort` | Testing and safety only; calling it in a scored autonomous run is a command |
| Pub | `/cmd_vel_auto` | During SEARCH, APPROACH, BACKOFF (bypasses the collision monitor so the marker post doesn't stop it) |
| Pub | `/rado/status`, `/arm/command` | |
| Sub | `/perception/marker`, `/arm/status`, `/trixanth/mode` | Leaving AUTONOMOUS (e.g. ESTOP) fails the delivery |

Deliveries come from a YAML file filled in at the briefing (`config/rado_deliveries.yaml`):

```yaml
deliveries:
  - {name: D1, lat: 12.6615, lon: 77.4500, marker: blue}
```

Parameters (`config/mission.yaml`): `nav_retries`, `search_turn_rate`, `marker_lost_timeout`, `stop_range` (0.8 m), `place_timeout` (20 s), `backoff_speed`, `backoff_time`. Approach control is in `approach.py` (unit-tested).

## `recon_logger`

During the `recon` stage, logs every new detection above `min_confidence` once (duplicates within `dedupe_radius_m` of the same label are skipped). Each entry gets a JPEG with the box and coordinates, a CSV row and a `/recon/entry` message. Position is the rover's GPS, offset by the detection's depth along the rover heading when available.

- `/recon/capture` (Trigger): operator logs the current frame as `manual`, for objects the detector misses. Use it freely.
- Output: `~/trixanth_logs/recon/<session>/recon.csv` + images, ready to hand to the judges.

## Launch

```bash
ros2 launch trixanth_mission mission.launch.py mission:=rado deliveries_file:=/path/today.yaml
ros2 launch trixanth_mission mission.launch.py mission:=abex      # monitor only
```

## Test

```bash
colcon test --packages-select trixanth_mission
```

TESTING.md S6 (20 sim deliveries), S9 (offset GPS), S10 (clock), F5 (field accuracy), D1–D4 drills.
