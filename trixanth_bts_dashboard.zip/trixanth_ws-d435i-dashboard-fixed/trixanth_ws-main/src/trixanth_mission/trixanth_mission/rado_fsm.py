"""RADO autonomous delivery state machine (rule 3.3.2).

Flow per delivery (operator does the pickup in MANUAL, then hands over):
  operator calls /rado/start_delivery      <- last command sent before autonomy
  -> mode AUTONOMOUS (command_gate announces it; team leader tells the judge)
  -> RESOLVE   lat/lon -> map pose (navsat_transform /fromLL)
  -> NAVIGATE  Nav2 NavigateToPose to the approximate GPS point (1 retry)
  -> SEARCH    rotate in place until the marker colour is seen
  -> APPROACH  visual servo to the marker
  -> PLACE     ask the arm to place the object (/arm/command "place", wait /arm/status "done")
  -> BACKOFF   reverse briefly so the object is not disturbed
  -> DONE      mode back to MANUAL
Any failure -> FAILED, mode MANUAL, operators can finish non-autonomously (50% of delivery points).

The rover never needs a command from the ground once AUTONOMOUS starts; link loss does not stop it.
Deliveries come from a YAML file (config/rado_deliveries.yaml), filled in at the briefing.
"""
import math

import rclpy
import yaml
from action_msgs.msg import GoalStatus
from geographic_msgs.msg import GeoPoint
from geometry_msgs.msg import PoseStamped, Twist
from nav2_msgs.action import NavigateToPose
from rcl_interfaces.msg import Parameter, ParameterType, ParameterValue
from rcl_interfaces.srv import SetParameters
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile
from robot_localization.srv import FromLL
from std_msgs.msg import String, UInt8
from std_srvs.srv import Trigger

from trixanth_interfaces.msg import MarkerObservation
from trixanth_interfaces.srv import SetMode
from trixanth_mission.approach import approach_cmd

MANUAL, AUTONOMOUS = 1, 2


class RadoFsm(Node):
    def __init__(self):
        super().__init__("rado_fsm")
        self.declare_parameter("deliveries_file", "")
        self.declare_parameter("nav_retries", 1)
        self.declare_parameter("search_turn_rate", 0.3)        # rad/s
        self.declare_parameter("marker_lost_timeout", 2.0)     # s before going back to SEARCH
        self.declare_parameter("stop_range", 0.8)              # m from marker to stop and place
        self.declare_parameter("place_timeout", 20.0)          # s to wait for the arm
        self.declare_parameter("backoff_speed", 0.15)
        self.declare_parameter("backoff_time", 2.0)
        self.declare_parameter("marker_detector_node", "/marker_detector")

        self.deliveries = self.load(self.get_parameter("deliveries_file").value)
        self.state = "IDLE"
        self.state_t = self.get_clock().now()
        self.current = None
        self.goal_pose = None
        self.nav_goal = None
        self.nav_tries = 0
        self.marker = None
        self.marker_t = None
        self.arm_done = False
        self.mode = 0

        self.nav = ActionClient(self, NavigateToPose, "navigate_to_pose")
        self.fromll = self.create_client(FromLL, "/fromLL")
        self.set_mode_cli = self.create_client(SetMode, "set_mode")
        det = self.get_parameter("marker_detector_node").value
        self.marker_param_cli = self.create_client(SetParameters, f"{det}/set_parameters")

        self.pub_cmd = self.create_publisher(Twist, "cmd_vel_auto", 10)
        self.pub_status = self.create_publisher(String, "rado/status", 10)
        self.pub_arm = self.create_publisher(String, "arm/command", 10)
        self.create_subscription(MarkerObservation, "perception/marker", self.on_marker, 10)
        self.create_subscription(String, "arm/status", self.on_arm, 10)
        latched = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.create_subscription(UInt8, "trixanth/mode", self.on_mode, latched)
        self.create_service(Trigger, "rado/start_delivery", self.on_start)
        self.create_service(Trigger, "rado/abort", self.on_abort)
        self.create_service(Trigger, "rado/list", self.on_list)
        self.create_timer(0.1, self.tick)
        self.status(f"Loaded {len(self.deliveries)} deliveries")

    # ---------- setup ----------
    def load(self, path):
        if not path:
            self.get_logger().warn("No deliveries_file set")
            return []
        with open(path) as f:
            data = yaml.safe_load(f) or {}
        out = []
        for d in data.get("deliveries", []):
            out.append({"name": d["name"], "lat": float(d["lat"]), "lon": float(d["lon"]),
                        "marker": d.get("marker", "blue"), "done": False})
        return out

    def status(self, text):
        self.get_logger().info(text)
        self.pub_status.publish(String(data=f"[{self.state}] {text}"))

    def go(self, state):
        self.state = state
        self.state_t = self.get_clock().now()
        self.status(f"-> {state}")

    def in_state_s(self):
        return (self.get_clock().now() - self.state_t).nanoseconds * 1e-9

    # ---------- inputs ----------
    def on_marker(self, msg):
        self.marker = msg
        if msg.visible:
            self.marker_t = self.get_clock().now()

    def on_arm(self, msg):
        if msg.data.strip().lower() == "done":
            self.arm_done = True

    def on_mode(self, msg):
        prev, self.mode = self.mode, msg.data
        if prev == AUTONOMOUS and msg.data != AUTONOMOUS and self.state not in ("IDLE", "DONE", "FAILED"):
            self.fail(f"mode left AUTONOMOUS ({msg.data})", restore_manual=False)

    def on_list(self, _req, res):
        res.success = True
        res.message = "; ".join(f"{d['name']} {d['marker']} {'done' if d['done'] else 'pending'}"
                                for d in self.deliveries) or "none"
        return res

    def on_abort(self, _req, res):
        # Test/safety use only: sending this during a scored autonomous run counts as a command.
        self.fail("aborted by operator")
        res.success, res.message = True, "aborted"
        return res

    def on_start(self, _req, res):
        if self.state not in ("IDLE", "DONE", "FAILED"):
            res.success, res.message = False, f"busy in {self.state}"
            return res
        if self.mode != MANUAL:
            res.success, res.message = False, "start from MANUAL mode (after pickup)"
            return res
        pending = [d for d in self.deliveries if not d["done"]]
        if not pending:
            res.success, res.message = False, "no pending deliveries"
            return res
        self.current = pending[0]
        self.nav_tries = 0
        self.arm_done = False
        self.set_marker_colour(self.current["marker"])
        req = SetMode.Request()
        req.mode = AUTONOMOUS
        self.set_mode_cli.call_async(req).add_done_callback(self.after_mode)
        res.success, res.message = True, f"starting {self.current['name']}"
        return res

    def after_mode(self, fut):
        r = fut.result()
        if r is None or not r.success:
            self.status(f"Mode change refused: {r.message if r else 'no response'}")
            return
        self.go("RESOLVE")
        req = FromLL.Request()
        req.ll_point = GeoPoint(latitude=self.current["lat"], longitude=self.current["lon"], altitude=0.0)
        self.fromll.call_async(req).add_done_callback(self.after_fromll)

    def after_fromll(self, fut):
        r = fut.result()
        if r is None:
            self.fail("fromLL failed")
            return
        p = PoseStamped()
        p.header.frame_id = "map"
        p.pose.position.x, p.pose.position.y = r.map_point.x, r.map_point.y
        p.pose.orientation.w = 1.0
        self.goal_pose = p
        self.send_nav()

    def set_marker_colour(self, colour):
        if not self.marker_param_cli.service_is_ready():
            self.get_logger().warn("marker_detector not reachable; colour not set")
            return
        v = ParameterValue(type=ParameterType.PARAMETER_STRING, string_value=colour)
        req = SetParameters.Request(parameters=[Parameter(name="colour", value=v)])
        self.marker_param_cli.call_async(req)

    # ---------- navigation ----------
    def send_nav(self):
        if not self.nav.wait_for_server(timeout_sec=2.0):
            self.fail("Nav2 not available")
            return
        self.nav_tries += 1
        self.go("NAVIGATE")
        goal = NavigateToPose.Goal()
        self.goal_pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose = self.goal_pose
        self.nav.send_goal_async(goal).add_done_callback(self.after_goal_sent)

    def after_goal_sent(self, fut):
        handle = fut.result()
        if handle is None or not handle.accepted:
            self.fail("Nav2 rejected goal")
            return
        self.nav_goal = handle
        handle.get_result_async().add_done_callback(self.after_nav)

    def after_nav(self, fut):
        self.nav_goal = None
        if self.state != "NAVIGATE":
            return
        status = fut.result().status
        if status == GoalStatus.STATUS_SUCCEEDED:
            self.go("SEARCH")
        elif self.nav_tries <= self.get_parameter("nav_retries").value:
            self.status(f"Navigation failed (status {status}), retrying")
            self.send_nav()
        else:
            self.fail(f"navigation failed (status {status})")

    # ---------- main loop ----------
    def drive(self, v, w):
        t = Twist()
        t.linear.x, t.angular.z = float(v), float(w)
        self.pub_cmd.publish(t)

    def marker_fresh(self):
        lim = self.get_parameter("marker_lost_timeout").value
        return self.marker_t is not None and (self.get_clock().now() - self.marker_t).nanoseconds * 1e-9 < lim

    def tick(self):
        s = self.state
        if s == "SEARCH":
            if self.marker_fresh():
                self.go("APPROACH")
                return
            rate = self.get_parameter("search_turn_rate").value
            if self.in_state_s() > 2 * math.pi / rate + 3.0:
                self.fail("marker not found after a full turn")
                return
            self.drive(0.0, rate)
        elif s == "APPROACH":
            if not self.marker_fresh():
                self.drive(0.0, 0.0)
                self.go("SEARCH")
                return
            m = self.marker
            v, w, arrived = approach_cmd(m.visible, m.bearing_rad, m.range_m, m.area_ratio,
                                         stop_range=self.get_parameter("stop_range").value)
            if arrived:
                self.drive(0.0, 0.0)
                self.arm_done = False
                self.pub_arm.publish(String(data="place"))
                self.go("PLACE")
            else:
                self.drive(v, w)
        elif s == "PLACE":
            self.drive(0.0, 0.0)
            if self.arm_done:
                self.go("BACKOFF")
            elif self.in_state_s() > self.get_parameter("place_timeout").value:
                self.status("Arm did not report done; backing off anyway")
                self.go("BACKOFF")
        elif s == "BACKOFF":
            if self.in_state_s() < self.get_parameter("backoff_time").value:
                self.drive(-self.get_parameter("backoff_speed").value, 0.0)
            else:
                self.drive(0.0, 0.0)
                self.current["done"] = True
                self.go("DONE")
                self.status(f"Delivered {self.current['name']}")
                self.request_manual()

    def request_manual(self):
        req = SetMode.Request()
        req.mode = MANUAL
        self.set_mode_cli.call_async(req)

    def fail(self, why, restore_manual=True):
        if self.nav_goal is not None:
            self.nav_goal.cancel_goal_async()
            self.nav_goal = None
        self.drive(0.0, 0.0)
        self.go("FAILED")
        self.status(f"FAILED: {why}")
        if restore_manual:
            self.request_manual()


def main():
    rclpy.init()
    node = RadoFsm()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
