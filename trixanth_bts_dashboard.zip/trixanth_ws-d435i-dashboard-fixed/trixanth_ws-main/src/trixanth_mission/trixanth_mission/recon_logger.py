"""RADO recon documentation (rule 3.3.1): photo + GPS for every located object.

Auto mode: during the "recon" stage, every new detection above min_confidence is logged once.
           Duplicates (same label within dedupe_radius_m) are skipped.
Manual:    /recon/capture (std_srvs/Trigger) logs the current frame with label "manual", for objects
           the detector misses. Operators should use this freely.
Output:    <output_dir>/<YYYYmmdd_HHMMSS>/recon.csv + one JPEG per entry, /recon/entry (ReconEntry)

GPS logged is the ROVER position at the time of the photo. If the detection has a depth position,
the object position is offset along the rover heading (needs /odometry/global yaw).
"""
import csv
import math
import os
import time

import cv2
import rclpy
from cv_bridge import CvBridge
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image, NavSatFix
from std_srvs.srv import Trigger

from trixanth_interfaces.msg import DetectionArray, MissionState, ReconEntry


def offset_latlon(lat, lon, north_m, east_m):
    dlat = north_m / 6378137.0
    dlon = east_m / (6378137.0 * math.cos(math.radians(lat)))
    return lat + math.degrees(dlat), lon + math.degrees(dlon)


class ReconLogger(Node):
    def __init__(self):
        super().__init__("recon_logger")
        self.declare_parameter("output_dir", os.path.expanduser("~/trixanth_logs/recon"))
        self.declare_parameter("min_confidence", 0.5)
        self.declare_parameter("dedupe_radius_m", 3.0)
        self.declare_parameter("auto_log", True)
        self.declare_parameter("color_topic", "/camera/color/image_raw")
        g = lambda n: self.get_parameter(n).value  # noqa: E731

        self.dir = os.path.join(g("output_dir"), time.strftime("%Y%m%d_%H%M%S"))
        os.makedirs(self.dir, exist_ok=True)
        self.csv_path = os.path.join(self.dir, "recon.csv")
        with open(self.csv_path, "w", newline="") as f:
            csv.writer(f).writerow(["id", "time", "label", "confidence", "latitude", "longitude",
                                    "altitude", "h_accuracy_m", "image"])
        self.bridge = CvBridge()
        self.fix = None
        self.yaw = None   # ENU yaw from the global EKF (0 = east)
        self.frame = None
        self.stage = ""
        self.entries = []
        self.next_id = 1

        self.pub = self.create_publisher(ReconEntry, "recon/entry", 10)
        self.create_subscription(NavSatFix, "gps/fix", lambda m: setattr(self, "fix", m), 10)
        self.create_subscription(Odometry, "odometry/global", self.on_odom, 10)
        self.create_subscription(Image, g("color_topic"), lambda m: setattr(self, "frame", m), qos_profile_sensor_data)
        self.create_subscription(DetectionArray, "perception/detections", self.on_detections, 10)
        self.create_subscription(MissionState, "mission/state", lambda m: setattr(self, "stage", m.stage), 10)
        self.create_service(Trigger, "recon/capture", self.on_capture)
        self.get_logger().info(f"Logging recon to {self.dir}")

    def on_odom(self, m):
        q = m.pose.pose.orientation
        self.yaw = math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))

    def on_detections(self, msg):
        if not self.get_parameter("auto_log").value or self.stage != "recon":
            return
        for d in msg.detections:
            if d.confidence < self.get_parameter("min_confidence").value:
                continue
            fwd = d.position.z if math.isfinite(d.position.z) else 0.0   # optical z = forward
            left = -d.position.x if math.isfinite(d.position.x) else 0.0
            self.log(d.label, d.confidence, fwd, left, (d.x, d.y, d.w, d.h))

    def on_capture(self, _req, res):
        ok, why = self.log("manual", 1.0, 0.0, 0.0, None, force=True)
        res.success, res.message = ok, why
        return res

    def log(self, label, conf, fwd_m, left_m, bbox, force=False):
        if self.fix is None or self.frame is None:
            return False, "no GPS fix or no image yet"
        lat, lon = self.fix.latitude, self.fix.longitude
        if self.yaw is not None and (fwd_m or left_m):
            east = fwd_m * math.cos(self.yaw) - left_m * math.sin(self.yaw)
            north = fwd_m * math.sin(self.yaw) + left_m * math.cos(self.yaw)
            lat, lon = offset_latlon(lat, lon, north, east)
        if not force:
            r = self.get_parameter("dedupe_radius_m").value
            for e in self.entries:
                if e["label"] == label and self.dist(e["lat"], e["lon"], lat, lon) < r:
                    return False, "duplicate"

        img = self.bridge.imgmsg_to_cv2(self.frame, "bgr8").copy()
        if bbox:
            x, y, w, h = bbox
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(img, f"#{self.next_id} {label} {lat:.6f},{lon:.6f}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        name = f"{self.next_id:03d}_{label}.jpg"
        cv2.imwrite(os.path.join(self.dir, name), img)

        cov = self.fix.position_covariance
        acc = math.sqrt(max(cov[0], cov[4], 0.0)) if self.fix.position_covariance_type else float("nan")
        row = [self.next_id, time.strftime("%H:%M:%S"), label, f"{conf:.2f}", f"{lat:.7f}", f"{lon:.7f}",
               f"{self.fix.altitude:.1f}", f"{acc:.2f}", name]
        with open(self.csv_path, "a", newline="") as f:
            csv.writer(f).writerow(row)

        e = ReconEntry()
        e.header.stamp = self.get_clock().now().to_msg()
        e.id, e.label, e.confidence = self.next_id, label, float(conf)
        e.latitude, e.longitude, e.altitude = lat, lon, self.fix.altitude
        e.horizontal_accuracy_m = float(acc)
        e.image_path = os.path.join(self.dir, name)
        self.pub.publish(e)
        self.entries.append({"label": label, "lat": lat, "lon": lon})
        self.get_logger().info(f"Recon #{self.next_id}: {label} at {lat:.6f}, {lon:.6f}")
        self.next_id += 1
        return True, name

    @staticmethod
    def dist(lat1, lon1, lat2, lon2):
        dn = math.radians(lat2 - lat1) * 6378137.0
        de = math.radians(lon2 - lon1) * 6378137.0 * math.cos(math.radians(lat1))
        return math.hypot(dn, de)


def main():
    rclpy.init()
    node = ReconLogger()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
