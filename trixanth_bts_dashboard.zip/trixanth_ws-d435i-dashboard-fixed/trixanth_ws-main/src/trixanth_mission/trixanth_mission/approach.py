"""Visual-servo approach to a delivery marker (no ROS imports)."""
import math


def approach_cmd(visible, bearing, range_m, area_ratio, stop_range=0.8, stop_area=0.12,
                 v_max=0.25, k_turn=1.2, w_max=0.6):
    """Return (linear_x, angular_z, arrived).

    Turns toward the marker, drives slower when off-axis, stops when close by depth or by blob size.
    """
    if not visible:
        return 0.0, 0.0, False
    close = (math.isfinite(range_m) and range_m <= stop_range) or area_ratio >= stop_area
    if close:
        return 0.0, 0.0, True
    w = max(-w_max, min(w_max, k_turn * bearing))
    alignment = max(0.0, math.cos(bearing))       # 1 straight ahead, 0 at 90 deg
    v = v_max * alignment if abs(bearing) < 0.6 else 0.0   # turn in place when far off-axis
    if math.isfinite(range_m):
        v = min(v, max(0.08, 0.3 * (range_m - stop_range)))  # slow down near the marker
    return v, w, False
