"""Mission clock for the dashboard: tracks the IRC timing rules and warns the operators.

Services  /mission/start (trixanth_interfaces/StartMission)   call when the judge starts the clock
          /mission/stop  (std_srvs/Trigger)
          /mission/comms_penalty (std_srvs/Trigger)            judge applied the 50% time penalty
Topics in /mission/score (ScoreEvent)  operator logs points as the judge awards them
          /trixanth/mode (UInt8)
Topics out /mission/state (MissionState, 2 Hz), /mission/alert (String) for dashboard pop-ups/audio
"""
import rclpy
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile
from std_msgs.msg import String, UInt8
from std_srvs.srv import Trigger

from trixanth_interfaces.msg import MissionState, ScoreEvent
from trixanth_interfaces.srv import StartMission
from trixanth_mission.mission_clock import MissionClock


class MissionMonitor(Node):
    def __init__(self):
        super().__init__("mission_monitor")
        self.clock = None
        self.mode = 0
        self.last_tick = None
        self.pub_state = self.create_publisher(MissionState, "mission/state", 10)
        self.pub_alert = self.create_publisher(String, "mission/alert", 10)
        self.create_service(StartMission, "mission/start", self.on_start)
        self.create_service(Trigger, "mission/stop", self.on_stop)
        self.create_service(Trigger, "mission/comms_penalty", self.on_comms_penalty)
        self.create_subscription(ScoreEvent, "mission/score", self.on_score, 10)
        latched = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.create_subscription(UInt8, "trixanth/mode", lambda m: setattr(self, "mode", m.data), latched)
        self.create_timer(0.5, self.tick)

    def on_start(self, req, res):
        if req.mission not in ("rado", "abex", "idmo"):
            res.success, res.message = False, "mission must be rado, abex or idmo"
            return res
        self.clock = MissionClock(mission=req.mission, points_max=float(req.points_max))
        self.last_tick = self.get_clock().now()
        self.alert(f"Mission {req.mission.upper()} started")
        res.success, res.message = True, "started"
        return res

    def on_stop(self, _req, res):
        if self.clock:
            self.alert(f"Mission stopped at {self.fmt(self.clock.elapsed)} with {self.clock.points:.0f} points")
        self.clock = None
        res.success, res.message = True, "stopped"
        return res

    def on_comms_penalty(self, _req, res):
        if self.clock:
            self.clock.comms_penalty = True
            self.alert("COMMS PENALTY: max mission time halved to 12:30")
        res.success, res.message = True, "applied"
        return res

    def on_score(self, msg):
        if self.clock:
            self.clock.add_points(msg.points)
            self.get_logger().info(f"+{msg.points:.0f} {msg.task} (total {self.clock.points:.0f})")

    def alert(self, text):
        self.get_logger().warn(text)
        self.pub_alert.publish(String(data=text))

    @staticmethod
    def fmt(s):
        return f"{int(s // 60):02d}:{int(s % 60):02d}"

    def tick(self):
        s = MissionState()
        s.header.stamp = self.get_clock().now().to_msg()
        s.mode = self.mode
        if self.clock is not None:
            now = self.get_clock().now()
            dt = (now - self.last_tick).nanoseconds * 1e-9
            self.last_tick = now
            if not self.clock.finished:
                for a in self.clock.advance(dt):
                    self.alert(a)
                if self.clock.finished:
                    self.alert(f"TIME: mission over at {self.fmt(self.clock.elapsed)}")
            c = self.clock
            s.mission, s.stage, s.running = c.mission, c.stage(), not c.finished
            s.elapsed_s, s.limit_s = float(c.elapsed), float(c.limit)
            s.points, s.points_max = float(c.points), float(c.points_max)
            s.bonus_unlocked = c.bonus_unlocked
            s.alert = c.log[-1] if c.log else ""
        self.pub_state.publish(s)


def main():
    rclpy.init()
    node = MissionMonitor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
