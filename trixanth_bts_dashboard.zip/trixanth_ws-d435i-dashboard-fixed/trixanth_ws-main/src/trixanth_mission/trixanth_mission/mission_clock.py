"""IRC 2027 field-mission timing rules (section 3.0), no ROS imports.

- 25 min per field mission
- no points in the first 7 min -> mission aborted
- MORE than 30% of points in the first 15 min to keep the full 25 min, otherwise stop at 15
- bonus tasks only after 15 min
- comms switched on without permission halves the maximum time (set comms_penalty=True)
- RADO: recon is the first 10 min, autonomous delivery the next 15 (3.3.1 / 3.3.2)
"""
from dataclasses import dataclass, field

FULL_S = 25 * 60
ZERO_ABORT_S = 7 * 60
GATE_S = 15 * 60
GATE_FRACTION = 0.30
RADO_RECON_S = 10 * 60


@dataclass
class MissionClock:
    mission: str = ""
    points_max: float = 0.0          # 0 = unknown (Table 1.2 not extracted yet)
    comms_penalty: bool = False
    elapsed: float = 0.0
    points: float = 0.0
    aborted: bool = False
    stopped_at_gate: bool = False
    log: list = field(default_factory=list)

    @property
    def limit(self) -> float:
        lim = FULL_S / 2 if self.comms_penalty else FULL_S
        if self.stopped_at_gate:
            lim = min(lim, GATE_S)
        if self.aborted:
            lim = min(lim, ZERO_ABORT_S)
        return lim

    @property
    def gate_known(self) -> bool:
        return self.points_max > 0

    @property
    def gate_passed(self) -> bool:
        return self.gate_known and self.points > GATE_FRACTION * self.points_max

    @property
    def bonus_unlocked(self) -> bool:
        return self.elapsed >= GATE_S and not self.stopped_at_gate and (self.gate_passed or not self.gate_known)

    @property
    def finished(self) -> bool:
        return self.elapsed >= self.limit

    def stage(self) -> str:
        if self.mission == "rado":
            return "recon" if self.elapsed < RADO_RECON_S else "delivery"
        return "field"

    def add_points(self, p: float):
        self.points += p

    def advance(self, dt: float) -> list:
        """Move the clock forward; returns new alert strings."""
        alerts = []
        before = self.elapsed
        self.elapsed += dt

        def crossed(t):
            return before < t <= self.elapsed

        if crossed(5 * 60) and self.points <= 0:
            alerts.append("5:00 and ZERO points - score anything in the next 2 minutes or the mission aborts")
        if crossed(ZERO_ABORT_S) and self.points <= 0:
            self.aborted = True
            alerts.append("7:00 with zero points - MISSION ABORTED (rule 3.0)")
        if self.mission == "rado" and crossed(RADO_RECON_S):
            alerts.append("10:00 recon over - autonomous delivery stage starts now")
        if crossed(12 * 60) and self.gate_known and not self.gate_passed:
            need = GATE_FRACTION * self.points_max - self.points
            alerts.append(f"12:00 below 30% gate - need more than {need:.0f} more points by 15:00")
        if crossed(GATE_S):
            if not self.gate_known:
                alerts.append("15:00 gate NOT evaluated: points_max unknown - judge decides")
            elif not self.gate_passed:
                self.stopped_at_gate = True
                alerts.append("15:00 at or below 30% - mission stops now (rule 3.0)")
            else:
                alerts.append("15:00 gate passed - bonus tasks unlocked")
        if crossed(20 * 60) and not self.finished:
            alerts.append("20:00 - 5 minutes left")
        self.log.extend(alerts)
        return alerts
