"""Serve the built dashboard (share/trixanth_dashboard/web) over HTTP.

    ros2 run trixanth_dashboard web_server --port 5173
    ros2 run trixanth_dashboard web_server --rover-host 192.168.10.2   # on the base laptop

With --rover-host the page talks to that machine for rosbridge (9090), the launch
manager (8000) and web_video_server (8080) instead of the host it was served from.
"""
import argparse
import json
import os
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer


def web_root() -> str:
    try:
        from ament_index_python.packages import get_package_share_directory

        root = os.path.join(get_package_share_directory("trixanth_dashboard"), "web")
        if os.path.isfile(os.path.join(root, "index.html")):
            return root
    except Exception:
        pass
    # Source tree fallback (running straight from src/ without installing)
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web")


class Handler(SimpleHTTPRequestHandler):
    rover_host = ""

    def do_GET(self):
        if self.path.split("?")[0] == "/runtime-config.js":
            body = f"window.__TRIXANTH_HOST__ = {json.dumps(self.rover_host)}\n".encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/javascript")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        super().do_GET()

    def log_message(self, fmt, *args):  # keep launch output readable
        pass


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(description="Serve the Trixanth dashboard")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=5173)
    ap.add_argument("--rover-host", default="", help="rover address the page should connect to")
    args, _ros_args = ap.parse_known_args(argv)

    root = web_root()
    if not os.path.isfile(os.path.join(root, "index.html")):
        raise SystemExit(
            f"No built dashboard in {root}. Run scripts/build_frontend.sh, then colcon build."
        )
    Handler.rover_host = args.rover_host
    server = ThreadingHTTPServer((args.host, args.port), partial(Handler, directory=root))
    print(f"Dashboard on http://{args.host}:{args.port}  (serving {root})", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
