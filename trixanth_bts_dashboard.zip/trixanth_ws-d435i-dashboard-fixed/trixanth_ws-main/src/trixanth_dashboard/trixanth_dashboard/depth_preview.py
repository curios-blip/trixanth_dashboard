"""Colourised depth image for the dashboard.

web_video_server cannot stream the RealSense depth topic: it is 16UC1 (millimetres) and cv_bridge
refuses to turn that into the colour JPEG the browser wants. This node subscribes to the raw depth
image, applies a colour map and republishes it as bgr8, which web_video_server streams fine.

  Sub  /camera/depth/image_rect_raw   sensor_msgs/Image  (16UC1 mm or 32FC1 m)
  Pub  /camera/depth/preview          sensor_msgs/Image  (bgr8)

The raw depth topic is left untouched, so red_zone / the point cloud / Nav2 are not affected.
It only does work while something is subscribed to the preview topic (e.g. a dashboard tab with
the "Depth Map" button selected).
"""
import numpy as np
import rclpy
from cv_bridge import CvBridge
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image


def colourise_depth(depth, min_m=0.2, max_m=6.0):
    """Depth image (uint16 mm or float32 m) -> bgr8 uint8 image. Near = warm, far = cool, no data = black."""
    import cv2

    d = depth.astype(np.float32)
    if depth.dtype == np.uint16:
        d /= 1000.0
    valid = np.isfinite(d) & (d > 0.0)
    span = max(max_m - min_m, 1e-3)
    norm = np.nan_to_num(np.clip((d - min_m) / span, 0.0, 1.0), nan=1.0, posinf=1.0, neginf=0.0)
    # JET runs blue -> red; invert so close objects are red (what operators expect for "danger").
    u8 = ((1.0 - norm) * 255.0).astype(np.uint8)
    out = cv2.applyColorMap(u8, cv2.COLORMAP_JET)
    out[~valid] = 0
    return out


class DepthPreview(Node):
    def __init__(self):
        super().__init__("depth_preview")
        self.declare_parameter("input_topic", "/camera/depth/image_rect_raw")
        self.declare_parameter("output_topic", "/camera/depth/preview")
        self.declare_parameter("min_m", 0.2)
        self.declare_parameter("max_m", 6.0)
        g = self.get_parameter
        self.bridge = CvBridge()
        self.min_m = float(g("min_m").value)
        self.max_m = float(g("max_m").value)
        self.pub = self.create_publisher(Image, g("output_topic").value, qos_profile_sensor_data)
        self.create_subscription(Image, g("input_topic").value, self.on_depth, qos_profile_sensor_data)
        self.get_logger().info(f"{g('input_topic').value} -> {g('output_topic').value} ({self.min_m}-{self.max_m} m)")

    def on_depth(self, msg: Image):
        if self.pub.get_subscription_count() == 0:
            return  # nobody is watching, skip the colour map
        try:
            depth = self.bridge.imgmsg_to_cv2(msg, "passthrough")
            out = self.bridge.cv2_to_imgmsg(colourise_depth(depth, self.min_m, self.max_m), "bgr8")
        except Exception as e:  # noqa: BLE001 - a bad frame must not kill the node
            self.get_logger().warn(f"depth frame skipped: {e}", throttle_duration_sec=5.0)
            return
        out.header = msg.header
        self.pub.publish(out)


def main():
    rclpy.init()
    node = DepthPreview()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
