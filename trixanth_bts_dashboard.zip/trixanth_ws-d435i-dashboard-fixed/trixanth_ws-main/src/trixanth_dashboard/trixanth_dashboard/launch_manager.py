"""Trixanth launch manager.

Wraps `ros2 launch` invocations as supervised subprocesses and exposes them over
REST + WebSocket so the web dashboard can start/stop them and tail their output.

Started by `ros2 launch trixanth_dashboard dashboard.launch.py`, or by hand:

    ros2 run trixanth_dashboard launch_manager --port 8000

Each child re-sources ROS and the workspace itself, so the manager also works when
started from systemd with an empty environment.

Environment:
    ROS_DISTRO     (default: jazzy)
    TRIXANTH_WS    workspace root; default: the workspace this package was installed from
"""

import asyncio
import os
import signal
import time
from contextlib import asynccontextmanager
from collections import deque
from dataclasses import dataclass, field
from typing import Optional

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

def find_workspace() -> str:
    """TRIXANTH_WS, else the workspace whose install/ holds this package, else ~/trixanth_ws."""
    if os.environ.get("TRIXANTH_WS"):
        return os.environ["TRIXANTH_WS"]
    for prefix in os.environ.get("AMENT_PREFIX_PATH", "").split(os.pathsep):
        if os.path.basename(prefix.rstrip("/")) == "trixanth_dashboard":
            return os.path.dirname(os.path.dirname(prefix.rstrip("/")))  # <ws>/install/<pkg> -> <ws>
        if os.path.basename(prefix.rstrip("/")) == "install":  # --merge-install
            return os.path.dirname(prefix.rstrip("/"))
    return os.path.expanduser("~/trixanth_ws")


ROS_DISTRO = os.environ.get("ROS_DISTRO", "jazzy")
WS_PATH = find_workspace()
LOG_BUFFER_LINES = 500
SHUTDOWN_GRACE_S = 8.0


# --------------------------------------------------------------------------
# What the dashboard is allowed to launch.
#
# `group` is a mutual-exclusion key: two launches in the same non-empty group
# can never run at the same time. Without this you can bring up two Nav2 stacks
# that both publish /cmd_vel, which is a genuinely dangerous failure mode.
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class LaunchSpec:
    package: str
    launch_file: str
    label: str
    group: str = ""
    args: tuple = ()


# Mission launches already include the robot base layer, so they and `robot` are one
# exclusion group: two of them at once would mean two command_gates and two EKFs.
# rosbridge is owned by dashboard.launch.py (the dashboard needs it to talk to the
# rover), so the mission launches are started with rosbridge:=false.
NO_BRIDGE = ("rosbridge:=false",)

LAUNCHES: dict[str, LaunchSpec] = {
    "robot": LaunchSpec(
        "trixanth_bringup", "robot.launch.py", "Robot base layer", group="stack"
    ),
    "rado": LaunchSpec(
        "trixanth_bringup", "rado.launch.py", "Mission: RADO", group="stack", args=NO_BRIDGE
    ),
    "abex": LaunchSpec(
        "trixanth_bringup", "abex.launch.py", "Mission: ABEx", group="stack", args=NO_BRIDGE
    ),
    "idmo": LaunchSpec(
        "trixanth_bringup", "idmo.launch.py", "Mission: IDMO", group="stack", args=NO_BRIDGE
    ),
    "sim_rado": LaunchSpec(
        "trixanth_bringup", "sim_rado.launch.py", "Simulation: RADO (Gazebo)", group="stack"
    ),
}


def build_command(spec: LaunchSpec, args: list[str]) -> list[str]:
    """Source the ROS environment inside the child, then exec ros2 launch.

    `exec` matters: without it bash stays as an extra layer between us and the
    launch process and the PID we hold isn't the one we need to signal.
    """
    quoted = " ".join(f"'{a}'" for a in [*spec.args, *args])
    inner = (
        f"source /opt/ros/{ROS_DISTRO}/setup.bash && "
        f"source '{WS_PATH}/install/setup.bash' && "
        f"exec ros2 launch {spec.package} {spec.launch_file} {quoted}"
    )
    return ["/bin/bash", "-c", inner]


@dataclass
class ManagedLaunch:
    name: str
    spec: LaunchSpec
    proc: Optional[asyncio.subprocess.Process] = None
    started_at: Optional[float] = None
    exit_code: Optional[int] = None
    stopping: bool = False
    log: deque = field(default_factory=lambda: deque(maxlen=LOG_BUFFER_LINES))
    subscribers: set = field(default_factory=set)

    @property
    def state(self) -> str:
        if self.proc is not None and self.proc.returncode is None:
            return "stopping" if self.stopping else "running"
        if self.exit_code in (None, 0, -signal.SIGINT, -signal.SIGTERM):
            return "stopped"
        return "crashed"

    def emit(self, line: str) -> None:
        stamped = f"{time.strftime('%H:%M:%S')} {line}"
        self.log.append(stamped)
        for q in list(self.subscribers):
            try:
                q.put_nowait(stamped)
            except asyncio.QueueFull:
                pass

    def status(self) -> dict:
        return {
            "name": self.name,
            "label": self.spec.label,
            "group": self.spec.group,
            "state": self.state,
            "pid": self.proc.pid if self.proc and self.proc.returncode is None else None,
            "uptime_s": round(time.time() - self.started_at, 1)
            if self.started_at and self.state in ("running", "stopping")
            else None,
            "exit_code": self.exit_code,
        }


MANAGED = {name: ManagedLaunch(name, spec) for name, spec in LAUNCHES.items()}

@asynccontextmanager
async def lifespan(_app: FastAPI):
    yield
    for ml in MANAGED.values():
        await signal_group(ml, signal.SIGINT)


app = FastAPI(title="Trixanth launch manager", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # local network only; do not expose this port publicly
    allow_methods=["*"],
    allow_headers=["*"],
)


async def pump_output(ml: ManagedLaunch) -> None:
    assert ml.proc and ml.proc.stdout
    async for raw in ml.proc.stdout:
        ml.emit(raw.decode(errors="replace").rstrip())
    await ml.proc.wait()
    ml.exit_code = ml.proc.returncode
    ml.stopping = False
    ml.emit(f"-- exited with code {ml.exit_code} --")


@app.get("/api/launches")
async def list_launches():
    return [ml.status() for ml in MANAGED.values()]


@app.post("/api/launches/{name}/start")
async def start(name: str, args: Optional[list[str]] = None):
    ml = MANAGED.get(name)
    if ml is None:
        raise HTTPException(404, f"unknown launch '{name}'")
    if ml.state in ("running", "stopping"):
        raise HTTPException(409, f"'{name}' is already {ml.state}")

    if ml.spec.group:
        for other in MANAGED.values():
            if (
                other.name != name
                and other.spec.group == ml.spec.group
                and other.state in ("running", "stopping")
            ):
                raise HTTPException(
                    409,
                    f"'{other.name}' is {other.state} and conflicts with '{name}' "
                    f"(group '{ml.spec.group}'). Stop it first.",
                )

    cmd = build_command(ml.spec, args or [])
    ml.log.clear()
    ml.exit_code = None
    ml.emit(f"-- starting: ros2 launch {ml.spec.package} {ml.spec.launch_file} --")
    ml.proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        start_new_session=True,  # own process group, so we can kill the whole tree
    )
    ml.started_at = time.time()
    asyncio.create_task(pump_output(ml))
    return ml.status()


async def signal_group(ml: ManagedLaunch, sig: int) -> None:
    if ml.proc is None or ml.proc.returncode is not None:
        return
    try:
        os.killpg(os.getpgid(ml.proc.pid), sig)
    except ProcessLookupError:
        pass


@app.post("/api/launches/{name}/stop")
async def stop(name: str):
    ml = MANAGED.get(name)
    if ml is None:
        raise HTTPException(404, f"unknown launch '{name}'")
    if ml.state not in ("running", "stopping"):
        raise HTTPException(409, f"'{name}' is not running")

    ml.stopping = True
    # SIGINT first: ros2 launch treats it as a clean shutdown and gives nodes
    # their on_shutdown handlers. Escalate only if it ignores us.
    await signal_group(ml, signal.SIGINT)
    for _ in range(int(SHUTDOWN_GRACE_S * 10)):
        if ml.proc.returncode is not None:
            return ml.status()
        await asyncio.sleep(0.1)
    ml.emit("-- did not exit on SIGINT, sending SIGTERM --")
    await signal_group(ml, signal.SIGTERM)
    await asyncio.sleep(2.0)
    if ml.proc.returncode is None:
        ml.emit("-- did not exit on SIGTERM, sending SIGKILL --")
        await signal_group(ml, signal.SIGKILL)
    return ml.status()


@app.post("/api/stop_all")
async def stop_all():
    for ml in MANAGED.values():
        if ml.state == "running":
            await stop(ml.name)
    return [ml.status() for ml in MANAGED.values()]


@app.websocket("/ws/logs/{name}")
async def logs(ws: WebSocket, name: str):
    ml = MANAGED.get(name)
    if ml is None:
        await ws.close(code=4404)
        return
    await ws.accept()
    q: asyncio.Queue = asyncio.Queue(maxsize=1000)
    ml.subscribers.add(q)
    try:
        for line in list(ml.log):
            await ws.send_text(line)
        while True:
            await ws.send_text(await q.get())
    except (WebSocketDisconnect, RuntimeError):
        pass
    finally:
        ml.subscribers.discard(q)


def main(argv=None) -> None:
    import argparse

    import uvicorn

    ap = argparse.ArgumentParser(description="Trixanth launch manager")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8000)
    args, _ros_args = ap.parse_known_args(argv)  # tolerate --ros-args from ros2 launch
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
