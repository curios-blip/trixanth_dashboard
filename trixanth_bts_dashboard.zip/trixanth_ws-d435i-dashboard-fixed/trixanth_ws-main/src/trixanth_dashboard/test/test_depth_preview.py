import numpy as np
import pytest

pytest.importorskip("cv2")
pytest.importorskip("rclpy")
pytest.importorskip("cv_bridge")

from trixanth_dashboard.depth_preview import colourise_depth  # noqa: E402


def test_uint16_mm_and_float_m_agree():
    mm = np.full((4, 6), 1500, np.uint16)
    m = np.full((4, 6), 1.5, np.float32)
    a, b = colourise_depth(mm), colourise_depth(m)
    assert a.shape == (4, 6, 3) and a.dtype == np.uint8
    assert np.array_equal(a, b)


def test_no_data_is_black_and_near_differs_from_far():
    d = np.array([[0, 300, 5500]], np.uint16)
    out = colourise_depth(d)
    assert out[0, 0].tolist() == [0, 0, 0]
    assert not np.array_equal(out[0, 1], out[0, 2])


def test_nan_is_black():
    d = np.array([[np.nan, 2.0]], np.float32)
    assert colourise_depth(d)[0, 0].tolist() == [0, 0, 0]
