import asyncio
import threading
import urllib.request
from functools import partial
from http.server import ThreadingHTTPServer

import pytest

fastapi = pytest.importorskip("fastapi")

from trixanth_dashboard import launch_manager as lm  # noqa: E402
from trixanth_dashboard import web_server  # noqa: E402


def test_launch_names_match_bringup_files():
    import os

    bringup = os.path.join(os.path.dirname(__file__), "..", "..", "trixanth_bringup", "launch")
    if not os.path.isdir(bringup):
        pytest.skip("trixanth_bringup not beside this package")
    for name, spec in lm.LAUNCHES.items():
        assert spec.package == "trixanth_bringup"
        assert os.path.isfile(os.path.join(bringup, spec.launch_file)), name


def test_missions_get_rosbridge_false_and_one_group():
    for name in ("rado", "abex", "idmo"):
        assert "rosbridge:=false" in lm.LAUNCHES[name].args
    assert len({s.group for s in lm.LAUNCHES.values()}) == 1


def test_build_command_sources_ros_and_execs():
    cmd = lm.build_command(lm.LAUNCHES["rado"], ["deliveries_file:=/tmp/x.yaml"])
    inner = cmd[-1]
    assert "setup.bash" in inner and "exec ros2 launch trixanth_bringup rado.launch.py" in inner
    assert "'rosbridge:=false'" in inner and "'deliveries_file:=/tmp/x.yaml'" in inner


def test_group_conflict_rejected():
    from fastapi import HTTPException

    class Alive:
        returncode = None
        pid = 1

    lm.MANAGED["abex"].proc = Alive()
    try:
        with pytest.raises(HTTPException) as e:
            asyncio.run(lm.start("rado"))
        assert e.value.status_code == 409
    finally:
        lm.MANAGED["abex"].proc = None


def test_unknown_launch_404():
    from fastapi import HTTPException

    with pytest.raises(HTTPException) as e:
        asyncio.run(lm.start("nope"))
    assert e.value.status_code == 404


def test_web_server_serves_runtime_config(tmp_path):
    (tmp_path / "index.html").write_text("<html></html>")
    web_server.Handler.rover_host = "192.168.10.2"
    srv = ThreadingHTTPServer(("127.0.0.1", 0), partial(web_server.Handler, directory=str(tmp_path)))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        port = srv.server_address[1]
        body = urllib.request.urlopen(f"http://127.0.0.1:{port}/runtime-config.js").read().decode()
        assert '"192.168.10.2"' in body
        assert b"<html>" in urllib.request.urlopen(f"http://127.0.0.1:{port}/").read()
    finally:
        srv.shutdown()
