# trixanth_dashboard

The ground-station web dashboard, packaged for this workspace.

| Part | What it is |
| --- | --- |
| `web/` | The built dashboard (committed, so the Jetson never needs Node). Installed to `share/trixanth_dashboard/web` |
| `frontend/` | React/Vite source. Edit `frontend/src/config.js` first: every topic, service and limit is there |
| `launch_manager` | FastAPI node (port 8000). Starts/stops `trixanth_bringup` launch files as supervised subprocesses and streams their output |
| `web_server` | Serves `web/` (port 5173). `--rover-host` points the page at another machine's rosbridge, launch manager and video server |
| `dashboard.launch.py` | rosbridge (9090) + web_video_server (8080) + launch manager + web server |

## Use

```bash
pip install -r requirements.txt            # fastapi, uvicorn (workspace root)
sudo apt install ros-jazzy-rosbridge-suite ros-jazzy-web-video-server
colcon build --packages-select trixanth_interfaces trixanth_bringup trixanth_dashboard
source install/setup.bash

ros2 launch trixanth_dashboard dashboard.launch.py                           # on the Jetson
ros2 launch trixanth_dashboard dashboard.launch.py rover_host:=192.168.10.2  # page served from the base laptop
```

Open `http://<host>:5173`. Start missions from the **Launches** panel; the manager runs
`rado`, `abex`, `idmo`, `robot` or `sim_rado` from `trixanth_bringup` (one at a time) with
`rosbridge:=false`, because this launch already owns rosbridge. If you start a mission from a terminal
while the dashboard is up, add `rosbridge:=false` to it too.

Demo mode (`?demo=1`) runs the page against a simulated rover with no ROS at all.

## Rebuilding the frontend

```bash
scripts/build_frontend.sh          # npm ci, build, copy to web/
colcon build --packages-up-to trixanth_dashboard
```

## What the dashboard talks to

Only topics and services that exist in this workspace:

- Subscribes: `/trixanth/mode` (drive-mode badge), `/trixanth/kill_switch`, `/red_zone/visible`, `/abex/*` sensors (soil/air temperature, humidity, pressure, pH, soil moisture), `/odometry/global`, `/trixanth/battery`, `/imu/data`, `/gps/fix`, `/map`, `/plan`, `/diagnostics_agg`, `/rosout`,
  `/rado/status`, `/mission/state`, `/mission/alert`, `/mission/score`, `/perception/detections`, `/perception/marker`,
  `/recon/entry`, `/trixanth/link_ok`, `/trixanth/link_age`, `/trixanth/autonomy_violations`, `/trixanth/mode_event`, camera images.
- Publishes: `/cmd_vel_teleop` (through `command_gate`, so mode and kill-switch lockout apply), `/goal_pose`, `/ground/heartbeat` (5 Hz).
- Services: `/abex/new_site`, `/abex/record`, `/abex/closeup`, `/abex/pano_start`, `/abex/pano_stop`, `/set_mode` (the header STOP button sends ESTOP/IDLE), `/mission/start`, `/mission/stop`, `/mission/comms_penalty`,
  `/recon/capture`, `/rado/start_delivery`, `/rado/abort`, `/rado/list`.

## Front camera (RealSense D435i)

`trixanth_bringup/robot.launch.py` starts the driver (topics `/camera/color/image_raw`, `/camera/depth/image_rect_raw`,
`/camera/infra1/image_rect_raw`); `web_video_server` turns any image topic into an MJPEG stream the page shows in an `<img>`.
Raw depth is 16UC1 and cannot be JPEG-streamed, so `depth_preview` publishes a colour-mapped copy on `/camera/depth/preview`
(only computed while the dashboard is watching it). The "RGB Color / Depth Map / Infrared IR" buttons on the front camera
switch between the three topics. Quick check without the dashboard:
`http://<rover>:8080/stream?topic=/camera/color/image_raw&type=mjpeg` in a browser tab.

## Known gaps

- Panels for wheel, electrical, sector-antenna, arm and ML telemetry have no publisher in the workspace. They still render
  their built-in placeholder values (kept on purpose for now), so **treat those numbers as not real**.
- `/trixanth_safety/soft_stop`, reset-odometry and IMU-calibrate no longer exist in the UI; no node provides them.
- Not run against real ROS 2 here: only `pytest` (launch-manager logic, web server) and the frontend build were run.
