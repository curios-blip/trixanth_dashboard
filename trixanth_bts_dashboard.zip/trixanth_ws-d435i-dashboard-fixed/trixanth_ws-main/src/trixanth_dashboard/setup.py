import os
from glob import glob

from setuptools import find_packages, setup

package_name = "trixanth_dashboard"


def data_dir(src, dest):
    """Install every file under src/ to share/<pkg>/<dest>/..., keeping subfolders."""
    out = {}
    for f in glob(os.path.join(src, "**", "*"), recursive=True):
        if os.path.isfile(f):
            target = os.path.join("share", package_name, dest, os.path.relpath(os.path.dirname(f), src))
            out.setdefault(os.path.normpath(target), []).append(f)
    return list(out.items())


data_files = [
    ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
    ("share/" + package_name, ["package.xml"]),
    ("share/" + package_name + "/launch", glob("launch/*.py")),
]
# The built frontend (frontend/dist copied to web/ by scripts/build_frontend.sh).
data_files += data_dir("web", "web")

setup(
    name=package_name,
    version="0.1.0",
    packages=find_packages(exclude=["test"]),
    data_files=data_files,
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="Team Trixanth",
    maintainer_email="trixanth@example.com",
    description="Ground-station web dashboard and launch manager.",
    license="Apache-2.0",
    tests_require=["pytest"],
    entry_points={
        "console_scripts": [
            "launch_manager = trixanth_dashboard.launch_manager:main",
            "web_server = trixanth_dashboard.web_server:main",
            "depth_preview = trixanth_dashboard.depth_preview:main",
        ],
    },
)
