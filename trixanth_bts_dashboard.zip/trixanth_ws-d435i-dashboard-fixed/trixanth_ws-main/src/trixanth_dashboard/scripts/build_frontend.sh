#!/usr/bin/env bash
# Rebuild the dashboard and copy it into web/ so colcon installs it.
# Needs Node 18+ (run on any machine, the Jetson does not need Node at runtime).
#   VITE_ROVER_HOST=192.168.10.2 scripts/build_frontend.sh    # optional: bake in the rover address
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
cd "$here/frontend"
npm ci
npm run build
rm -rf "$here/web"
mkdir -p "$here/web"
cp -r dist/. "$here/web/"
echo "Copied frontend/dist -> web/. Now: colcon build --packages-select trixanth_dashboard"
