import { useEffect, useRef, useState } from 'react'
import ROSLIB from 'roslib'
import { config, DEMO } from './config'
import * as mock from './mock/mockRos'

// One shared rosbridge connection for the whole app. roslibjs does not
// reconnect on its own, so we rebuild the socket on close.

let ros = null
const listeners = new Set()
let status = DEMO ? 'demo' : 'connecting'

function setStatus(next) {
  status = next
  listeners.forEach((fn) => fn(next))
}

function connect() {
  ros = new ROSLIB.Ros({ url: config.rosbridgeUrl })
  ros.on('connection', () => setStatus('connected'))
  ros.on('error', () => setStatus('error'))
  ros.on('close', () => {
    setStatus('disconnected')
    setTimeout(connect, 2000)
  })
}

export function getRos() {
  if (!ros && !DEMO) connect()
  return ros
}

if (DEMO) mock.start()

export function useRosStatus() {
  const [s, setS] = useState(status)
  useEffect(() => {
    if (DEMO) return
    getRos()
    listeners.add(setS)
    return () => listeners.delete(setS)
  }, [])
  return s
}

export const isLive = () => (DEMO ? true : status === 'connected')

// ------------------------------------------------------------- subscriptions

function rawSubscribe({ name, type }, cb, throttle, queue = 1) {
  if (DEMO) return mock.subscribe(name, cb)
  const topic = new ROSLIB.Topic({
    ros: getRos(),
    name,
    messageType: type,
    throttle_rate: throttle,
    queue_length: queue,
  })
  topic.subscribe(cb)
  return () => topic.unsubscribe()
}

/** Plain subscription for event streams where every message matters (no throttle). */
export function subscribeTopic(spec, cb) {
  return rawSubscribe(spec, cb, 0, 0)
}

/** Subscribe and re-render on each message. Use for low-rate readouts. */
export function useTopic(spec, { throttle = 200 } = {}) {
  const [msg, setMsg] = useState(null)
  useEffect(() => rawSubscribe(spec, setMsg, throttle), [spec.name, spec.type, throttle])
  return msg
}

/** Subscribe without re-rendering. Use for canvas draws and high-rate data. */
export function useTopicCallback(spec, cb, { throttle = 100 } = {}) {
  const ref = useRef(cb)
  ref.current = cb
  useEffect(
    () => rawSubscribe(spec, (m) => ref.current(m), throttle),
    [spec.name, spec.type, throttle]
  )
}

/** Keep a rolling buffer of the last `size` messages. */
export function useTopicBuffer(spec, size = 200, { throttle = 200, paused = false } = {}) {
  const [items, setItems] = useState([])
  const pausedRef = useRef(paused)
  pausedRef.current = paused
  useEffect(
    () =>
      rawSubscribe(
        spec,
        (m) => {
          if (pausedRef.current) return
          setItems((prev) => [...prev.slice(-(size - 1)), { ...m, _rx: Date.now() }])
        },
        throttle
      ),
    [spec.name, spec.type, size, throttle]
  )
  return items
}

// ---------------------------------------------------------------- publishing

export function makePublisher({ name, type }) {
  if (DEMO) return { publish: (msg) => mock.publishTo(name, msg) }
  const topic = new ROSLIB.Topic({ ros: getRos(), name, messageType: type })
  return { publish: (msg) => topic.publish(new ROSLIB.Message(msg)) }
}

export function publishTo(specOrName, msg) {
  const name = typeof specOrName === 'string' ? specOrName : specOrName?.name
  const type = typeof specOrName === 'object' ? specOrName?.type : 'std_msgs/msg/String'
  if (DEMO) return mock.publishTo(name, msg)
  const topic = new ROSLIB.Topic({ ros: getRos(), name, messageType: type })
  topic.publish(new ROSLIB.Message(msg))
}

export function callService({ name, type }, request = {}) {
  if (DEMO) return mock.callService(name, request)
  return new Promise((resolve, reject) => {
    const svc = new ROSLIB.Service({ ros: getRos(), name, serviceType: type })
    svc.callService(new ROSLIB.ServiceRequest(request), resolve, reject)
  })
}

/** Ask rosapi what exists, so camera feeds are discovered rather than hardcoded. */
export function listTopics() {
  if (DEMO) return mock.listTopics()
  return new Promise((resolve, reject) => {
    const svc = new ROSLIB.Service({
      ros: getRos(),
      name: '/rosapi/topics',
      serviceType: 'rosapi/Topics',
    })
    svc.callService(
      new ROSLIB.ServiceRequest({}),
      (res) => resolve(res.topics.map((t, i) => ({ name: t, type: res.types?.[i] }))),
      reject
    )
  })
}

/** Topic names currently advertised on the ROS graph (null until rosapi answers). */
export function useAdvertisedTopics(intervalMs = 5000) {
  const [names, setNames] = useState(null)
  useEffect(() => {
    let alive = true
    const poll = async () => {
      try {
        const t = await listTopics()
        if (alive) setNames(new Set(t.map((x) => x.name)))
      } catch {
        if (alive) setNames(null)
      }
    }
    poll()
    const id = setInterval(poll, intervalMs)
    return () => {
      alive = false
      clearInterval(id)
    }
  }, [intervalMs])
  return names
}

/**
 * Measure a real round trip. kind 'ros' times a rosapi service call through
 * rosbridge; kind 'http' times a request to `url`. Returns { up, ms } where
 * up is null until the first answer.
 */
export function useRoundTrip(kind, url, intervalMs = 3000) {
  const [state, setState] = useState({ up: null, ms: null })
  useEffect(() => {
    if (DEMO) return
    let alive = true
    const probe = async () => {
      const t0 = performance.now()
      try {
        if (kind === 'ros') {
          if (status !== 'connected') throw new Error('not connected')
          await new Promise((resolve, reject) => {
            const svc = new ROSLIB.Service({ ros: getRos(), name: '/rosapi/get_time', serviceType: 'rosapi/GetTime' })
            const timer = setTimeout(() => reject(new Error('timeout')), 2500)
            svc.callService(new ROSLIB.ServiceRequest({}), () => { clearTimeout(timer); resolve() }, (e) => { clearTimeout(timer); reject(e) })
          })
        } else {
          const ctl = new AbortController()
          const timer = setTimeout(() => ctl.abort(), 2500)
          try {
            await fetch(url, { mode: 'no-cors', cache: 'no-store', signal: ctl.signal })
          } finally {
            clearTimeout(timer)
          }
        }
        if (alive) setState({ up: true, ms: Math.round(performance.now() - t0) })
      } catch {
        if (alive) setState({ up: false, ms: null })
      }
    }
    probe()
    const id = setInterval(probe, intervalMs)
    return () => {
      alive = false
      clearInterval(id)
    }
  }, [kind, url, intervalMs])
  return state
}

/** Read a ROS parameter through rosapi, e.g. '/robot_state_publisher:robot_description'. */
export function getParam(name) {
  if (DEMO) return Promise.resolve(null)
  return new Promise((resolve, reject) => {
    const svc = new ROSLIB.Service({ ros: getRos(), name: '/rosapi/get_param', serviceType: 'rosapi/GetParam' })
    svc.callService(
      new ROSLIB.ServiceRequest({ name, default: '' }),
      (res) => {
        const v = res?.value
        if (v == null || v === '' || v === 'null') return resolve(null)
        try { resolve(JSON.parse(v)) } catch { resolve(v) }
      },
      reject
    )
  })
}

// -------------------------------------------------------------------- maths

export function yawFrom(q) {
  if (!q) return 0
  const { x, y, z, w } = q
  return Math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
}

export const quatFromYaw = (yaw) => ({
  x: 0,
  y: 0,
  z: Math.sin(yaw / 2),
  w: Math.cos(yaw / 2),
})
