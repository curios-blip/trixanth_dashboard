// Everything site-specific lives here. Defaults assume the dashboard is served
// from the Jetson; override with frontend/.env.local if you serve it elsewhere.

const host =
  window.__TRIXANTH_HOST__ || import.meta.env.VITE_ROVER_HOST || window.location.hostname

// Demo mode runs the whole UI against simulated data — no rover, no rosbridge.
// Toggle it from the header; it persists and reloads.
const params = new URLSearchParams(window.location.search)
if (params.has('demo')) {
  localStorage.setItem('trixanth.demo', params.get('demo') === '0' ? '0' : '1')
}
export const DEMO =
  localStorage.getItem('trixanth.demo') === '1' || import.meta.env.VITE_DEMO === '1'

export function setDemo(on) {
  localStorage.setItem('trixanth.demo', on ? '1' : '0')
  window.location.href = window.location.pathname
}

export const config = {
  roverName: 'Trixanth',

  rosbridgeUrl: `ws://${host}:9090`,
  videoServerUrl: `http://${host}:8080`,
  launchManagerUrl: `http://${host}:8000`,
  launchManagerWs: `ws://${host}:8000`,

  // --- topics -------------------------------------------------------------
  // Every topic below has a publisher or subscriber in trixanth_ws (see CONNECTIONS.md).
  topics: {
    odom: { name: '/odometry/global', type: 'nav_msgs/msg/Odometry' },
    map: { name: '/map', type: 'nav_msgs/msg/OccupancyGrid' },
    globalPlan: { name: '/plan', type: 'nav_msgs/msg/Path' },
    goalPose: { name: '/goal_pose', type: 'geometry_msgs/msg/PoseStamped' },
    battery: { name: '/trixanth/battery', type: 'sensor_msgs/msg/BatteryState' },
    imu: { name: '/imu/data', type: 'sensor_msgs/msg/Imu' },
    gps: { name: '/gps/fix', type: 'sensor_msgs/msg/NavSatFix' },
    diagnostics: { name: '/diagnostics_agg', type: 'diagnostic_msgs/msg/DiagnosticArray' },
    rosout: { name: '/rosout', type: 'rcl_interfaces/msg/Log' },
    fsmState: { name: '/rado/status', type: 'std_msgs/msg/String' },
    // Intel RealSense D435i (realsense-ros / librealsense2 2.58.3 on ROS 2 Jazzy)
    realsenseColor: { name: '/camera/color/image_raw', type: 'sensor_msgs/msg/Image' },
    realsenseDepth: { name: '/camera/depth/image_rect_raw', type: 'sensor_msgs/msg/Image' },
    realsenseInfra1: { name: '/camera/infra1/image_rect_raw', type: 'sensor_msgs/msg/Image' },
    realsenseImu: { name: '/camera/imu', type: 'sensor_msgs/msg/Imu' },
    missionState: { name: '/mission/state', type: 'trixanth_interfaces/msg/MissionState' },
    missionAlert: { name: '/mission/alert', type: 'std_msgs/msg/String' },
    scoreEvent: { name: '/mission/score', type: 'trixanth_interfaces/msg/ScoreEvent' },
    detections: { name: '/perception/detections', type: 'trixanth_interfaces/msg/DetectionArray' },
    marker: { name: '/perception/marker', type: 'trixanth_interfaces/msg/MarkerObservation' },
    reconEntry: { name: '/recon/entry', type: 'trixanth_interfaces/msg/ReconEntry' },
    modeEvent: { name: '/trixanth/mode_event', type: 'std_msgs/msg/String' },
    autonomyViolations: { name: '/trixanth/autonomy_violations', type: 'std_msgs/msg/UInt32' },
    linkOk: { name: '/trixanth/link_ok', type: 'std_msgs/msg/Bool' },
    linkAge: { name: '/trixanth/link_age', type: 'std_msgs/msg/Float32' },
    killSwitch: { name: '/trixanth/kill_switch', type: 'std_msgs/msg/Bool' },
    radoStatus: { name: '/rado/status', type: 'std_msgs/msg/String' },
    armStatus: { name: '/arm/status', type: 'std_msgs/msg/String' },
    cmdVelAuto: { name: '/cmd_vel_auto', type: 'geometry_msgs/msg/Twist' },
    groundHeartbeat: { name: '/ground/heartbeat', type: 'std_msgs/msg/Header' },
    cmdVelTeleop: { name: '/cmd_vel_teleop', type: 'geometry_msgs/msg/Twist' },
    // command_gate: the single owner of drive mode (transient-local, UInt8 0..3)
    mode: { name: '/trixanth/mode', type: 'std_msgs/msg/UInt8' },
    // trixanth_red_zone
    redZoneVisible: { name: '/red_zone/visible', type: 'std_msgs/msg/Bool' },
    // trixanth_hardware sensor_bridge -> trixanth_science site_logger (ABEx)
    abexSoilTemp: { name: '/abex/soil_temperature', type: 'sensor_msgs/msg/Temperature' },
    abexAirTemp: { name: '/abex/air_temperature', type: 'sensor_msgs/msg/Temperature' },
    abexHumidity: { name: '/abex/humidity', type: 'sensor_msgs/msg/RelativeHumidity' },
    abexPressure: { name: '/abex/pressure', type: 'sensor_msgs/msg/FluidPressure' },
    abexPh: { name: '/abex/ph', type: 'std_msgs/msg/Float32' },
    abexSoilMoisture: { name: '/abex/soil_moisture', type: 'std_msgs/msg/Float32' },


  },

  // Links shown in the header. Status and latency are measured at runtime
  // (rosbridge connection, /trixanth/link_age, HTTP probes); nothing here is a reading.
  links: [
    { id: 'rosbridge', name: 'rosbridge WebSocket', shortName: 'ROS', port: 9090 },
    { id: 'safety', name: 'Safety heartbeat (link_monitor)', shortName: 'Safety', port: null },
    { id: 'camera', name: 'Video server (web_video_server)', shortName: 'Video', port: 8080 },
    { id: 'launch', name: 'Launch manager', shortName: 'Launch', port: 8000 },
  ],

  // 5 Subsystems as specified:
  // 1. General (view of all subsystems)
  // 2. ML (locomotion camera feed, relative operations & operations logs: moved X meters, turning left/right, global & local logs)
  // 3. Electrical (battery level of each component, power draining per component)
  // 4. Cams and Comms (sector antenna working status & RF links)
  // 5. Arm for RADO (arm operations for RADO mission & arm camera feed)
  subsystems: [
    { id: 'general', name: 'General Overview', code: 'GEN', lead: 'All Subsystems View & Health' },
    { id: 'ml', name: 'ML & Locomotion', code: 'ML', lead: 'Locomotion Feed, Relative Ops & Dual Logs' },
    { id: 'electrical', name: 'Electrical & Power', code: 'ELEC', lead: 'Component Batteries & Power Draw' },
    { id: 'cams_comms', name: 'Cams & Comms', code: 'COMS', lead: 'Sector Antenna & 5-Camera Feeds' },
    { id: 'arm_rado', name: 'Arm for RADO', code: 'RADO', lead: 'Manipulator & RADO Mission Delivery' },
    { id: 'abex', name: 'ABEx Science', code: 'ABEX', lead: 'Site Sensors, Close-ups & Panorama' },
  ],

  // trixanth_interfaces Mode Constants
  MODES: {
    IDLE: 0,
    MANUAL: 1,
    AUTONOMOUS: 2,
    ESTOP: 3,
  },
  MODE_NAMES: ['IDLE', 'MANUAL', 'AUTONOMOUS', 'ESTOP'],

  services: {
    clearCostmaps: {
      name: '/global_costmap/clear_entirely_global_costmap',
      type: 'nav2_msgs/srv/ClearEntireCostmap',
    },

    // trixanth_interfaces services
    setMode: { name: '/set_mode', type: 'trixanth_interfaces/srv/SetMode' },
    startMission: { name: '/mission/start', type: 'trixanth_interfaces/srv/StartMission' },
    stopMission: { name: '/mission/stop', type: 'std_srvs/srv/Trigger' },
    commsPenalty: { name: '/mission/comms_penalty', type: 'std_srvs/srv/Trigger' },
    // trixanth_science (ABEx)
    abexNewSite: { name: '/abex/new_site', type: 'std_srvs/srv/Trigger' },
    abexRecord: { name: '/abex/record', type: 'std_srvs/srv/Trigger' },
    abexCloseup: { name: '/abex/closeup', type: 'std_srvs/srv/Trigger' },
    abexPanoStart: { name: '/abex/pano_start', type: 'std_srvs/srv/Trigger' },
    abexPanoStop: { name: '/abex/pano_stop', type: 'std_srvs/srv/Trigger' },
    reconCapture: { name: '/recon/capture', type: 'std_srvs/srv/Trigger' },
    radoStartDelivery: { name: '/rado/start_delivery', type: 'std_srvs/srv/Trigger' },
    radoAbort: { name: '/rado/abort', type: 'std_srvs/srv/Trigger' },
    radoList: { name: '/rado/list', type: 'std_srvs/srv/Trigger' },
  },

  // Intel RealSense D435i Metadata
  realsense: {
    model: 'Intel RealSense D435i',
    sdk: 'librealsense2 v2.58.3',
    rosDistro: 'ROS 2 Jazzy Jalisco',
    wrapper: 'realsense-ros v4.56.1',
    repo: 'https://github.com/realsenseai/realsense-ros',
  },

  // 5 Cameras: 1 RealSense D435i (Depth & RGB in front) + 4 Webcams (Back, Manipulator, Left Side, Right Side)
  cameras: [
    {
      id: 'front',
      name: 'front',
      topic: '/camera/color/image_raw',
      fallbackTopic: '/camera_front/image_raw',
      depthTopic: '/camera/depth/image_rect_raw',
      // web_video_server cannot stream raw 16UC1 depth; trixanth_dashboard's depth_preview node
      // publishes a colour-mapped bgr8 copy here, and the "Depth Map" button streams that.
      depthPreviewTopic: '/camera/depth/preview',
      infraTopic: '/camera/infra1/image_rect_raw',
      label: 'Front RealSense D435i',
      shortLabel: 'Front (D435i)',
      model: 'Intel RealSense D435i',
      sdk: 'librealsense2 2.58.3',
      type: 'depth_rgb',
    },
    {
      id: 'rear',
      name: 'rear',
      topic: '/camera_rear/image_raw',
      label: 'Rear Back Webcam',
      shortLabel: 'Rear Cam',
      type: 'webcam',
    },
    {
      id: 'arm',
      name: 'arm',
      topic: '/camera_arm/image_raw',
      label: 'Manipulator Arm Webcam',
      shortLabel: 'Arm Cam',
      type: 'webcam',
    },
    {
      id: 'left',
      name: 'left',
      topic: '/camera_left/image_raw',
      label: 'Rover Left Side Webcam',
      shortLabel: 'Left Cam',
      type: 'webcam',
    },
    {
      id: 'right',
      name: 'right',
      topic: '/camera_right/image_raw',
      label: 'Rover Right Side Webcam',
      shortLabel: 'Right Cam',
      type: 'webcam',
    },
  ],

  // Detection boxes arrive in source-image pixels
  detectionSourceSize: { width: 640, height: 480 },

  // Teleop limits. Keep these conservative; the rover is heavy.
  teleop: { maxLinear: 0.6, maxAngular: 0.9, rateHz: 10 },

  // Battery thresholds for the header warning (volts, 6S Li-ion nominal 22.2).
  battery: { warn: 21.0, critical: 19.8 },
}

