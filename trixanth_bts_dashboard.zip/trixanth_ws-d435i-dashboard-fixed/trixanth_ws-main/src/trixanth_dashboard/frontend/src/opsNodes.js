// Topic contracts per subsystem, taken from the package READMEs.
// Pills are checked against the live ROS graph at runtime; nothing here is a reading.
export const SUBSYSTEM_ROS_NODES = {
  general: {
    subscribed: [
      { node: 'mission_monitor', topic: '/mission/score', type: 'trixanth_interfaces/ScoreEvent' },
      { node: 'mission_monitor', topic: '/trixanth/mode', type: 'std_msgs/UInt8' },
      { node: 'link_monitor', topic: '/ground/heartbeat', type: 'std_msgs/Header' },
      { node: 'ekf_filter_node', topic: '/imu/data', type: 'sensor_msgs/Imu' },
      { node: 'ekf_filter_node', topic: '/gps/fix', type: 'sensor_msgs/NavSatFix' },
      { node: 'ekf_filter_node', topic: '/odom/wheel', type: 'nav_msgs/Odometry' },
    ],
    publishing: [
      { node: 'mission_monitor', topic: '/mission/state', type: 'trixanth_interfaces/MissionState' },
      { node: 'mission_monitor', topic: '/mission/alert', type: 'std_msgs/String' },
      { node: 'command_gate', topic: '/trixanth/mode', type: 'std_msgs/UInt8' },
      { node: 'command_gate', topic: '/trixanth/mode_event', type: 'std_msgs/String' },
      { node: 'command_gate', topic: '/trixanth/autonomy_violations', type: 'std_msgs/UInt32' },
      { node: 'link_monitor', topic: '/trixanth/link_ok', type: 'std_msgs/Bool' },
      { node: 'link_monitor', topic: '/trixanth/link_age', type: 'std_msgs/Float32' },
    ],
  },
  ml: {
    subscribed: [
      { node: 'command_gate', topic: '/cmd_vel_auto', type: 'geometry_msgs/Twist' },
      { node: 'command_gate', topic: '/cmd_vel_teleop', type: 'geometry_msgs/Twist' },
      { node: 'object_detector', topic: '/camera/color/image_raw', type: 'sensor_msgs/Image' },
      { node: 'recon_logger', topic: '/perception/detections', type: 'trixanth_interfaces/DetectionArray' },
    ],
    publishing: [
      { node: 'command_gate', topic: '/cmd_vel', type: 'geometry_msgs/Twist' },
      { node: 'object_detector', topic: '/perception/detections', type: 'trixanth_interfaces/DetectionArray' },
      { node: 'recon_logger', topic: '/recon/entry', type: 'trixanth_interfaces/ReconEntry' },
    ],
  },
  electrical: {
    subscribed: [
      { node: 'base_bridge', topic: '/cmd_vel', type: 'geometry_msgs/Twist' },
    ],
    publishing: [
      { node: 'base_bridge', topic: '/odom/wheel', type: 'nav_msgs/Odometry' },
      { node: 'base_bridge', topic: '/imu/data', type: 'sensor_msgs/Imu' },
      { node: 'base_bridge', topic: '/trixanth/kill_switch', type: 'std_msgs/Bool' },
      { node: 'base_bridge', topic: '/trixanth/battery', type: 'sensor_msgs/BatteryState' },
    ],
  },
  cams_comms: {
    subscribed: [
      { node: 'command_gate', topic: '/cmd_vel_teleop', type: 'geometry_msgs/Twist' },
      { node: 'command_gate', topic: '/trixanth/link_ok', type: 'std_msgs/Bool' },
      { node: 'link_monitor', topic: '/ground/heartbeat', type: 'std_msgs/Header' },
    ],
    publishing: [
      { node: 'command_gate', topic: '/trixanth/mode_event', type: 'std_msgs/String' },
      { node: 'link_monitor', topic: '/trixanth/link_ok', type: 'std_msgs/Bool' },
      { node: 'link_monitor', topic: '/trixanth/link_age', type: 'std_msgs/Float32' },
      { node: 'realsense2_camera', topic: '/camera/color/image_raw', type: 'sensor_msgs/Image' },
      { node: 'realsense2_camera', topic: '/camera/depth/image_rect_raw', type: 'sensor_msgs/Image' },
      { node: 'cam_streamers', topic: '/camera_rear/image_raw', type: 'sensor_msgs/Image' },
      { node: 'cam_streamers', topic: '/camera_arm/image_raw', type: 'sensor_msgs/Image' },
      { node: 'cam_streamers', topic: '/camera_left/image_raw', type: 'sensor_msgs/Image' },
      { node: 'cam_streamers', topic: '/camera_right/image_raw', type: 'sensor_msgs/Image' },
    ],
  },
  arm_rado: {
    subscribed: [
      { node: 'rado_fsm', topic: '/perception/marker', type: 'trixanth_interfaces/MarkerObservation' },
      { node: 'rado_fsm', topic: '/arm/status', type: 'std_msgs/String' },
      { node: 'rado_fsm', topic: '/trixanth/mode', type: 'std_msgs/UInt8' },
    ],
    publishing: [
      { node: 'rado_fsm', topic: '/cmd_vel_auto', type: 'geometry_msgs/Twist' },
      { node: 'rado_fsm', topic: '/rado/status', type: 'std_msgs/String' },
      { node: 'rado_fsm', topic: '/arm/command', type: 'std_msgs/String' },
      { node: 'marker_detector', topic: '/perception/marker', type: 'trixanth_interfaces/MarkerObservation' },
      { node: 'recon_logger', topic: '/recon/entry', type: 'trixanth_interfaces/ReconEntry' },
    ],
  },
  abex: {
    subscribed: [
      { node: 'site_logger', topic: '/abex/soil_temperature', type: 'sensor_msgs/Temperature' },
      { node: 'site_logger', topic: '/abex/soil_moisture', type: 'std_msgs/Float32' },
      { node: 'site_logger', topic: '/abex/ph', type: 'std_msgs/Float32' },
      { node: 'site_logger', topic: '/gps/fix', type: 'sensor_msgs/NavSatFix' },
      { node: 'panorama', topic: '/odometry/global', type: 'nav_msgs/Odometry' },
    ],
    publishing: [
      { node: 'sensor_bridge', topic: '/abex/soil_temperature', type: 'sensor_msgs/Temperature' },
      { node: 'sensor_bridge', topic: '/abex/air_temperature', type: 'sensor_msgs/Temperature' },
      { node: 'sensor_bridge', topic: '/abex/humidity', type: 'sensor_msgs/RelativeHumidity' },
      { node: 'sensor_bridge', topic: '/abex/pressure', type: 'sensor_msgs/FluidPressure' },
      { node: 'sensor_bridge', topic: '/abex/ph', type: 'std_msgs/Float32' },
      { node: 'sensor_bridge', topic: '/abex/soil_moisture', type: 'std_msgs/Float32' },
    ],
  },
}
