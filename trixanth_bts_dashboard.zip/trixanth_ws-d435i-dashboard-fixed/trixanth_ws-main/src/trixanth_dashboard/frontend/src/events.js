// Operator event feed built only from real ROS traffic. Nothing is seeded:
// the list starts empty and fills as messages arrive.
import { useSyncExternalStore } from 'react'
import { config } from './config'
import { subscribeTopic } from './ros'

let events = []
let started = false
const listeners = new Set()
let seq = 0

function push(e) {
  events = [{ id: ++seq, ts: Date.now(), time: new Date().toLocaleTimeString('en-GB'), level: 'INFO', ...e }, ...events].slice(0, 200)
  listeners.forEach((l) => l())
}

export function startEvents() {
  if (started) return
  started = true
  const T = config.topics
  const last = {}
  const onChange = (key, val) => {
    if (last[key] === val) return false
    const first = !(key in last)
    last[key] = val
    return !first // the first value only primes the comparison
  }

  subscribeTopic(T.modeEvent, (m) =>
    m?.data && push({ scope: 'global', tag: 'GATE/MODE', text: m.data, subs: ['general', 'cams_comms'] }))

  subscribeTopic(T.missionAlert, (m) =>
    m?.data && onChange('alert', m.data) &&
    push({ scope: 'global', tag: 'MISSION/ALERT', level: 'WARN', text: m.data, subs: ['general', 'arm_rado'] }))

  subscribeTopic(T.scoreEvent, (m) =>
    m?.task && push({ scope: 'global', tag: 'MISSION/SCORE', text: `${m.task}: +${m.points} pts`, subs: ['general', 'arm_rado'] }))

  subscribeTopic(T.reconEntry, (m) =>
    m?.id != null && push({
      scope: 'local', tag: 'RADO/RECON', subs: ['arm_rado', 'ml'],
      text: `#${m.id} ${m.label} (${Math.round((m.confidence ?? 0) * 100)}%) at ${m.latitude?.toFixed?.(5)}, ${m.longitude?.toFixed?.(5)}`,
    }))

  subscribeTopic(T.radoStatus, (m) =>
    m?.data && onChange('rado', m.data) &&
    push({ scope: 'local', tag: 'RADO/FSM', text: m.data, subs: ['arm_rado', 'general'] }))

  subscribeTopic(T.armStatus, (m) =>
    m?.data && onChange('arm', m.data) &&
    push({ scope: 'local', tag: 'RADO/ARM', text: m.data, subs: ['arm_rado'] }))

  subscribeTopic(T.killSwitch, (m) =>
    m && typeof m.data === 'boolean' && onChange('kill', m.data) &&
    push({
      scope: 'global', tag: 'ELEC/KILL', level: m.data ? 'WARN' : 'INFO',
      text: m.data ? 'Kill switch: motor bus contactor OPEN' : 'Kill switch released',
      subs: ['electrical', 'general'],
    }))

  subscribeTopic(T.linkOk, (m) =>
    m && typeof m.data === 'boolean' && onChange('link', m.data) &&
    push({
      scope: 'global', tag: 'COMMS/LINK', level: m.data ? 'INFO' : 'ERROR',
      text: m.data ? 'Ground heartbeat restored' : 'Ground heartbeat lost',
      subs: ['cams_comms', 'general'],
    }))

  subscribeTopic(T.rosout, (m) => {
    if (!m || m.level < 30) return
    push({
      scope: 'global', tag: m.name || 'rosout', level: m.level >= 40 ? 'ERROR' : 'WARN',
      text: m.msg, subs: ['general', 'ml', 'electrical', 'cams_comms', 'arm_rado'],
    })
  })
}

const subscribe = (l) => { listeners.add(l); return () => listeners.delete(l) }

/** Real events relevant to a subsystem, newest first. */
export function useOpsEvents(subsystemId) {
  startEvents()
  const all = useSyncExternalStore(subscribe, () => events)
  return all.filter((e) => !e.subs || e.subs.includes(subsystemId))
}
