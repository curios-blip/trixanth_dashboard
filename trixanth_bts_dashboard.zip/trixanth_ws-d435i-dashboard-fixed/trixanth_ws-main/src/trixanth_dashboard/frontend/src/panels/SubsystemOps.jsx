import { useState, useEffect } from 'react'
import { config } from '../config'
import { useTopic, callService, publishTo, useAdvertisedTopics, useRosStatus } from '../ros'
import { useOpsEvents } from '../events'
import { useDistanceDriven } from '../hooks/useDerived'
import { SUBSYSTEM_ROS_NODES } from '../opsNodes'
import { Readout, fmt, Chip, Dot } from '../components/ui'
import CameraView from './CameraView'
import './SubsystemOps.extra.css'
import {
  getSubsystemIcon,
  IconRover,
  IconArm,
  IconTelemetry,
  IconBroadcast,
  IconGlobe,
  IconSwap,
  IconPiP,
  IconMaximize,
  IconTerminal,
  IconLogs,
  IconReady,
  IconStow,
  IconLock,
  IconUnlock,
} from '../components/Icons'

// Every value on these views comes from a ROS message, a measurement made in the
// browser, or arithmetic on those. When a source is silent the view shows "—".
// Nothing is defaulted, seeded or estimated.

const SUBSYSTEM_LIST = [
  { id: 'general', name: 'General Overview', code: 'GEN', lead: 'All Subsystems View & Health' },
  { id: 'ml', name: 'ML & Locomotion', code: 'ML', lead: 'Locomotion Feed, Relative Ops & Logs' },
  { id: 'electrical', name: 'Electrical & Power', code: 'ELEC', lead: 'Battery & Kill Switch' },
  { id: 'cams_comms', name: 'Cams & Comms', code: 'COMS', lead: 'Link Health & 5-Camera Feeds' },
  { id: 'arm_rado', name: 'Arm for RADO', code: 'RADO', lead: 'RADO Mission & Arm Camera' },
  { id: 'abex', name: 'ABEx Science', code: 'ABEX', lead: 'Site Sensors, Close-ups & Panorama' },
]

const MODE_NAMES = config.MODE_NAMES
const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null)
const dash = (v, f = (x) => x) => (v == null ? '—' : f(v))
const fmtTime = (sec) =>
  sec == null ? '—' : `${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, '0')}`
const modeClassOf = (idx) => (idx === 3 ? 'fault' : idx === 2 ? 'ok' : idx === 1 ? 'warn' : '')

/** Plain-words description of what the rover is doing, from a real Twist. */
function describeMotion(tw) {
  if (!tw) return null
  const lin = tw.linear?.x ?? 0
  const ang = tw.angular?.z ?? 0
  const parts = []
  if (lin > 0.02) parts.push('FORWARD')
  else if (lin < -0.02) parts.push('REVERSE')
  if (ang > 0.05) parts.push('TURNING LEFT')
  else if (ang < -0.05) parts.push('TURNING RIGHT')
  return parts.length ? parts.join(' + ') : 'STOPPED'
}

/** Run a ROS service and report a failure instead of swallowing it. */
function useServiceRunner() {
  const [note, setNote] = useState(null)
  const run = async (spec, req = {}) => {
    try {
      const r = await callService(spec, req)
      setNote(r && r.success === false ? `${spec.name}: ${r.message || 'refused'}` : null)
    } catch {
      setNote(`${spec.name} did not respond (is the node running?)`)
    }
  }
  return [run, note]
}

export default function SubsystemOps({
  activeSubsystem = 'general',
  onSelectSubsystem = null,
  onFocusCamera = null,
  onOpenPiP = null,
  hideInlineLogs = false,
}) {
  const [currentSub, setCurrentSub] = useState(activeSubsystem || 'general')

  useEffect(() => {
    if (activeSubsystem) setCurrentSub(activeSubsystem)
  }, [activeSubsystem])

  const handleSubSwitch = (subId) => {
    setCurrentSub(subId)
    if (onSelectSubsystem) onSelectSubsystem(subId)
  }

  // Live topic subscriptions
  const odom = useTopic(config.topics.odom, { throttle: 200 })
  const battery = useTopic(config.topics.battery, { throttle: 500 })
  const imu = useTopic(config.topics.imu, { throttle: 200 })
  const gps = useTopic(config.topics.gps, { throttle: 1000 })
  const missionState = useTopic(config.topics.missionState, { throttle: 500 })
  const missionAlert = useTopic(config.topics.missionAlert, { throttle: 1000 })
  const markerObs = useTopic(config.topics.marker, { throttle: 300 })
  const radoStatus = useTopic(config.topics.radoStatus, { throttle: 500 })
  const armStatus = useTopic(config.topics.armStatus, { throttle: 500 })
  const linkOk = useTopic(config.topics.linkOk, { throttle: 500 })
  const linkAge = useTopic(config.topics.linkAge, { throttle: 500 })
  const killSwitch = useTopic(config.topics.killSwitch, { throttle: 500 })
  const redZone = useTopic(config.topics.redZoneVisible, { throttle: 500 })
  const autonomyViolations = useTopic(config.topics.autonomyViolations, { throttle: 1000 })

  const advertised = useAdvertisedTopics()
  const distance = useDistanceDriven(odom)

  return (
    <div className="minimal-subsystem-container">
      <div className="minimal-subnav-bar">
        <div className="minimal-pills-row">
          {SUBSYSTEM_LIST.map((sub) => {
            const isActive = currentSub === sub.id
            return (
              <button
                key={sub.id}
                type="button"
                className={`minimal-nav-pill ${isActive ? 'active' : ''}`}
                onClick={() => handleSubSwitch(sub.id)}
                title={sub.lead}
              >
                <span className="pill-icon">{getSubsystemIcon(sub.id, 13)}</span>
                <span className="pill-code mono">[{sub.code}]</span>
                <span className="pill-name">{sub.name}</span>
              </button>
            )
          })}
        </div>
      </div>

      {currentSub === 'general' && (
        <GeneralView
          odom={odom} battery={battery} gps={gps} missionState={missionState}
          missionAlert={missionAlert} linkOk={linkOk} linkAge={linkAge}
          killSwitch={killSwitch} radoStatus={radoStatus} armStatus={armStatus}
          markerObs={markerObs} autonomyViolations={autonomyViolations}
          advertised={advertised} distance={distance} redZone={redZone}
          onSelectSubsystem={handleSubSwitch} hideInlineLogs={hideInlineLogs}
        />
      )}

      {currentSub === 'ml' && (
        <MLView
          odom={odom} imu={imu} missionState={missionState} distance={distance} advertised={advertised}
          onFocusCamera={onFocusCamera} onOpenPiP={onOpenPiP} hideInlineLogs={hideInlineLogs}
        />
      )}

      {currentSub === 'electrical' && (
        <ElectricalView battery={battery} killSwitch={killSwitch} advertised={advertised} hideInlineLogs={hideInlineLogs} />
      )}

      {currentSub === 'cams_comms' && (
        <CamsCommsView
          linkOk={linkOk} linkAge={linkAge} advertised={advertised}
          onFocusCamera={onFocusCamera} onOpenPiP={onOpenPiP} hideInlineLogs={hideInlineLogs}
        />
      )}

      {currentSub === 'abex' && <AbexView advertised={advertised} hideInlineLogs={hideInlineLogs} />}

      {currentSub === 'arm_rado' && (
        <ArmRadoView
          missionState={missionState} markerObs={markerObs} radoStatus={radoStatus}
          armStatus={armStatus} autonomyViolations={autonomyViolations} advertised={advertised}
          onFocusCamera={onFocusCamera} onOpenPiP={onOpenPiP} hideInlineLogs={hideInlineLogs}
        />
      )}
    </div>
  )
}

// =============================================================================
// Topic contracts per subsystem, taken from the package READMEs. The pills are
// colour-coded against the live ROS graph: solid = advertised right now,
// dashed = not advertised (node not running).
// =============================================================================
const topicClass = (advertised, topic) =>
  advertised == null ? '' : advertised.has(topic) ? 'topic-live' : 'topic-absent'

// =============================================================================
// EVENT LOG: real messages only (/trixanth/mode_event, /mission/alert,
// /mission/score, /recon/entry, /rado/status, /arm/status, kill switch and link
// changes, /rosout warnings and errors). Operator notes stay on this page.
// =============================================================================
function SubsystemDualLogs({ subsystemId = 'general', subsystemCode = 'GEN', subsystemName = 'General Overview', advertised }) {
  const nodeDefs = SUBSYSTEM_ROS_NODES[subsystemId] || SUBSYSTEM_ROS_NODES.general
  const [logFilter, setLogFilter] = useState('all')
  const [newLogText, setNewLogText] = useState('')
  const [newLogScope, setNewLogScope] = useState('local')
  const [notes, setNotes] = useState([])
  const events = useOpsEvents(subsystemId)

  const logList = [...notes, ...events].sort((a, b) => b.ts - a.ts).slice(0, 200)

  const handleSendLog = (e) => {
    e.preventDefault()
    if (!newLogText.trim()) return
    const ts = Date.now()
    setNotes((prev) => [
      {
        id: `note-${ts}`, ts, scope: newLogScope, text: newLogText.trim(),
        time: new Date().toLocaleTimeString('en-GB'),
        tag: newLogScope === 'global' ? 'OPERATOR NOTE' : `OPERATOR NOTE/${subsystemCode}`,
        level: 'INFO',
      },
      ...prev,
    ])
    setNewLogText('')
  }

  const shownLogs = logList.filter((item) => logFilter === 'all' || item.scope === logFilter)

  return (
    <div className="subsystem-dual-logs-card">
      <div className="logs-head">
        <div className="logs-title-wrap">
          <IconLogs size={14} />
          <span className="card-title">EVENTS & NODE LOGS</span>
          <span className="sub-tag-code mono">[{subsystemCode}]</span>
          <span className="mono muted-hint">LIVE ROS EVENTS</span>
        </div>
        <div className="log-filter-tabs">
          <button type="button" className={`log-chip ${logFilter === 'all' ? 'active' : ''}`} onClick={() => setLogFilter('all')}>
            All ({logList.length})
          </button>
          <button type="button" className={`log-chip ${logFilter === 'global' ? 'active' : ''}`} onClick={() => setLogFilter('global')}>
            Global ({logList.filter((l) => l.scope === 'global').length})
          </button>
          <button type="button" className={`log-chip ${logFilter === 'local' ? 'active' : ''}`} onClick={() => setLogFilter('local')}>
            Local / {subsystemCode} ({logList.filter((l) => l.scope === 'local').length})
          </button>
        </div>
      </div>

      <div className="subsystem-nodes-ribbon mono">
        <div className="nodes-ribbon-col">
          <span className="ribbon-lbl sub">SUBSCRIBED:</span>
          <div className="ribbon-tags-wrap">
            {nodeDefs.subscribed.map((s, idx) => (
              <span key={idx} className={`node-pill sub ${topicClass(advertised, s.topic)}`}
                    title={`Node: /${s.node} | Type: ${s.type}${advertised ? (advertised.has(s.topic) ? ' | advertised now' : ' | NOT advertised') : ''}`}>
                <span className="node-name">/{s.node}</span>
                <span className="node-topic">{s.topic}</span>
              </span>
            ))}
          </div>
        </div>
        <div className="nodes-ribbon-col">
          <span className="ribbon-lbl pub">PUBLISHING:</span>
          <div className="ribbon-tags-wrap">
            {nodeDefs.publishing.map((p, idx) => (
              <span key={idx} className={`node-pill pub ${topicClass(advertised, p.topic)}`}
                    title={`Node: /${p.node} | Type: ${p.type}${advertised ? (advertised.has(p.topic) ? ' | advertised now' : ' | NOT advertised') : ''}`}>
                <span className="node-name">/{p.node}</span>
                <span className="node-topic">{p.topic}</span>
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="log-stream-box mono">
        {shownLogs.length === 0 && (
          <div className="empty-note">No events yet. Entries appear when real messages arrive (mode changes, mission alerts, link or kill-switch changes, warnings in /rosout).</div>
        )}
        {shownLogs.map((l) => (
          <div key={l.id} className={`log-entry-row ${l.scope}`}>
            <span className="log-time">{l.time}</span>
            <span className={`log-scope-pill ${l.scope}`}>{l.scope === 'global' ? 'GLOBAL' : `LOCAL [${subsystemCode}]`}</span>
            <span className={`log-level-pill ${l.level ? l.level.toLowerCase() : 'info'}`}>{l.level || 'INFO'}</span>
            <span className="log-tag">{l.tag}</span>
            <span className="log-text">{l.text}</span>
          </div>
        ))}
      </div>

      <form className="log-dispatch-form" onSubmit={handleSendLog}>
        <div className="scope-toggle-group">
          <button type="button" className={`scope-btn ${newLogScope === 'local' ? 'active local' : ''}`} onClick={() => setNewLogScope('local')}
                  title={`Note for ${subsystemName}`}>
            Local ({subsystemCode})
          </button>
          <button type="button" className={`scope-btn ${newLogScope === 'global' ? 'active global' : ''}`} onClick={() => setNewLogScope('global')}
                  title="Note shown under Global">
            Global
          </button>
        </div>
        <input type="text" className="log-input mono" placeholder="Operator note (kept on this page, not sent to the rover)"
               value={newLogText} onChange={(e) => setNewLogText(e.target.value)} />
        <button type="submit" className="log-submit-btn">Add note</button>
      </form>
    </div>
  )
}

// =============================================================================
// 1. GENERAL
// =============================================================================
function gnssLabelOf(gps) {
  if (!gps) return null
  const s = gps.status?.status
  return s === 2 ? 'RTK FIXED' : s === 1 ? 'SBAS/DGPS' : s === 0 ? '3D FIX' : 'NO FIX'
}

function GeneralView({
  odom, battery, gps, missionState, missionAlert, linkOk, linkAge, killSwitch,
  radoStatus, armStatus, markerObs, autonomyViolations, advertised, distance, redZone,
  onSelectSubsystem, hideInlineLogs = false,
}) {
  const [run, cmdNote] = useServiceRunner()

  const tw = odom?.twist?.twist
  const speed = tw ? Math.hypot(tw.linear.x, tw.linear.y) : null
  const yawRate = tw?.angular?.z ?? null
  const volts = num(battery?.voltage)
  const current = num(battery?.current)
  const charge = num(battery?.percentage) != null && battery.percentage >= 0 ? Math.round(battery.percentage * 100) : null
  const power = volts != null && current != null ? volts * Math.abs(current) : null
  const vTone = volts == null ? '' : volts < config.battery.critical ? 'fault' : volts < config.battery.warn ? 'warn' : 'ok'

  const modeIdx = missionState?.mode ?? null
  const modeName = modeIdx != null ? MODE_NAMES[modeIdx] ?? 'UNKNOWN' : null
  const missionName = missionState?.mission ? missionState.mission.toUpperCase() : null
  const stage = missionState?.stage || null
  const elapsedSec = missionState ? num(missionState.elapsed_s) : null
  const limitSec = missionState ? num(missionState.limit_s) : null
  const points = missionState ? num(missionState.points) : null
  const pointsMax = missionState ? num(missionState.points_max) : null
  const bonusUnlocked = missionState?.bonus_unlocked === true
  const alertText = missionState?.alert || missionAlert?.data || ''

  const linkKnown = linkOk != null
  const isLinkOk = linkOk?.data === true
  const linkAgeSec = num(linkAge?.data)
  const violations = autonomyViolations?.data ?? null
  const gnss = gnssLabelOf(gps)
  const camsUp = advertised ? config.cameras.filter((c) => advertised.has(c.topic)).length : null

  const motion = describeMotion(tw)

  return (
    <div className="general-overview-deck">
      {alertText && <div className="mission-alert-banner mono">ALERT: {alertText}</div>}

      <div className="minimal-metric-strip">
        <div className="metric-pill">
          <span className="metric-lbl">MISSION</span>
          <span className={`metric-val mono ${modeClassOf(modeIdx)}`}>
            {modeName ? `${missionName ? missionName + ' · ' : ''}${modeName}` : '—'}
          </span>
        </div>
        <div className="metric-pill">
          <span className="metric-lbl">TIMER</span>
          <span className={`metric-val mono ${elapsedSec != null && limitSec != null && elapsedSec > limitSec * 0.85 ? 'warn' : ''}`}>
            {elapsedSec != null ? `${fmtTime(elapsedSec)}${limitSec != null ? ` / ${fmtTime(limitSec)}` : ''}` : '—'}
          </span>
        </div>
        <div className="metric-pill">
          <span className="metric-lbl">POINTS</span>
          <span className={`metric-val mono ${bonusUnlocked ? 'ok' : ''}`}>
            {points != null ? `${points.toFixed(0)}${pointsMax != null ? ` / ${pointsMax.toFixed(0)}` : ''}${bonusUnlocked ? ' BONUS' : ''}` : '—'}
          </span>
        </div>
        <div className="metric-pill">
          <span className="metric-lbl">STAGE</span>
          <span className="metric-val mono">{stage ?? '—'}</span>
        </div>
        <div className="metric-pill">
          <span className="metric-lbl">SPEED</span>
          <span className="metric-val mono">{speed != null ? `${fmt(speed, 2)} m/s` : '—'}</span>
        </div>
        <div className="metric-pill">
          <span className="metric-lbl">BATTERY</span>
          <span className={`metric-val mono ${vTone}`}>
            {volts != null ? `${volts.toFixed(1)}V${charge != null ? ` · ${charge}%` : ''}` : '—'}
          </span>
        </div>
        {power != null && (
          <div className="metric-pill">
            <span className="metric-lbl">POWER DRAW</span>
            <span className="metric-val mono">{power.toFixed(0)} W</span>
          </div>
        )}
        <div className="metric-pill">
          <span className="metric-lbl">LINK</span>
          <span className={`metric-val mono ${linkKnown ? (isLinkOk ? 'ok' : 'fault') : ''}`}>
            {linkKnown ? (isLinkOk ? `OK${linkAgeSec != null ? ` ${linkAgeSec.toFixed(2)}s` : ''}` : 'DOWN') : '—'}
          </span>
        </div>
        <div className="metric-pill">
          <span className="metric-lbl">RED ZONE</span>
          <span className={`metric-val mono ${redZone ? (redZone.data ? 'fault' : 'ok') : ''}`}>
            {redZone ? (redZone.data ? 'VISIBLE' : 'CLEAR') : '—'}
          </span>
        </div>
        {violations > 0 && (
          <div className="metric-pill">
            <span className="metric-lbl">VIOLATIONS</span>
            <span className="metric-val mono fault">{violations} AUTO</span>
          </div>
        )}
        <div className="metric-pill">
          <span className="metric-lbl">GNSS</span>
          <span className={`metric-val mono ${gnss === 'RTK FIXED' ? 'ok' : gnss === 'NO FIX' ? 'fault' : ''}`}>
            {gps ? `${gnss} · ${gps.latitude.toFixed(5)}°, ${gps.longitude.toFixed(5)}°` : '—'}
          </span>
        </div>
      </div>

      <div className="mission-controls-strip">
        <div className="cmd-group">
          <span className="cmd-group-label mono">DRIVE MODE (/set_mode):</span>
          {config.MODE_NAMES.map((name, idx) => (
            <button
              key={name}
              type="button"
              className={`mode-btn mono ${modeIdx === idx ? 'active ' + (idx === 3 ? 'fault' : idx === 2 ? 'ok' : 'warn') : ''}`}
              onClick={() => run(config.services.setMode, { mode: idx })}
              title={`Switch mode to ${name}`}
            >
              {name}
            </button>
          ))}
        </div>

        <div className="cmd-group">
          <span className="cmd-group-label mono">MISSION (/mission/start):</span>
          {['rado', 'abex', 'idmo'].map((m) => (
            <button
              key={m}
              type="button"
              className={`mission-btn mono ${missionState?.mission === m && missionState?.running ? 'active' : ''}`}
              onClick={() => run(config.services.startMission, { mission: m })}
            >
              {m.toUpperCase()}
            </button>
          ))}
          <button type="button" className="mission-btn stop mono" onClick={() => run(config.services.stopMission, {})} title="Stop mission timer">
            STOP
          </button>
          <button type="button" className="mission-btn penalty mono" onClick={() => run(config.services.commsPenalty, {})} title="Toggle comms penalty">
            PENALTY
          </button>
        </div>
        {cmdNote && <p className="notice inline">{cmdNote}</p>}
      </div>

      <div className="general-cards-grid">
        {/* ML & Locomotion */}
        <div className="general-sub-card" onClick={() => onSelectSubsystem('ml')} title="Open ML & Locomotion">
          <div className="card-head">
            <div className="card-title-wrap">
              <IconRover size={15} />
              <span className="card-title">ML & LOCOMOTION</span>
            </div>
            <span className={`live-status-tag ${tw ? 'ok' : ''}`}>{tw ? motion : 'NO DATA'}</span>
          </div>
          <div className="card-body">
            <div className="card-stat-row"><span className="c-lbl">Speed</span><span className="c-val mono">{speed != null ? `${fmt(speed, 2)} m/s` : '—'}</span></div>
            <div className="card-stat-row"><span className="c-lbl">Yaw rate</span><span className="c-val mono">{yawRate != null ? `${fmt(yawRate, 2)} rad/s` : '—'}</span></div>
            <div className="card-stat-row"><span className="c-lbl">Driven since page load</span><span className="c-val mono">{distance != null ? `${distance.toFixed(1)} m` : '—'}</span></div>
          </div>
          <div className="card-footer mono">Open ML Locomotion →</div>
        </div>

        {/* Electrical */}
        <div className="general-sub-card" onClick={() => onSelectSubsystem('electrical')} title="Open Electrical & Power">
          <div className="card-head">
            <div className="card-title-wrap">
              <IconTelemetry size={15} />
              <span className="card-title">ELECTRICAL &amp; POWER</span>
            </div>
            <span className={`live-status-tag ${vTone}`}>
              {volts == null ? 'NO DATA' : vTone === 'fault' ? 'CRITICAL' : vTone === 'warn' ? 'LOW' : 'OK'}
            </span>
          </div>
          <div className="card-body">
            <div className="card-stat-row"><span className="c-lbl">Pack voltage</span><span className={`c-val mono ${vTone}`}>{volts != null ? `${volts.toFixed(2)} V` : '—'}</span></div>
            <div className="card-stat-row"><span className="c-lbl">Current</span><span className="c-val mono">{current != null ? `${current.toFixed(1)} A` : 'not published'}</span></div>
            <div className="card-stat-row">
              <span className="c-lbl">Motor bus</span>
              <span className={`c-val mono ${killSwitch ? (killSwitch.data ? 'fault' : 'ok') : ''}`}>
                {killSwitch ? (killSwitch.data ? 'CONTACTOR OPEN' : 'CONTACTOR CLOSED') : '—'}
              </span>
            </div>
          </div>
          <div className="card-footer mono">Open Electrical →</div>
        </div>

        {/* Cams & Comms */}
        <div className="general-sub-card" onClick={() => onSelectSubsystem('cams_comms')} title="Open Cams & Comms">
          <div className="card-head">
            <div className="card-title-wrap">
              <IconBroadcast size={15} />
              <span className="card-title">CAMS & COMMS</span>
            </div>
            <span className={`live-status-tag ${linkKnown ? (isLinkOk ? 'ok' : 'fault') : ''}`}>
              {linkKnown ? (isLinkOk ? 'LINK OK' : 'LINK DOWN') : 'NO DATA'}
            </span>
          </div>
          <div className="card-body">
            <div className="card-stat-row"><span className="c-lbl">Heartbeat age</span><span className="c-val mono">{linkAgeSec != null ? `${Math.round(linkAgeSec * 1000)} ms` : '—'}</span></div>
            <div className="card-stat-row"><span className="c-lbl">Camera topics advertised</span><span className="c-val mono">{camsUp != null ? `${camsUp} / ${config.cameras.length}` : '—'}</span></div>
          </div>
          <div className="card-footer mono">Open Cams & Comms →</div>
        </div>

        {/* Arm / RADO */}
        <div className="general-sub-card" onClick={() => onSelectSubsystem('arm_rado')} title="Open RADO">
          <div className="card-head">
            <div className="card-title-wrap">
              <IconArm size={15} />
              <span className="card-title">ARM FOR RADO</span>
            </div>
            <span className={`live-status-tag ${radoStatus ? 'ok' : ''}`}>{radoStatus?.data ?? 'NO DATA'}</span>
          </div>
          <div className="card-body">
            <div className="card-stat-row"><span className="c-lbl">RADO FSM</span><span className="c-val mono">{radoStatus?.data ?? '—'}</span></div>
            <div className="card-stat-row"><span className="c-lbl">Arm status</span><span className="c-val mono">{armStatus?.data ?? '—'}</span></div>
            <div className="card-stat-row">
              <span className="c-lbl">Marker</span>
              <span className="c-val mono">
                {markerObs ? (markerObs.visible ? `${(markerObs.colour || '').toUpperCase()} ${num(markerObs.range_m) != null ? markerObs.range_m.toFixed(2) + ' m' : 'visible'}` : 'NOT VISIBLE') : '—'}
              </span>
            </div>
          </div>
          <div className="card-footer mono">Open RADO →</div>
        </div>
      </div>

      {!hideInlineLogs && (
        <SubsystemDualLogs subsystemId="general" subsystemCode="GEN" subsystemName="General Overview" advertised={advertised} />
      )}
    </div>
  )
}

// =============================================================================
// 2. ML & LOCOMOTION
// =============================================================================
function MLView({ odom, imu, missionState, distance, advertised, onFocusCamera, onOpenPiP, hideInlineLogs = false }) {
  const [activeCam, setActiveCam] = useState('/camera/color/image_raw')

  const tw = odom?.twist?.twist
  const speed = tw ? Math.hypot(tw.linear.x, tw.linear.y) : null
  const yawRate = tw?.angular?.z ?? null
  const action = describeMotion(tw)
  const modeIdx = missionState?.mode ?? null
  const ax = num(imu?.linear_acceleration?.x)
  const ay = num(imu?.linear_acceleration?.y)
  const az = num(imu?.linear_acceleration?.z)
  const gz = num(imu?.angular_velocity?.z)

  const chips = [
    { topic: '/camera/color/image_raw', label: 'Front (D435i)', match: 'color' },
    { topic: '/camera_rear/image_raw', label: 'Rear', match: 'rear' },
    { topic: '/camera_left/image_raw', label: 'Left', match: 'left' },
    { topic: '/camera_right/image_raw', label: 'Right', match: 'right' },
  ]

  return (
    <div className="ml-ops-layout">
      <div className="ml-camera-column">
        <div className="column-header">
          <span className="col-title mono">LOCOMOTION CAMERA FEED</span>
          <div className="cam-selector-mini-chips">
            {chips.map((c) => (
              <button key={c.topic} type="button" className={`mini-chip ${activeCam.includes(c.match) ? 'active' : ''}`} onClick={() => setActiveCam(c.topic)} title={c.topic}>
                {c.label}
              </button>
            ))}
          </div>
        </div>

        <div className="compact-cam-container">
          <CameraView topic={activeCam} quality={60} width={680} showBoxes={true} showHud={true} onFocus={onFocusCamera} />
        </div>

        <div className="cam-quick-actions">
          <button type="button" className="mini-action-btn" onClick={() => onOpenPiP && onOpenPiP(activeCam)} title="Float camera into a draggable Picture-in-Picture window">
            <IconPiP size={12} /> Float in PiP
          </button>
        </div>
      </div>

      <div className="ml-ops-column">
        <div className="relative-ops-card">
          <div className="card-head">
            <div className="card-title-wrap">
              <IconRover size={14} />
              <span className="card-title">LOCOMOTION (from {config.topics.odom.name})</span>
            </div>
            <span className={`badge mono ${tw ? 'ok' : ''}`}>{action ?? 'NO DATA'}</span>
          </div>

          <div className="ops-metrics-grid">
            <div className="ops-stat-item highlight">
              <span className="ops-lbl">DISTANCE DRIVEN</span>
              <span className="ops-val mono">{distance != null ? `${distance.toFixed(1)} m` : '—'}</span>
              <span className="ops-sub">Integrated from odometry since page load</span>
            </div>
            <div className="ops-stat-item">
              <span className="ops-lbl">STEERING</span>
              <span className="ops-val mono">{yawRate != null ? `${fmt(yawRate, 2)} rad/s` : '—'}</span>
              <span className="ops-sub">{yawRate != null ? `${(yawRate * (180 / Math.PI)).toFixed(1)} °/s` : 'Yaw rate'}</span>
            </div>
            <div className="ops-stat-item">
              <span className="ops-lbl">LINEAR SPEED</span>
              <span className="ops-val mono">{speed != null ? `${fmt(speed, 2)} m/s` : '—'}</span>
              <span className="ops-sub">Teleop limit: {config.teleop.maxLinear.toFixed(2)} m/s</span>
            </div>
            <div className="ops-stat-item">
              <span className="ops-lbl">MODE</span>
              <span className={`ops-val mono ${modeClassOf(modeIdx)}`}>{modeIdx != null ? MODE_NAMES[modeIdx] : '—'}</span>
              <span className="ops-sub">From /mission/state</span>
            </div>
            <div className="ops-stat-item">
              <span className="ops-lbl">IMU ACCEL (x / y / z)</span>
              <span className="ops-val mono">{ax != null && ay != null && az != null ? `${ax.toFixed(2)} / ${ay.toFixed(2)} / ${az.toFixed(2)}` : '—'}</span>
              <span className="ops-sub">m/s² · /imu/data</span>
            </div>
            <div className="ops-stat-item">
              <span className="ops-lbl">IMU YAW RATE</span>
              <span className="ops-val mono">{gz != null ? `${gz.toFixed(3)} rad/s` : '—'}</span>
              <span className="ops-sub">/imu/data</span>
            </div>
          </div>
        </div>

        {!hideInlineLogs && (
          <SubsystemDualLogs subsystemId="ml" subsystemCode="ML" subsystemName="ML & Locomotion" advertised={advertised} />
        )}
      </div>
    </div>
  )
}

// =============================================================================
// 3. ELECTRICAL
// base_bridge publishes pack voltage only (see trixanth_hardware README). Anything
// else (current, charge, per-component power, cells) is shown only if a BatteryState
// message actually carries it.
// =============================================================================
function ElectricalView({ battery, killSwitch, advertised, hideInlineLogs = false }) {
  const volts = num(battery?.voltage)
  const current = num(battery?.current)
  const pct = num(battery?.percentage) != null && battery.percentage >= 0 ? battery.percentage * 100 : null
  const temp = num(battery?.temperature)
  const capacity = num(battery?.design_capacity) || num(battery?.capacity)
  const charge = num(battery?.charge)
  const power = volts != null && current != null ? volts * Math.abs(current) : null
  const runtimeMin = charge != null && current != null && Math.abs(current) > 0.05 ? (charge / Math.abs(current)) * 60 : null
  const cRate = capacity && current != null ? Math.abs(current) / capacity : null
  const cells = Array.isArray(battery?.cell_voltage) ? battery.cell_voltage.filter((v) => num(v) != null && v > 0) : []
  const cellDelta = cells.length > 1 ? (Math.max(...cells) - Math.min(...cells)) * 1000 : null
  const vTone = volts == null ? '' : volts < config.battery.critical ? 'fault' : volts < config.battery.warn ? 'warn' : 'ok'

  return (
    <div className="electrical-deck">
      <div className="bms-summary-grid">
        <div className="bms-stat-card">
          <span className="bms-lbl">PACK VOLTAGE</span>
          <span className={`bms-val mono ${vTone}`}>{volts != null ? `${volts.toFixed(2)} V` : '—'}</span>
          <span className="bms-sub">Warn &lt; {config.battery.warn} V · Critical &lt; {config.battery.critical} V</span>
        </div>
        <div className="bms-stat-card">
          <span className="bms-lbl">STATE OF CHARGE</span>
          <span className="bms-val mono">{pct != null ? `${Math.round(pct)}%` : '—'}</span>
          {pct != null ? (
            <div className="bms-progress-track"><div className="bms-progress-fill ok" style={{ width: `${Math.min(100, pct)}%` }} /></div>
          ) : (
            <span className="bms-sub">Not published</span>
          )}
        </div>
        <div className="bms-stat-card">
          <span className="bms-lbl">CURRENT</span>
          <span className="bms-val mono">{current != null ? `${current.toFixed(1)} A` : '—'}</span>
          <span className="bms-sub">{cRate != null ? `${cRate.toFixed(2)} C` : current != null ? '' : 'Not published'}</span>
        </div>
        <div className="bms-stat-card">
          <span className="bms-lbl">POWER DRAW</span>
          <span className="bms-val mono">{power != null ? `${power.toFixed(0)} W` : '—'}</span>
          <span className="bms-sub">{power != null ? 'Voltage × current' : 'Needs current'}</span>
        </div>
        <div className="bms-stat-card">
          <span className="bms-lbl">EST. RUNTIME</span>
          <span className="bms-val mono">{runtimeMin != null ? `${Math.round(runtimeMin)} min` : '—'}</span>
          <span className="bms-sub">{runtimeMin != null ? 'Charge ÷ current' : 'Needs charge and current'}</span>
        </div>
        <div className="bms-stat-card">
          <span className="bms-lbl">MOTOR BUS</span>
          <span className={`bms-val mono ${killSwitch ? (killSwitch.data ? 'fault' : 'ok') : ''}`}>
            {killSwitch ? (killSwitch.data ? 'OPEN' : 'CLOSED') : '—'}
          </span>
          <span className="bms-sub">/trixanth/kill_switch{temp != null ? ` · pack ${temp.toFixed(0)} °C` : ''}</span>
        </div>
      </div>

      {volts != null && current == null && pct == null && (
        <p className="empty-note">base_bridge publishes pack voltage only. Current, charge, per-component power and cell voltages are shown here only if a BatteryState message carries them.</p>
      )}

      {cells.length > 0 && (
        <div className="cells-balance-card">
          <div className="card-head">
            <span className="card-title mono">CELL VOLTAGES</span>
            {cellDelta != null && <span className="badge mono">DELTA: {cellDelta.toFixed(0)} mV</span>}
          </div>
          <div className="cells-grid mono">
            {cells.map((v, i) => (
              <div key={i} className="cell-card">
                <span className="cell-lbl">CELL {i + 1}</span>
                <span className="cell-v">{v.toFixed(3)} V</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {!hideInlineLogs && (
        <SubsystemDualLogs subsystemId="electrical" subsystemCode="ELEC" subsystemName="Electrical & Power" advertised={advertised} />
      )}
    </div>
  )
}

// =============================================================================
// 4. CAMS & COMMS
// =============================================================================
function CamsCommsView({ linkOk, linkAge, advertised, onFocusCamera, onOpenPiP, hideInlineLogs = false }) {
  const rosStatus = useRosStatus()
  const linkKnown = linkOk != null
  const isLinkOk = linkOk?.data === true
  const linkAgeSec = num(linkAge?.data)

  const [layoutMode, setLayoutMode] = useState('hero_quad')
  const [heroCamTopic, setHeroCamTopic] = useState('/camera/color/image_raw')

  const CAMERAS_5 = config.cameras
  const heroCamMeta = CAMERAS_5.find((c) => c.topic === heroCamTopic) || CAMERAS_5[0]
  const companionCams = CAMERAS_5.filter((c) => c.topic !== heroCamTopic)
  const swapToHero = (topic) => setHeroCamTopic(topic)

  return (
    <div className="cams-comms-deck">
      {/* LINK HEALTH: all values measured */}
      <div className="sector-antenna-card">
        <div className="card-head">
          <div className="card-title-wrap">
            <IconBroadcast size={15} />
            <span className="card-title">LINK HEALTH</span>
          </div>
          <div className="antenna-working-badge-wrap">
            <span className={`antenna-working-pill ${linkKnown ? (isLinkOk ? 'working' : 'fault') : ''}`}>
              <Dot state={linkKnown ? (isLinkOk ? 'running' : 'crashed') : ''} />
              <span className="mono">GROUND HEARTBEAT: {linkKnown ? (isLinkOk ? 'OK' : 'LOST') : 'NO DATA'}</span>
            </span>
          </div>
        </div>

        <div className="sector-metrics-grid">
          <div className="sec-stat-box">
            <span className="sec-lbl">HEARTBEAT AGE</span>
            <span className={`sec-val mono ${linkKnown ? (isLinkOk ? 'ok' : 'fault') : ''}`}>{linkAgeSec != null ? `${Math.round(linkAgeSec * 1000)} ms` : '—'}</span>
            <span className="sec-sub">/trixanth/link_age from link_monitor</span>
          </div>
          <div className="sec-stat-box">
            <span className="sec-lbl">ROSBRIDGE</span>
            <span className={`sec-val mono ${rosStatus === 'connected' ? 'ok' : 'fault'}`}>{rosStatus.toUpperCase()}</span>
            <span className="sec-sub">{config.rosbridgeUrl}</span>
          </div>
          <div className="sec-stat-box">
            <span className="sec-lbl">CAMERA TOPICS</span>
            <span className="sec-val mono">
              {advertised ? `${CAMERAS_5.filter((c) => advertised.has(c.topic)).length} / ${CAMERAS_5.length}` : '—'}
            </span>
            <span className="sec-sub">advertised on the ROS graph</span>
          </div>
        </div>

        {advertised && (
          <div className="antenna-controls-strip">
            {CAMERAS_5.map((c) => (
              <span key={c.id} className="mono ctrl-lbl" title={c.topic}>
                <Dot state={advertised.has(c.topic) ? 'running' : 'crashed'} /> {c.shortLabel || c.label}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* 5-CAMERA COMMAND LAYOUT */}
      <div className="cams-command-section">
        <div className="section-head">
          <div className="section-title-wrap">
            <IconMaximize size={14} />
            <span className="section-heading mono">5 ROVER CAMERA STREAMS (REALSENSE D435i + 4 WEBCAMS)</span>
          </div>

          {/* Layout switcher buttons */}
          <div className="cams-layout-switch-bar">
            <button
              type="button"
              className={`layout-switch-btn ${layoutMode === 'hero_quad' ? 'active' : ''}`}
              onClick={() => setLayoutMode('hero_quad')}
              title="Prominent Hero Stream + 4 Companion Feeds Quad"
            >
              Hero + Quad Companion
            </button>
            <button
              type="button"
              className={`layout-switch-btn ${layoutMode === 'matrix' ? 'active' : ''}`}
              onClick={() => setLayoutMode('matrix')}
              title="Equal Size 5-Camera Grid"
            >
              5-Camera Equal Matrix
            </button>
            <button
              type="button"
              className={`layout-switch-btn ${layoutMode === 'dual_drive' ? 'active' : ''}`}
              onClick={() => setLayoutMode('dual_drive')}
              title="Dual Drive (Front D435i + Rear Webcam side-by-side)"
            >
              Dual Drive Split
            </button>
          </div>
        </div>

        {/* LAYOUT 1: HERO + QUAD COMPANION FEEDS */}
        {layoutMode === 'hero_quad' && (
          <div className="cams-hero-quad-split">
            {/* HERO STREAM COLUMN */}
            <div className="cams-hero-column">
              <div className="hero-stream-header">
                <div className="hero-title-meta">
                  <span className="hero-badge-live">HERO STAGE FEED</span>
                  <span className="hero-label mono">{heroCamMeta.label}</span>
                </div>
                {/* Camera quick-switch chips */}
                <div className="cam-selector-mini-chips">
                  {CAMERAS_5.map((cam) => (
                    <button
                      key={cam.id}
                      type="button"
                      className={`mini-chip ${heroCamTopic === cam.topic ? 'active' : ''}`}
                      onClick={() => setHeroCamTopic(cam.topic)}
                      title={`Switch Hero to ${cam.label}`}
                    >
                      {cam.shortLabel || cam.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="hero-viewport-card">
                <CameraView
                  topic={heroCamTopic}
                  quality={60}
                  width={680}
                  showBoxes={heroCamTopic.includes('color') || heroCamTopic.includes('front')}
                  showHud={true}
                  onFocus={onFocusCamera}
                />
              </div>

              <div className="hero-actions-bar">
                <button
                  type="button"
                  className="mini-action-btn"
                  onClick={() => onOpenPiP && onOpenPiP(heroCamTopic)}
                  title="Float current Hero camera in draggable Picture-in-Picture window"
                >
                  <IconPiP size={12} /> Float in PiP
                </button>
                <button
                  type="button"
                  className="mini-action-btn"
                  onClick={() => onFocusCamera && onFocusCamera(heroCamTopic)}
                  title="Focus in Stage View"
                >
                  Focus Full Stage
                </button>
              </div>
            </div>

            {/* QUAD COMPANION FEEDS COLUMN */}
            <div className="cams-quad-column">
              <div className="quad-column-head mono">COMPANION FEEDS (1-CLICK SWAP TO HERO)</div>
              <div className="companion-quad-grid">
                {companionCams.map((cam) => (
                  <div key={cam.id} className="companion-cam-card">
                    <div className="companion-head">
                      <span className="companion-title mono">{cam.label}</span>
                    </div>

                    <div className="companion-viewport">
                      <CameraView
                        topic={cam.topic}
                        quality={45}
                        width={340}
                        showBoxes={false}
                        showHud={false}
                      />
                    </div>

                    <div className="companion-card-actions">
                      <button
                        type="button"
                        className="companion-btn swap"
                        onClick={() => swapToHero(cam.topic)}
                        title={`Promote ${cam.label} to large Hero spot`}
                      >
                        <IconSwap size={11} /> Swap to Main
                      </button>
                      <button
                        type="button"
                        className="companion-btn pip"
                        onClick={() => onOpenPiP && onOpenPiP(cam.topic)}
                        title={`Open ${cam.label} in PiP`}
                      >
                        <IconPiP size={11} /> PiP
                      </button>
                      <button
                        type="button"
                        className="companion-btn focus"
                        onClick={() => onFocusCamera && onFocusCamera(cam.topic)}
                        title="Focus in Stage"
                      >
                        Focus
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* LAYOUT 2: EQUAL 5-CAMERA MATRIX */}
        {layoutMode === 'matrix' && (
          <div className="cameras-5-matrix">
            {CAMERAS_5.map((cam) => (
              <div key={cam.id} className="camera-grid-card">
                <div className="cam-card-top">
                  <span className="cam-badge-name mono">{cam.label}</span>
                </div>

                <div className="cam-viewport-box">
                  <CameraView
                    topic={cam.topic}
                    quality={45}
                    width={340}
                    showBoxes={cam.id === 'front'}
                    showHud={false}
                  />
                </div>

                <div className="cam-card-actions">
                  <button
                    type="button"
                    className="cam-act-btn"
                    onClick={() => {
                      setHeroCamTopic(cam.topic)
                      setLayoutMode('hero_quad')
                    }}
                    title="Promote to Hero Stage"
                  >
                    <IconSwap size={11} /> Hero
                  </button>
                  <button
                    type="button"
                    className="cam-act-btn"
                    onClick={() => onFocusCamera && onFocusCamera(cam.topic)}
                    title="Expand to Full Stage Focus"
                  >
                    Focus
                  </button>
                  <button
                    type="button"
                    className="cam-act-btn pip"
                    onClick={() => onOpenPiP && onOpenPiP(cam.topic)}
                    title="Open this camera in draggable Picture-in-Picture window"
                  >
                    <IconPiP size={12} /> PiP
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* LAYOUT 3: DUAL DRIVE SPLIT (FRONT & REAR TOP, 3 CAMS BOTTOM) */}
        {layoutMode === 'dual_drive' && (
          <div className="cams-dual-drive-deck">
            <div className="dual-drive-top-row">
              <div className="drive-cam-cell">
                <div className="drive-cam-header mono">FRONT INTEL REALSENSE D435i (FORWARD TRAVERSE)</div>
                <div className="drive-viewport">
                  <CameraView
                    topic="/camera/color/image_raw"
                    quality={55}
                    width={520}
                    showBoxes={true}
                    showHud={true}
                    onFocus={onFocusCamera}
                  />
                </div>
              </div>
              <div className="drive-cam-cell">
                <div className="drive-cam-header mono">REAR BACK WEBCAM (REVERSE & HITCH COUPLING)</div>
                <div className="drive-viewport">
                  <CameraView
                    topic="/camera_rear/image_raw"
                    quality={55}
                    width={520}
                    showBoxes={false}
                    showHud={true}
                    onFocus={onFocusCamera}
                  />
                </div>
              </div>
            </div>

            <div className="dual-drive-bottom-row">
              {['/camera_arm/image_raw', '/camera_left/image_raw', '/camera_right/image_raw'].map((top) => {
                const c = CAMERAS_5.find((m) => m.topic === top) || { label: top }
                return (
                  <div key={top} className="sub-cam-cell">
                    <div className="sub-cam-header mono">{c.label}</div>
                    <div className="sub-viewport">
                      <CameraView topic={top} quality={45} width={320} showBoxes={false} showHud={false} />
                    </div>
                    <div className="sub-cam-actions">
                      <button type="button" className="mini-action-btn" onClick={() => onOpenPiP && onOpenPiP(top)}>
                        <IconPiP size={11} /> PiP
                      </button>
                      <button type="button" className="mini-action-btn" onClick={() => onFocusCamera && onFocusCamera(top)}>
                        Focus
                      </button>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}
      </div>

      {!hideInlineLogs && (
        <SubsystemDualLogs subsystemId="cams_comms" subsystemCode="COMS" subsystemName="Cams & Comms" advertised={advertised} />
      )}
    </div>
  )
}

// =============================================================================
// 5. ARM FOR RADO
// Real sources only: MissionState, MarkerObservation, ReconEntry, /rado/status,
// /arm/status. No arm joint or gripper feedback is published in this workspace,
// so none is shown.
// =============================================================================
function ArmRadoView({ missionState, markerObs, radoStatus, armStatus, autonomyViolations, advertised, onFocusCamera, onOpenPiP, hideInlineLogs = false }) {
  const [run, cmdNote] = useServiceRunner()
  const reconLog = useOpsEvents('arm_rado').filter((e) => e.tag === 'RADO/RECON').slice(0, 10)

  const modeIdx = missionState?.mode ?? null
  const modeName = modeIdx != null ? MODE_NAMES[modeIdx] ?? 'UNKNOWN' : null
  const elapsedSec = missionState ? num(missionState.elapsed_s) : null
  const limitSec = missionState ? num(missionState.limit_s) : null
  const points = missionState ? num(missionState.points) : null
  const bonusUnlocked = missionState?.bonus_unlocked === true
  const stage = missionState?.stage || null

  const markerRange = num(markerObs?.range_m)
  const markerBearing = num(markerObs?.bearing_rad)
  const violations = autonomyViolations?.data ?? null

  return (
    <div className="arm-rado-deck">
      <div className="rado-mission-banner mono">
        <span className={`rado-mode-tag ${modeClassOf(modeIdx)}`}>MODE: {modeName ?? '—'}</span>
        <span className="rado-timer-tag">TIMER: {elapsedSec != null ? `${fmtTime(elapsedSec)}${limitSec != null ? ` / ${fmtTime(limitSec)}` : ''}` : '—'}</span>
        <span className="rado-pts-tag">POINTS: {points != null ? `${points.toFixed(0)}${bonusUnlocked ? ' + BONUS' : ''}` : '—'}</span>
        <span className="rado-fsm-tag">{radoStatus?.data ?? '—'}</span>
        {violations > 0 && <span className="rado-viol-tag fault">VIOLATIONS: {violations}</span>}
      </div>

      <div className="arm-top-grid">
        <div className="arm-cam-card">
          <div className="card-head">
            <span className="card-title mono">MANIPULATOR ARM CAMERA FEED</span>
            <button type="button" className="mini-chip" onClick={() => onOpenPiP && onOpenPiP('/camera_arm/image_raw')} title="Open Arm Camera in Draggable PiP">
              <IconPiP size={12} /> Float in PiP
            </button>
          </div>
          <div className="compact-cam-container">
            <CameraView topic="/camera_arm/image_raw" quality={60} width={680} showBoxes={false} showHud={true} onFocus={onFocusCamera} />
          </div>
        </div>

        <div className="rado-mission-card">
          <div className="card-head">
            <div className="card-title-wrap">
              <IconArm size={14} />
              <span className="card-title">RADO MISSION TELEMETRY</span>
            </div>
          </div>

          <div className="rado-stats-list">
            <div className="rado-stat-row"><span className="r-lbl">FSM State (/rado/status)</span><span className="r-val mono">{radoStatus?.data ?? '—'}</span></div>
            <div className="rado-stat-row"><span className="r-lbl">Arm status (/arm/status)</span><span className="r-val mono">{armStatus?.data ?? '—'}</span></div>
            <div className="rado-stat-row"><span className="r-lbl">Mission stage</span><span className="r-val mono">{stage ?? '—'}</span></div>
            <div className="rado-stat-row">
              <span className="r-lbl">Marker detector</span>
              <span className={`r-val mono ${markerObs ? (markerObs.visible ? 'ok' : 'fault') : ''}`}>
                {markerObs
                  ? `${(markerObs.colour || '—').toUpperCase()} · ${markerObs.visible
                      ? `VISIBLE${markerRange != null ? ` ${markerRange.toFixed(2)}m` : ''}${markerBearing != null ? ` at ${(markerBearing * 180 / Math.PI).toFixed(1)}°` : ''}`
                      : 'NOT VISIBLE'}`
                  : '—'}
              </span>
            </div>

            <div className="rado-action-btns-row">
              <button type="button" className="rado-act-btn start mono" onClick={() => run(config.services.radoStartDelivery, {})} title="/rado/start_delivery">START DELIVERY</button>
              <button type="button" className="rado-act-btn abort mono" onClick={() => run(config.services.radoAbort, {})} title="/rado/abort">ABORT</button>
              <button type="button" className="rado-act-btn capture mono" onClick={() => run(config.services.reconCapture, {})} title="/recon/capture">CAPTURE RECON</button>
            </div>
            {cmdNote && <p className="notice inline">{cmdNote}</p>}
          </div>

          <div className="recon-log-section">
            <div className="recon-log-header mono">RECON LOG (/recon/entry)</div>
            {reconLog.length === 0 ? (
              <p className="empty-note">No recon entries received yet.</p>
            ) : (
              <div className="recon-log-list mono">
                {reconLog.map((e) => (
                  <div key={e.id} className="recon-log-row"><span className="recon-time">{e.time}</span> <span className="recon-label">{e.text}</span></div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <p className="empty-note">Arm joint angles and gripper state are not published by any node in this workspace, so they are not shown.</p>

      {!hideInlineLogs && (
        <SubsystemDualLogs subsystemId="arm_rado" subsystemCode="RADO" subsystemName="Arm for RADO" advertised={advertised} />
      )}
    </div>
  )
}

// =============================================================================
// 6. ABEx SCIENCE  (trixanth_hardware sensor_bridge -> trixanth_science)
// =============================================================================
function AbexView({ advertised, hideInlineLogs = false }) {
  const soilT = useTopic(config.topics.abexSoilTemp, { throttle: 500 })
  const airT = useTopic(config.topics.abexAirTemp, { throttle: 500 })
  const hum = useTopic(config.topics.abexHumidity, { throttle: 500 })
  const press = useTopic(config.topics.abexPressure, { throttle: 500 })
  const ph = useTopic(config.topics.abexPh, { throttle: 500 })
  const moist = useTopic(config.topics.abexSoilMoisture, { throttle: 500 })
  const gps = useTopic(config.topics.gps, { throttle: 1000 })
  const [result, setResult] = useState(null)
  const [busy, setBusy] = useState(null)

  const call = async (spec, label) => {
    setBusy(label)
    try {
      const r = await callService(spec, {})
      setResult({ ok: r?.success !== false, text: `${label}: ${r?.message || (r?.success === false ? 'refused' : 'done')}` })
    } catch {
      setResult({ ok: false, text: `${label}: ${spec.name} did not respond. Is the abex or science launch running?` })
    } finally {
      setBusy(null)
    }
  }

  const rh = num(hum?.relative_humidity)
  const pa = num(press?.fluid_pressure)
  const sensors = [
    { label: 'SOIL TEMPERATURE', v: num(soilT?.temperature), text: (v) => `${v.toFixed(1)} °C`, topic: config.topics.abexSoilTemp.name },
    { label: 'SOIL MOISTURE', v: num(moist?.data), text: (v) => `${v.toFixed(1)} %`, topic: config.topics.abexSoilMoisture.name },
    { label: 'SOIL pH', v: num(ph?.data), text: (v) => v.toFixed(2), topic: config.topics.abexPh.name },
    { label: 'AIR TEMPERATURE', v: num(airT?.temperature), text: (v) => `${v.toFixed(1)} °C`, topic: config.topics.abexAirTemp.name },
    { label: 'HUMIDITY', v: rh != null ? rh * 100 : null, text: (v) => `${v.toFixed(1)} %`, topic: config.topics.abexHumidity.name },
    { label: 'PRESSURE', v: pa, text: (v) => `${(v / 100).toFixed(1)} hPa`, topic: config.topics.abexPressure.name },
  ]
  const actions = [
    { label: 'NEW SITE', spec: config.services.abexNewSite, hint: 'Start the next site and store the current GPS' },
    { label: 'RECORD', spec: config.services.abexRecord, hint: 'Snapshot the latest sensor values to the site log' },
    { label: 'CLOSE-UP', spec: config.services.abexCloseup, hint: 'Save a close-up photo with the scale note' },
    { label: 'PANO START', spec: config.services.abexPanoStart, hint: 'Begin capturing frames, then rotate the rover slowly' },
    { label: 'PANO STOP', spec: config.services.abexPanoStop, hint: 'Stitch and save the panorama' },
  ]

  return (
    <div className="electrical-deck">
      <div className="bms-summary-grid">
        {sensors.map((s) => (
          <div key={s.label} className="bms-stat-card">
            <span className="bms-lbl">{s.label}</span>
            <span className="bms-val mono">{s.v != null ? s.text(s.v) : '—'}</span>
            <span className="bms-sub">{s.v != null ? s.topic : `${s.topic} not published`}</span>
          </div>
        ))}
        <div className="bms-stat-card">
          <span className="bms-lbl">SITE POSITION</span>
          <span className="bms-val mono">
            {gps ? `${gps.latitude.toFixed(5)}°, ${gps.longitude.toFixed(5)}°` : '—'}
          </span>
          <span className="bms-sub">/gps/fix</span>
        </div>
      </div>

      <div className="cells-balance-card">
        <div className="card-head"><span className="card-title mono">SITE LOGGING (trixanth_science)</span></div>
        <div className="cmd-group" style={{ flexWrap: 'wrap', gap: 8 }}>
          {actions.map((a) => (
            <button key={a.label} type="button" className="mission-btn mono" title={a.hint}
                    disabled={busy != null} onClick={() => call(a.spec, a.label)}>
              {busy === a.label ? '…' : a.label}
            </button>
          ))}
        </div>
        {result && <p className={`empty-note ${result.ok ? '' : 'fault'}`}>{result.text}</p>}
        <p className="empty-note">Order: NEW SITE, then RECORD and CLOSE-UP. For a panorama, PANO START, rotate slowly, PANO STOP.</p>
      </div>

      {!hideInlineLogs && (
        <SubsystemDualLogs subsystemId="abex" subsystemCode="ABEX" subsystemName="ABEx Science" advertised={advertised} />
      )}
    </div>
  )
}
