import { useState, useEffect, useRef } from 'react'
import { config } from '../config'
import { useTopicBuffer, useAdvertisedTopics } from '../ros'
import { useOpsEvents } from '../events'
import { SUBSYSTEM_ROS_NODES } from '../opsNodes'
import { fetchLaunches, tailLog } from '../api'
import { Chip, Dot, Empty } from '../components/ui'
import {
  IconLogs,
  IconTerminal,
  IconMinimize,
  IconMaximize,
  IconSwap,
  IconRover,
  IconBroadcast,
  getSubsystemIcon,
} from '../components/Icons'

const SUBSYSTEM_LIST = [
  { id: 'general', name: 'General Overview', code: 'GEN' },
  { id: 'ml', name: 'ML & Locomotion', code: 'ML' },
  { id: 'electrical', name: 'Electrical & Power', code: 'ELEC' },
  { id: 'cams_comms', name: 'Cams & Comms', code: 'COMS' },
  { id: 'arm_rado', name: 'Arm for RADO', code: 'RADO' },
  { id: 'abex', name: 'ABEx Science', code: 'ABEX' },
]

const ROS_LEVELS = [
  { key: 10, label: 'Debug' },
  { key: 20, label: 'Info' },
  { key: 30, label: 'Warn' },
  { key: 40, label: 'Error' },
]

export default function RightSideLogsDock({
  activeSubsystem = 'general',
  onSelectSubsystem = null,
}) {
  // Dock width state (resizable by dragging left edge)
  const [dockWidth, setDockWidth] = useState(() => {
    try {
      const saved = localStorage.getItem('trixanth_dock_width')
      if (saved) return Math.min(Math.max(300, parseInt(saved, 10)), 650)
    } catch {}
    return 400
  })
  const [isResizing, setIsResizing] = useState(false)
  const [isCollapsed, setIsCollapsed] = useState(false)

  // Subsystem selection in dock
  const [currentSub, setCurrentSub] = useState(activeSubsystem || 'general')
  useEffect(() => {
    if (activeSubsystem) setCurrentSub(activeSubsystem)
  }, [activeSubsystem])

  // Tabs: 'ops' (Subsystem Ops Logs) | 'console' (ROS 2 /rosout) | 'process' (Process tails) | 'split' (Ops + Console)
  const [tab, setTab] = useState('ops')

  // --- TAB 1: EVENTS (real ROS messages) + operator notes kept on this page ---
  const nodeDefs = SUBSYSTEM_ROS_NODES[currentSub] || SUBSYSTEM_ROS_NODES.general
  const advertised = useAdvertisedTopics()
  const [opsFilter, setOpsFilter] = useState('all') // 'all' | 'global' | 'local'
  const [newLogText, setNewLogText] = useState('')
  const [newLogScope, setNewLogScope] = useState('local')
  const [notes, setNotes] = useState([])
  const events = useOpsEvents(currentSub)
  const opsLogs = [...notes, ...events].sort((a, b) => b.ts - a.ts).slice(0, 200)

  const handleSendOpsLog = (e) => {
    e.preventDefault()
    if (!newLogText.trim()) return
    const ts = Date.now()
    setNotes((prev) => [
      {
        id: `note-${ts}`, ts, scope: newLogScope, text: newLogText.trim(),
        time: new Date().toLocaleTimeString('en-GB'),
        tag: newLogScope === 'global' ? 'OPERATOR NOTE' : `OPERATOR NOTE/${currentSub.toUpperCase()}`,
        level: 'INFO',
      },
      ...prev,
    ])
    setNewLogText('')
  }

  // --- TAB 2: ROS CONSOLE (/rosout) STATE ---
  const [minConsoleLevel, setMinConsoleLevel] = useState(20)
  const [consolePaused, setConsolePaused] = useState(false)
  const [consoleSearch, setConsoleSearch] = useState('')
  const rosoutMessages = useTopicBuffer(config.topics.rosout, 200)

  const shownConsoleMessages = rosoutMessages.filter((m) => {
    if (m.level < minConsoleLevel) return false
    if (!consoleSearch) return true
    const q = consoleSearch.toLowerCase()
    return (
      (m.msg && m.msg.toLowerCase().includes(q)) ||
      (m.name && m.name.toLowerCase().includes(q))
    )
  })

  // --- TAB 3: PROCESS LOGS STATE ---
  const [launches, setLaunches] = useState([])
  const [selectedProcessNode, setSelectedProcessNode] = useState('rado')
  const [processLogs, setProcessLogs] = useState([])
  const [processFilter, setProcessFilter] = useState('')
  const [processPaused, setProcessPaused] = useState(false)

  useEffect(() => {
    fetchLaunches()
      .then((res) => {
        if (Array.isArray(res)) setLaunches(res)
      })
      .catch(() => {})
  }, [])

  // Left resizer handler: drag left edge of right-dock to resize
  const handleResizerMouseDown = (e) => {
    e.preventDefault()
    setIsResizing(true)
    document.body.style.cursor = 'col-resize'
    document.body.style.userSelect = 'none'

    const startX = e.clientX
    const startW = dockWidth

    const onMouseMove = (moveEvent) => {
      const delta = startX - moveEvent.clientX
      const newWidth = Math.min(Math.max(300, startW + delta), 650)
      setDockWidth(newWidth)
      try {
        localStorage.setItem('trixanth_dock_width', newWidth.toString())
      } catch {}
    }

    const onMouseUp = () => {
      setIsResizing(false)
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
      window.removeEventListener('mousemove', onMouseMove)
      window.removeEventListener('mouseup', onMouseUp)
    }

    window.addEventListener('mousemove', onMouseMove)
    window.addEventListener('mouseup', onMouseUp)
  }

  // Render Subsystem Operations Log View
  const renderOpsLogsContent = () => {
    const shown = opsLogs.filter((l) => {
      if (opsFilter === 'all') return true
      return l.scope === opsFilter
    })

    return (
      <div className="dock-tab-content dock-ops-logs">
        {/* CONTRACTED NODES PILL BAR */}
        <div className="dock-nodes-row">
          <span className="dock-nodes-title mono">NODES:</span>
          {nodeDefs.subscribed.map((n, i) => (
            <span key={i} className={`dock-node-pill sub mono ${advertised == null ? '' : advertised.has(n.topic) ? 'topic-live' : 'topic-absent'}`} title={`Subscribed: ${n.topic} (${n.type})`}>
              <span className="node-dir">↓</span> {n.node}
            </span>
          ))}
          {nodeDefs.publishing.map((n, i) => (
            <span key={i} className={`dock-node-pill pub mono ${advertised == null ? '' : advertised.has(n.topic) ? 'topic-live' : 'topic-absent'}`} title={`Publishes: ${n.topic} (${n.type})`}>
              <span className="node-dir">↑</span> {n.node}
            </span>
          ))}
        </div>

        {/* LOG FILTER SWITCHER */}
        <div className="dock-logs-toolbar">
          <div className="filter-pill-group">
            <button
              type="button"
              className={`filter-btn ${opsFilter === 'all' ? 'active' : ''}`}
              onClick={() => setOpsFilter('all')}
            >
              All ({opsLogs.length})
            </button>
            <button
              type="button"
              className={`filter-btn ${opsFilter === 'global' ? 'active' : ''}`}
              onClick={() => setOpsFilter('global')}
            >
              Global ({opsLogs.filter((l) => l.scope === 'global').length})
            </button>
            <button
              type="button"
              className={`filter-btn ${opsFilter === 'local' ? 'active' : ''}`}
              onClick={() => setOpsFilter('local')}
            >
              Local / {currentSub.toUpperCase()} ({opsLogs.filter((l) => l.scope === 'local').length})
            </button>
          </div>
        </div>

        {/* LOG STREAM LIST */}
        <div className="dock-log-list mono">
          {shown.length === 0 && <div className="empty-note">No events yet. Entries appear when real messages arrive.</div>}
          {shown.map((item) => (
            <div key={item.id} className={`dock-log-line ${item.scope} ${item.level.toLowerCase()}`}>
              <span className="dock-log-time">{item.time}</span>
              <span className={`dock-log-tag ${item.scope}`}>{item.tag}</span>
              <span className="dock-log-text">{item.text}</span>
            </div>
          ))}
        </div>

        {/* DIRECT LOG ENTRY INPUT */}
        <form className="dock-log-input-form" onSubmit={handleSendOpsLog}>
          <div className="dock-scope-select">
            <button
              type="button"
              className={`scope-btn ${newLogScope === 'local' ? 'active local' : ''}`}
              onClick={() => setNewLogScope('local')}
            >
              Local ({currentSub.toUpperCase()})
            </button>
            <button
              type="button"
              className={`scope-btn ${newLogScope === 'global' ? 'active global' : ''}`}
              onClick={() => setNewLogScope('global')}
            >
              Global
            </button>
          </div>
          <div className="dock-input-row">
            <input
              type="text"
              className="dock-text-input mono"
              value={newLogText}
              onChange={(e) => setNewLogText(e.target.value)}
              placeholder="Operator note (kept on this page, not sent to the rover)"
            />
            <button type="submit" className="dock-dispatch-btn mono">
              Add note
            </button>
          </div>
        </form>
      </div>
    )
  }

  // Render ROS Console Stream View
  const renderConsoleContent = () => (
    <div className="dock-tab-content dock-console">
      <div className="dock-console-toolbar">
        <div className="level-chips">
          {ROS_LEVELS.map((lvl) => (
            <Chip
              key={lvl.key}
              active={minConsoleLevel === lvl.key}
              onClick={() => setMinConsoleLevel(lvl.key)}
            >
              {lvl.label}
            </Chip>
          ))}
        </div>

        <input
          type="text"
          className="dock-filter-search mono"
          placeholder="Filter /rosout..."
          value={consoleSearch}
          onChange={(e) => setConsoleSearch(e.target.value)}
        />

        <Chip active={consolePaused} onClick={() => setConsolePaused((p) => !p)}>
          {consolePaused ? 'Paused' : 'Pause'}
        </Chip>
      </div>

      <div className="dock-console-stream mono">
        {shownConsoleMessages.length === 0 ? (
          <Empty>No /rosout messages at level {minConsoleLevel}. Waiting for stream...</Empty>
        ) : (
          shownConsoleMessages.map((m, i) => (
            <div key={i} className={`console-row lvl-${m.level}`}>
              <span className="c-name">{m.name || 'node'}</span>
              <span className="c-msg">{m.msg}</span>
            </div>
          ))
        )}
      </div>
    </div>
  )

  // Render Process Logs View
  const renderProcessContent = () => (
    <div className="dock-tab-content dock-process">
      <div className="dock-process-toolbar">
        <select
          className="dock-process-select mono"
          value={selectedProcessNode}
          onChange={(e) => setSelectedProcessNode(e.target.value)}
        >
          {launches.length === 0 && (
            <option value={selectedProcessNode}>{selectedProcessNode}</option>
          )}
          {launches.map((l) => (
            <option key={l.name} value={l.name}>
              {l.state === 'running' ? '● ' : '○ '} [{l.subsystem || 'SYS'}] {l.label || l.name}
            </option>
          ))}
        </select>

        <input
          type="text"
          className="dock-filter-search mono"
          placeholder="Filter tails..."
          value={processFilter}
          onChange={(e) => setProcessFilter(e.target.value)}
        />

        <Chip active={processPaused} onClick={() => setProcessPaused((p) => !p)}>
          {processPaused ? 'Paused' : 'Pause'}
        </Chip>
      </div>

      <div className="dock-process-stream mono">
        <Empty>No output received from {selectedProcessNode} yet.</Empty>
      </div>
    </div>
  )

  if (isCollapsed) {
    return (
      <div
        className="right-side-logs-dock collapsed"
        onClick={() => setIsCollapsed(false)}
        title="Click to expand right-side logs dock"
      >
        <div className="collapsed-dock-rail">
          <IconLogs size={14} />
          <span className="collapsed-rail-text mono">SYSTEM & OPERATIONS LOGS [{currentSub.toUpperCase()}]</span>
          <span className="collapsed-badge ok mono">ACTIVE</span>
        </div>
      </div>
    )
  }

  return (
    <div
      className={`right-side-logs-dock expanded ${isResizing ? 'is-resizing' : ''}`}
      style={{ width: dockWidth }}
    >
      {/* DRAGGABLE LEFT RESIZER HANDLE */}
      <div
        className="dock-left-resizer"
        onMouseDown={handleResizerMouseDown}
        title="Drag edge to resize right-side logs dock"
      >
        <div className="dock-resizer-line" />
      </div>

      {/* DOCK MAIN HEADER */}
      <div className="dock-header">
        <div className="dock-header-title">
          <IconLogs size={14} className="dock-icon" />
          <span className="dock-title-text mono">SYSTEM & OPS LOGS</span>
          <span className="dock-sub-badge mono ok">[{currentSub.toUpperCase()}]</span>
        </div>

        <div className="dock-header-actions">
          {/* Subsystem quick switcher dropdown */}
          <select
            className="dock-sub-switcher mono"
            value={currentSub}
            onChange={(e) => {
              setCurrentSub(e.target.value)
              if (onSelectSubsystem) onSelectSubsystem(e.target.value)
            }}
            title="Switch active subsystem logs"
          >
            {SUBSYSTEM_LIST.map((s) => (
              <option key={s.id} value={s.id}>
                [{s.code}] {s.name}
              </option>
            ))}
          </select>

          {/* Minimize / Collapse Dock */}
          <button
            type="button"
            className="dock-min-btn"
            onClick={() => setIsCollapsed(true)}
            title="Collapse logs dock to rail"
          >
            <IconMinimize size={12} />
          </button>
        </div>
      </div>

      {/* VIEW MODE TABS */}
      <div className="dock-tabs-nav">
        <button
          type="button"
          className={`dock-tab-btn ${tab === 'ops' ? 'active' : ''}`}
          onClick={() => setTab('ops')}
        >
          <span className="mono">Ops Logs</span>
        </button>
        <button
          type="button"
          className={`dock-tab-btn ${tab === 'console' ? 'active' : ''}`}
          onClick={() => setTab('console')}
        >
          <span className="mono">/rosout</span>
        </button>
        <button
          type="button"
          className={`dock-tab-btn ${tab === 'process' ? 'active' : ''}`}
          onClick={() => setTab('process')}
        >
          <span className="mono">Process</span>
        </button>
        <button
          type="button"
          className={`dock-tab-btn ${tab === 'split' ? 'active' : ''}`}
          onClick={() => setTab('split')}
        >
          <span className="mono">Split</span>
        </button>
      </div>

      {/* DOCK TAB BODY */}
      <div className="dock-body">
        {tab === 'ops' && renderOpsLogsContent()}
        {tab === 'console' && renderConsoleContent()}
        {tab === 'process' && renderProcessContent()}
        {tab === 'split' && (
          <div className="dock-split-container">
            <div className="split-half top">{renderOpsLogsContent()}</div>
            <div className="split-half bottom">{renderConsoleContent()}</div>
          </div>
        )}
      </div>
    </div>
  )
}
