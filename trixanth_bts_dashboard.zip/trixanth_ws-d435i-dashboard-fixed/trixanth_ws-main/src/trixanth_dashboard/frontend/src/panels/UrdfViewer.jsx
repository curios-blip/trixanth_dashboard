import { useState, useRef, useEffect } from 'react'
import { getParam, useTopic } from '../ros'
import { config } from '../config'
import { Readout, fmt, Chip } from '../components/ui'

/** Pull link / joint / mass facts out of a real URDF string. */
function parseUrdf(xml) {
  try {
    const doc = new DOMParser().parseFromString(xml, 'application/xml')
    if (doc.querySelector('parsererror')) return null
    const links = [...doc.querySelectorAll('robot > link')].map((l) => l.getAttribute('name'))
    const joints = [...doc.querySelectorAll('robot > joint')].map((j) => ({
      name: j.getAttribute('name'),
      type: j.getAttribute('type'),
    }))
    const masses = [...doc.querySelectorAll('robot > link > inertial > mass')]
      .map((m) => parseFloat(m.getAttribute('value')))
      .filter((v) => Number.isFinite(v))
    return { name: doc.documentElement.getAttribute('name'), links, joints, mass: masses.length ? masses.reduce((a, b) => a + b, 0) : null }
  } catch {
    return null
  }
}

export default function UrdfViewer({ onExpand = null }) {
  const [tab, setTab] = useState('3d') // '3d' | 'xml'
  const [copied, setCopied] = useState(false)
  const [wireframe, setWireframe] = useState(false)

  const odom = useTopic(config.topics.odom, { throttle: 100 })
  const arm = null

  // The real robot_description, read through rosapi from robot_state_publisher.
  const [urdf, setUrdf] = useState(null)
  const [urdfNote, setUrdfNote] = useState('Waiting for robot_description…')
  useEffect(() => {
    let alive = true
    let id
    const load = async () => {
      try {
        const v = await getParam('/robot_state_publisher:robot_description')
        if (!alive) return
        if (typeof v === 'string' && v.includes('<robot')) {
          setUrdf(v)
          setUrdfNote(null)
          return
        }
        setUrdfNote('No robot_description found. Start a launch that runs robot_state_publisher.')
      } catch {
        if (alive) setUrdfNote('rosapi did not answer, so robot_description could not be read.')
      }
      id = setTimeout(load, 5000)
    }
    load()
    return () => { alive = false; clearTimeout(id) }
  }, [])
  const info = urdf ? parseUrdf(urdf) : null

  const tw = odom?.twist?.twist
  const speed = tw ? Math.hypot(tw.linear.x, tw.linear.y) : 0
  const yawRate = tw?.angular?.z ?? 0

  const canvasRef = useRef(null)

  const copyUrdf = () => {
    if (urdf) navigator.clipboard.writeText(urdf)
    setCopied(true)
    setTimeout(() => setCopied(false), 2500)
  }

  // Animated 3D Kinematics Renderer
  useEffect(() => {
    if (tab !== '3d') return
    let raf
    let angle = 0.5
    let wheelRot = 0

    const draw = () => {
      const el = canvasRef.current
      if (!el) return
      const rect = el.parentElement?.getBoundingClientRect() || { width: 600, height: 380 }
      const dpr = window.devicePixelRatio || 1
      if (el.width !== rect.width * dpr || el.height !== rect.height * dpr) {
        el.width = rect.width * dpr
        el.height = rect.height * dpr
      }
      const ctx = el.getContext('2d')
      if (!ctx) return
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      const { width: w, height: h } = rect

      ctx.fillStyle = '#0c0f14'
      ctx.fillRect(0, 0, w, h)

      // Perspective Grid Floor
      const cx = w / 2
      const cy = h / 2 + 50
      ctx.strokeStyle = '#18202c'
      ctx.lineWidth = 1
      for (let x = -250; x <= 250; x += 30) {
        ctx.beginPath()
        ctx.moveTo(cx + x * 0.4, cy - 90)
        ctx.lineTo(cx + x * 1.5, cy + 110)
        ctx.stroke()
      }
      for (let y = -90; y <= 110; y += 25) {
        const span = (y + 110) * 1.4 + 40
        ctx.beginPath()
        ctx.moveTo(cx - span, cy + y)
        ctx.lineTo(cx + span, cy + y)
        ctx.stroke()
      }

      // Coordinate axes
      ctx.lineWidth = 2
      // X axis (Red)
      ctx.strokeStyle = '#e5544b'
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + 40, cy + 15); ctx.stroke()
      // Y axis (Green)
      ctx.strokeStyle = '#4fd6a0'
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx - 35, cy + 15); ctx.stroke()
      // Z axis (Blue)
      ctx.strokeStyle = '#5aa9ff'
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx, cy - 45); ctx.stroke()

      wheelRot += speed * 0.15

      // ROVER CHASSIS BOX
      const bw = 140, bh = 44, bd = 80
      const boxY = cy - 25

      // Shadow
      ctx.fillStyle = 'rgba(0,0,0,0.45)'
      ctx.beginPath()
      ctx.ellipse(cx, cy + 30, 100, 35, 0, 0, Math.PI * 2)
      ctx.fill()

      if (wireframe) {
        ctx.strokeStyle = '#4fd6a0'
        ctx.lineWidth = 1.5
        ctx.strokeRect(cx - bw / 2, boxY - bh / 2, bw, bh)
      } else {
        // Top Face
        ctx.fillStyle = '#202834'
        ctx.beginPath()
        ctx.moveTo(cx - bw / 2, boxY - bh / 2)
        ctx.lineTo(cx + bw / 2, boxY - bh / 2)
        ctx.lineTo(cx + bw / 2 + 20, boxY - bh / 2 - 25)
        ctx.lineTo(cx - bw / 2 + 20, boxY - bh / 2 - 25)
        ctx.closePath()
        ctx.fill()
        ctx.strokeStyle = '#323d4e'; ctx.stroke()

        // Front Face
        ctx.fillStyle = '#181e27'
        ctx.fillRect(cx - bw / 2, boxY - bh / 2, bw, bh)
        ctx.strokeStyle = '#2d3747'; ctx.strokeRect(cx - bw / 2, boxY - bh / 2, bw, bh)

        // Side Face
        ctx.fillStyle = '#131820'
        ctx.beginPath()
        ctx.moveTo(cx + bw / 2, boxY - bh / 2)
        ctx.lineTo(cx + bw / 2 + 20, boxY - bh / 2 - 25)
        ctx.lineTo(cx + bw / 2 + 20, boxY + bh / 2 - 25)
        ctx.lineTo(cx + bw / 2, boxY + bh / 2)
        ctx.closePath()
        ctx.fill()
        ctx.strokeStyle = '#283241'; ctx.stroke()
      }

      // 4 WHEELS (FL, FR, RL, RR)
      const wheels = [
        { x: cx - bw / 2 - 12, y: boxY + bh / 2 + 10, label: 'RL' },
        { x: cx - bw / 2 + 35, y: boxY + bh / 2 + 24, label: 'FL' },
        { x: cx + bw / 2 - 25, y: boxY + bh / 2 + 24, label: 'FR' },
        { x: cx + bw / 2 + 22, y: boxY + bh / 2 + 10, label: 'RR' },
      ]

      wheels.forEach((wObj, idx) => {
        ctx.fillStyle = '#0a0d12'
        ctx.strokeStyle = idx % 2 === 0 ? '#5aa9ff' : '#4fd6a0'
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.ellipse(wObj.x, wObj.y, 16, 26, 0.1, 0, Math.PI * 2)
        ctx.fill()
        ctx.stroke()

        // Tread line
        ctx.strokeStyle = 'rgba(255,255,255,0.4)'
        ctx.lineWidth = 1
        const treadY = Math.sin(wheelRot + idx) * 10
        ctx.beginPath()
        ctx.moveTo(wObj.x - 8, wObj.y + treadY)
        ctx.lineTo(wObj.x + 8, wObj.y + treadY)
        ctx.stroke()
      })

      // SENSOR MAST & D435i CAMERA
      const mastX = cx + 18, mastY = boxY - bh / 2 - 20
      ctx.strokeStyle = '#7f8a9c'
      ctx.lineWidth = 4
      ctx.beginPath(); ctx.moveTo(mastX, boxY - bh / 2); ctx.lineTo(mastX, mastY - 35); ctx.stroke()

      // RealSense D435i Camera Head
      ctx.fillStyle = '#5aa9ff'
      ctx.fillRect(mastX - 12, mastY - 45, 28, 10)
      ctx.fillStyle = '#00ffff'
      ctx.beginPath(); ctx.arc(mastX - 5, mastY - 40, 2.5, 0, Math.PI * 2); ctx.fill()
      ctx.beginPath(); ctx.arc(mastX + 7, mastY - 40, 2.5, 0, Math.PI * 2); ctx.fill()

      // 6-DOF ARM MANIPULATOR
      const armBaseX = cx - 35, armBaseY = boxY - bh / 2
      // No arm joint feedback exists, so the arm is drawn in a fixed neutral pose.
      const j1 = 0
      const j2 = 0
      const j3 = 0

      // Link 1 (Shoulder)
      const l1_x = armBaseX + Math.sin(j1) * 15
      const l1_y = armBaseY - 30
      ctx.strokeStyle = '#e8b84b'
      ctx.lineWidth = 4
      ctx.beginPath(); ctx.moveTo(armBaseX, armBaseY); ctx.lineTo(l1_x, l1_y); ctx.stroke()

      // Link 2 (Elbow)
      const l2_x = l1_x + Math.cos(j2) * 35
      const l2_y = l1_y + Math.sin(j2) * 35
      ctx.strokeStyle = '#e8b84b'
      ctx.lineWidth = 3.5
      ctx.beginPath(); ctx.moveTo(l1_x, l1_y); ctx.lineTo(l2_x, l2_y); ctx.stroke()

      // Link 3 (Wrist & Gripper)
      const l3_x = l2_x + Math.cos(j3) * 28
      const l3_y = l2_y + Math.sin(j3) * 28
      ctx.strokeStyle = '#4fd6a0'
      ctx.lineWidth = 2.5
      ctx.beginPath(); ctx.moveTo(l2_x, l2_y); ctx.lineTo(l3_x, l3_y); ctx.stroke()
      ctx.fillStyle = '#4fd6a0'
      ctx.beginPath(); ctx.arc(l3_x, l3_y, 4, 0, Math.PI * 2); ctx.fill()

      // Text Labels
      ctx.fillStyle = 'rgba(255,255,255,0.7)'
      ctx.font = '10px ui-monospace, monospace'
      ctx.fillText('base_link', cx - 25, boxY + bh / 2 + 42)
      ctx.fillText('d435i_camera_link', mastX + 20, mastY - 40)
      ctx.fillText('gripper_tool_frame', l3_x + 8, l3_y - 4)

      angle += 0.01
      raf = requestAnimationFrame(draw)
    }

    raf = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(raf)
  }, [tab, wireframe, speed, arm])

  return (
    <div className="dedicated-section-container urdf-viewer-container">
      <div className="section-head-bar">
        <div className="section-title-wrap">
          <h2>URDF Kinematics & 3D Robot Description</h2>
          <span className="mono badge ok">trixanth_description (Jazzy)</span>
        </div>
        <div className="section-actions">
          <div className="chip-row">
            <Chip active={tab === '3d'} onClick={() => setTab('3d')}>
              3D Kinematics Model
            </Chip>
            <Chip active={tab === 'xml'} onClick={() => setTab('xml')}>
              URDF XML Inspector
            </Chip>
          </div>
          {onExpand && (
            <button
              type="button"
              className="ops-btn"
              onClick={onExpand}
              title="Expand back to full Operations deck"
            >
              Expand to Operations
            </button>
          )}
        </div>
      </div>

      {tab === '3d' && (
        <div className="urdf-3d-deck">
          <div className="urdf-canvas-wrap">
            <canvas ref={canvasRef} className="urdf-canvas" />
            <div className="urdf-canvas-overlay">
              <label className="checkbox">
                <input
                  type="checkbox"
                  checked={wireframe}
                  onChange={(e) => setWireframe(e.target.checked)}
                />
                Wireframe Mesh
              </label>
              <span className="mono overlay-tag">
                Schematic only, not drawn from the URDF · wheel spin follows real odometry speed
              </span>
            </div>
          </div>

          <div className="urdf-stats-grid">
            <div className="tel-card">
              <div className="tel-card-head">
                <h3>{info ? `Robot Links (${info.links.length})` : 'Robot Links'}</h3>
                {info?.name && <span className="mono badge">{info.name}</span>}
              </div>
              {info ? (
                <div className="tel-metrics-list">
                  <div className="metric-row"><span className="label">Links</span><span className="val mono">{info.links.join(', ')}</span></div>
                  <div className="metric-row"><span className="label">Joints ({info.joints.length})</span><span className="val mono">{info.joints.map((j) => `${j.name} [${j.type}]`).join(', ') || '—'}</span></div>
                </div>
              ) : (
                <p className="empty-note">{urdfNote}</p>
              )}
            </div>

            <div className="tel-card">
              <div className="tel-card-head">
                <h3>Physical attributes (from URDF)</h3>
              </div>
              <div className="tel-card-stats">
                <Readout label="Total mass" value={info?.mass != null ? info.mass.toFixed(2) : null} unit="kg" />
                <Readout label="Links" value={info ? info.links.length : null} />
                <Readout label="Joints" value={info ? info.joints.length : null} />
              </div>
              {info && info.mass == null && <p className="empty-note">The URDF has no inertial mass values.</p>}
            </div>
          </div>
        </div>
      )}

      {tab === 'xml' && (
        <div className="urdf-xml-deck">
          <div className="urdf-xml-toolbar">
            <span className="urdf-file-path mono">
              robot_description parameter (robot_state_publisher)
            </span>
            <div className="xml-tools-right">
              {copied && <span className="calib-feedback mono">Copied XML to Clipboard!</span>}
              <button type="button" className="ops-btn" onClick={copyUrdf}>
                Copy URDF XML
              </button>
            </div>
          </div>
          <pre className="urdf-xml-content mono">
            <code>{urdf ?? urdfNote}</code>
          </pre>
        </div>
      )}
    </div>
  )
}
