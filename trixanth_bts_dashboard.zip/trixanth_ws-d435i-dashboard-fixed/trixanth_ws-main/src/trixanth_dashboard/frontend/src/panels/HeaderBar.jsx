import { useState } from 'react'
import { config, DEMO, setDemo } from '../config'
import { callService, useRoundTrip, useRosStatus, useTopic } from '../ros'
import { Dot, fmt } from '../components/ui'
import ControlModeBadge from '../components/ControlModeBadge'

export default function HeaderBar({
  stopped,
  setStopped,
  drivingActive = false,
}) {
  const status = useRosStatus()
  const battery = useTopic(config.topics.battery, { throttle: 2000 })
  const fsm = useTopic(config.topics.fsmState, { throttle: 500 })

  // trixanth_interfaces/msg/MissionState — /mission/state (2Hz from mission_monitor)
  const missionState = useTopic(config.topics.missionState, { throttle: 500 })
  // /trixanth/link_ok and /trixanth/link_age from link_monitor
  const linkOk = useTopic(config.topics.linkOk, { throttle: 500 })
  const linkAge = useTopic(config.topics.linkAge, { throttle: 500 })

  // Link pills. Outside demo mode every state below is measured:
  //  ros     rosbridge socket + round trip of a rosapi call
  //  safety  /trixanth/link_ok and /trixanth/link_age from link_monitor
  //  camera  HTTP round trip to web_video_server
  //  launch  HTTP round trip to the launch manager
  const rosRtt = useRoundTrip('ros')
  const camRtt = useRoundTrip('http', config.videoServerUrl)
  const launchRtt = useRoundTrip('http', `${config.launchManagerUrl}/api/launches`)
  const [demoLinks, setDemoLinks] = useState({ rosbridge: true, safety: true, camera: true, launch: true })

  const volts = battery?.voltage
  const vClass =
    volts == null ? '' : volts < config.battery.critical ? 'fault'
      : volts < config.battery.warn ? 'warn' : 'ok'

  const linkState = DEMO ? 'demo' : status === 'connected' ? 'running' : 'crashed'
  const canStop = DEMO || status === 'connected'

  // MissionState fields
  const MODE_NAMES = ['IDLE', 'MANUAL', 'AUTONOMOUS', 'ESTOP']
  const modeIdx = missionState?.mode ?? null
  const modeName = modeIdx != null ? MODE_NAMES[modeIdx] : null
  const modeClass = modeIdx === 3 ? 'fault' : modeIdx === 2 ? 'ok' : modeIdx === 1 ? 'warn' : ''
  const missionName = missionState?.mission?.toUpperCase() ?? null
  const elapsedSec = missionState?.elapsed_s ?? null
  const limitSec = missionState?.limit_s ?? null
  const fmtTime = (sec) => {
    const m = Math.floor(sec / 60); const s = Math.floor(sec % 60)
    return `${m}:${String(s).padStart(2, '0')}`
  }
  const isLinkOk = linkOk?.data !== false
  const linkAgeSec = linkAge?.data ?? null

  const toggleStop = async () => {
    const next = !stopped
    try {
      const r = await callService(config.services.setMode, { mode: next ? config.MODES.ESTOP : config.MODES.IDLE })
      if (r && r.success === false) throw new Error(r.message)
      setStopped(next)
    } catch {
      setStopped('failed')
    }
  }

  // Returns { state: 'working' | 'down' | 'unknown', metric }
  const getLink = (id) => {
    if (DEMO) return { state: demoLinks[id] ? 'working' : 'down', metric: demoLinks[id] ? 'demo' : 'DOWN' }
    const fromProbe = (r) =>
      r.up == null ? { state: 'unknown', metric: '…' }
        : r.up ? { state: 'working', metric: r.ms != null ? `${r.ms}ms` : 'UP' }
        : { state: 'down', metric: 'DOWN' }
    if (id === 'rosbridge') {
      if (status !== 'connected') return { state: 'down', metric: status === 'connecting' ? '…' : 'DOWN' }
      return rosRtt.up === false ? { state: 'down', metric: 'NO REPLY' }
        : { state: 'working', metric: rosRtt.ms != null ? `${rosRtt.ms}ms` : 'UP' }
    }
    if (id === 'safety') {
      if (linkOk == null && linkAge == null) return { state: 'unknown', metric: 'NO DATA' }
      const ok = linkOk?.data !== false
      return { state: ok ? 'working' : 'down', metric: ok && linkAgeSec != null ? `${Math.round(linkAgeSec * 1000)}ms` : 'DOWN' }
    }
    if (id === 'camera') return fromProbe(camRtt)
    if (id === 'launch') return fromProbe(launchRtt)
    return { state: 'unknown', metric: '—' }
  }

  return (
    <header>
      <div className="brand-zone">
        <div className="brand">
          <span className="mark" aria-hidden />
          <h1>{config.roverName}</h1>
        </div>

        <div className="top-links-bar" title="Measured links">
          {config.links.map((link) => {
            const { state, metric } = getLink(link.id)
            return (
              <button
                key={link.id}
                type="button"
                className={`top-link-pill ${state}`}
                onClick={DEMO ? () => setDemoLinks((p) => ({ ...p, [link.id]: !p[link.id] })) : undefined}
                title={`${link.name}${link.port ? ` · port ${link.port}` : ''} · ${state === 'working' ? 'up' : state === 'down' ? 'down' : 'no data yet'}${DEMO ? ' · demo: click to toggle' : ''}`}
              >
                <span className={`link-dot ${state}`} />
                <span className="link-title">{link.shortName}</span>
                <span className="link-metric mono">{metric}</span>
              </button>
            )
          })}
        </div>
      </div>

      <div className="hud">
        <span className="hud-item">
          <Dot state={linkState} />
          {DEMO ? 'simulated data' : `rosbridge ${status}`}
        </span>

        {/* Drive mode from command_gate: AUTONOMOUS / MANUAL / IDLE / E-STOP */}
        <ControlModeBadge />
        {missionName && <span className="hud-item mono">{missionName}</span>}
        {missionState?.running && elapsedSec != null && limitSec != null && (
          <span className={`hud-item mono ${elapsedSec > limitSec * 0.85 ? 'warn' : 'ok'}`}>
            {fmtTime(elapsedSec)} / {fmtTime(limitSec)}
          </span>
        )}

        {/* link_monitor: /trixanth/link_ok */}
        {linkAgeSec != null && (
          <span className={`hud-item mono ${isLinkOk ? 'ok' : 'fault'}`}>
            LINK {isLinkOk ? `${linkAgeSec.toFixed(2)}s` : 'DOWN'}
          </span>
        )}

        <span className="hud-item mono">{fsm?.data ?? '—'}</span>
        <span className={`hud-item mono ${vClass}`}>
          {volts != null ? `${fmt(volts, 1)} V` : '— V'}
          {battery?.percentage != null && ` · ${Math.round(battery.percentage * 100)}%`}
        </span>
        {drivingActive && (
          <span className="hud-item mono drive-active-badge">
            TELEOP DRIVE ACTIVE
          </span>
        )}
      </div>

      <div className="header-right">
        <label className="checkbox demo-toggle">
          <input type="checkbox" checked={DEMO} onChange={(e) => setDemo(e.target.checked)} />
          Demo
        </label>
        {stopped === 'failed' && (
          <span className="notice inline">Command did not reach the rover.</span>
        )}
        <button
          className={stopped === true ? 'softstop released' : 'softstop'}
          disabled={!canStop}
          onClick={toggleStop}
        >
          {stopped === true ? 'Release soft stop' : 'Soft stop'}
        </button>
      </div>
    </header>
  )
}
