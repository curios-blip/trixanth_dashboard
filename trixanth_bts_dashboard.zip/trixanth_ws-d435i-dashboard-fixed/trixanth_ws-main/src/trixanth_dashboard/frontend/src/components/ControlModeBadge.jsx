import { useControlMode } from '../hooks/useDerived'

const TEXT = [
  { label: 'IDLE', sub: 'No drive commands passed' },
  { label: 'MANUAL', sub: 'Operator driving (teleop)' },
  { label: 'AUTONOMOUS', sub: 'Rover driving itself, teleop locked out' },
  { label: 'E-STOP', sub: 'Motion inhibited' },
]
const CLS = ['idle', 'manual', 'auto', 'estop']

/** Large, always-visible drive-mode indicator. Shows "NO MODE DATA" rather than guessing. */
export default function ControlModeBadge() {
  const { idx, source, lastEvent } = useControlMode()
  const t = idx != null ? TEXT[idx] : null
  const title = idx != null
    ? `Drive mode from ${source}${lastEvent ? ` · last change: ${lastEvent}` : ''}`
    : 'Neither /trixanth/mode nor /mission/state has been received. Is command_gate running?'
  return (
    <div className={`mode-badge ${idx != null ? CLS[idx] : 'unknown'}`} role="status" aria-live="polite" title={title}>
      <span className="mode-badge-dot" aria-hidden />
      <span className="mode-badge-text">
        <strong className="mono">{t ? t.label : 'NO MODE DATA'}</strong>
        <small>{t ? t.sub : 'Waiting for command_gate'}</small>
      </span>
    </div>
  )
}
