import { useEffect, useRef, useState } from 'react'
import { config } from '../config'
import { useTopic } from '../ros'

/** Distance driven since this page loaded, integrated from real odometry messages. */
export function useDistanceDriven(odom) {
  const last = useRef(null)
  const [total, setTotal] = useState(null)
  useEffect(() => {
    const p = odom?.pose?.pose?.position
    if (!p) return
    if (last.current) {
      const d = Math.hypot(p.x - last.current.x, p.y - last.current.y)
      // ignore jumps from a re-localisation; real driving between 2 samples is well under this
      if (d < 5) setTotal((t) => (t ?? 0) + d)
    } else {
      setTotal(0)
    }
    last.current = { x: p.x, y: p.y }
  }, [odom])
  return total
}

/**
 * Current drive mode, straight from command_gate (/trixanth/mode, UInt8), falling back to the
 * copy in /mission/state while mission_monitor is running. null until one of them is heard.
 */
export function useControlMode() {
  const modeMsg = useTopic(config.topics.mode, { throttle: 100 })
  const state = useTopic(config.topics.missionState, { throttle: 500 })
  const event = useTopic(config.topics.modeEvent, { throttle: 100 })
  const raw = modeMsg?.data ?? state?.mode ?? null
  const idx = Number.isInteger(raw) && raw >= 0 && raw < config.MODE_NAMES.length ? raw : null
  return {
    idx,
    name: idx != null ? config.MODE_NAMES[idx] : null,
    source: modeMsg ? config.topics.mode.name : state ? config.topics.missionState.name : null,
    lastEvent: event?.data ?? null,
  }
}
