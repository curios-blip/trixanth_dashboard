"""Local + global EKF and navsat_transform."""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    cfg = PathJoinSubstitution([FindPackageShare("trixanth_localization"), "config", "ekf.yaml"])
    sim = LaunchConfiguration("use_sim_time")
    common = [cfg, {"use_sim_time": sim}]
    return LaunchDescription([
        DeclareLaunchArgument("use_sim_time", default_value="false"),
        Node(package="robot_localization", executable="ekf_node", name="ekf_local", parameters=common,
             remappings=[("odometry/filtered", "odometry/local")], output="screen"),
        Node(package="robot_localization", executable="ekf_node", name="ekf_global", parameters=common,
             remappings=[("odometry/filtered", "odometry/global")], output="screen"),
        Node(package="robot_localization", executable="navsat_transform_node", name="navsat_transform",
             parameters=common,
             remappings=[("imu", "imu/data"), ("gps/fix", "gps/fix"),
                         ("odometry/filtered", "odometry/global"), ("odometry/gps", "odometry/gps"),
                         ("gps/filtered", "gps/filtered")],
             output="screen"),
    ])
