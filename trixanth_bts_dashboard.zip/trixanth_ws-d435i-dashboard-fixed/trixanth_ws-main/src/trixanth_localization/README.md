# trixanth_localization

Standard `robot_localization` GPS setup: two EKFs and `navsat_transform`. Config only, no code.

## What runs

| Node | Inputs | Output | TF |
| --- | --- | --- | --- |
| `ekf_local` | `/odom/wheel` (vx, yaw rate), `/imu/data` (orientation, angular velocity) | `/odometry/local` | `odom → base_footprint` |
| `ekf_global` | the same + `/odometry/gps` (x, y) | `/odometry/global` | `map → odom` |
| `navsat_transform` | `/gps/fix`, `/imu/data`, `/odometry/global` | `/odometry/gps`, `/gps/filtered`, service `/fromLL` | none |

`two_d_mode` is off so pitch and roll are tracked on slopes and dunes. The `map` frame has no prior map: it is a local ENU frame anchored at the first GPS fix. `/fromLL` turns WGS 84 lat/lon into `map` coordinates; `trixanth_navigation` and `rado_fsm` use it for GPS goals.

## Launch

```bash
ros2 launch trixanth_localization localization.launch.py [use_sim_time:=true]
```

## Settings to check on the real rover (`config/ekf.yaml`)

| Parameter | Value | Check |
| --- | --- | --- |
| `magnetic_declination_radians` | `-0.0175` (≈ −1° for Bengaluru) | Verify with the NOAA calculator before the finals |
| `yaw_offset` | `0.0` | The IMU must read 0 facing east (REP 103). If it reads 0 facing north, set `1.5708` |
| `imu0_remove_gravitational_acceleration` | `true` | |

## Test

- Drive a closed loop and compare start and end in `/odometry/global` (TESTING.md S2 and F2).
- Heading on the dashboard should match a phone compass within a few degrees.
- `ros2 service call /fromLL robot_localization/srv/FromLL "{ll_point: {latitude: 12.661, longitude: 77.4495}}"`
