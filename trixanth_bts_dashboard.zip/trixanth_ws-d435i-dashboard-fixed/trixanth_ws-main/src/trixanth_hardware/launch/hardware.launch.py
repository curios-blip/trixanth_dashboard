"""Base controller bridge, science sensor bridge and GPS driver."""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    cfg = PathJoinSubstitution([FindPackageShare("trixanth_hardware"), "config", "hardware.yaml"])
    return LaunchDescription([
        DeclareLaunchArgument("science", default_value="false", description="Start the ESP32 science bridge (ABEx)"),
        DeclareLaunchArgument("gps_port", default_value="/dev/trixanth_gps"),
        Node(package="trixanth_hardware", executable="base_bridge", parameters=[cfg], output="screen"),
        Node(package="trixanth_hardware", executable="sensor_bridge", parameters=[cfg], output="screen",
             condition=IfCondition(LaunchConfiguration("science"))),
        # Generic NMEA driver. If you use a u-blox F9P with RTK, swap for ublox_gps.
        Node(
            package="nmea_navsat_driver",
            executable="nmea_serial_driver",
            name="gps",
            parameters=[{"port": LaunchConfiguration("gps_port"), "baud": 115200, "frame_id": "gps_link"}],
            remappings=[("fix", "gps/fix")],
            output="screen",
        ),
    ])
