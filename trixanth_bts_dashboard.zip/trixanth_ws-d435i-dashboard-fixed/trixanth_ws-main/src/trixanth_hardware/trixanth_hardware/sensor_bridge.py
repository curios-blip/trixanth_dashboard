"""Serial bridge for the ESP32 ABEx science sensor node.

The ESP32 prints one JSON object per line, for example:
  {"soil_temp_c": 24.1, "soil_moisture_pct": 12.0, "air_temp_c": 30.2, "humidity_pct": 41.0,
   "pressure_pa": 91234.0, "ph": 7.3}
Missing keys are skipped.

Publishes under /abex/:
  soil_temperature (sensor_msgs/Temperature)   air_temperature (sensor_msgs/Temperature)
  humidity (sensor_msgs/RelativeHumidity, 0..1) pressure (sensor_msgs/FluidPressure, Pa)
  ph (std_msgs/Float32)                        soil_moisture (std_msgs/Float32, %)
"""
import json

import rclpy
import serial
from rclpy.node import Node
from sensor_msgs.msg import FluidPressure, RelativeHumidity, Temperature
from std_msgs.msg import Float32


class SensorBridge(Node):
    def __init__(self):
        super().__init__("sensor_bridge")
        self.declare_parameter("port", "/dev/trixanth_esp32_science")
        self.declare_parameter("baud", 115200)
        self.declare_parameter("frame_id", "science_link")
        self.port = self.get_parameter("port").value
        self.baud = self.get_parameter("baud").value
        self.frame = self.get_parameter("frame_id").value

        self.pub_soil_t = self.create_publisher(Temperature, "abex/soil_temperature", 10)
        self.pub_air_t = self.create_publisher(Temperature, "abex/air_temperature", 10)
        self.pub_hum = self.create_publisher(RelativeHumidity, "abex/humidity", 10)
        self.pub_press = self.create_publisher(FluidPressure, "abex/pressure", 10)
        self.pub_ph = self.create_publisher(Float32, "abex/ph", 10)
        self.pub_moist = self.create_publisher(Float32, "abex/soil_moisture", 10)

        self.ser = None
        self.buf = ""
        self.create_timer(0.02, self.poll)
        self.create_timer(1.0, self.ensure_open)
        self.ensure_open()

    def ensure_open(self):
        if self.ser is not None and self.ser.is_open:
            return
        try:
            self.ser = serial.Serial(self.port, self.baud, timeout=0)
            self.get_logger().info(f"Opened {self.port}")
        except serial.SerialException as e:
            self.ser = None
            self.get_logger().warn(f"Cannot open {self.port}: {e}", throttle_duration_sec=5.0)

    def poll(self):
        if self.ser is None:
            return
        try:
            n = self.ser.in_waiting
            if n:
                self.buf += self.ser.read(n).decode("utf-8", errors="ignore")
        except (serial.SerialException, OSError) as e:
            self.get_logger().error(f"Serial read failed: {e}")
            self.ser = None
            return
        while "\n" in self.buf:
            line, self.buf = self.buf.split("\n", 1)
            line = line.strip()
            if not line.startswith("{"):
                continue
            try:
                self.publish(json.loads(line))
            except json.JSONDecodeError:
                self.get_logger().warn(f"Bad JSON: {line}", throttle_duration_sec=2.0)

    def publish(self, d):
        stamp = self.get_clock().now().to_msg()

        def temp(pub, key):
            if key in d:
                m = Temperature()
                m.header.stamp, m.header.frame_id = stamp, self.frame
                m.temperature = float(d[key])
                pub.publish(m)

        temp(self.pub_soil_t, "soil_temp_c")
        temp(self.pub_air_t, "air_temp_c")
        if "humidity_pct" in d:
            m = RelativeHumidity()
            m.header.stamp, m.header.frame_id = stamp, self.frame
            m.relative_humidity = float(d["humidity_pct"]) / 100.0
            self.pub_hum.publish(m)
        if "pressure_pa" in d:
            m = FluidPressure()
            m.header.stamp, m.header.frame_id = stamp, self.frame
            m.fluid_pressure = float(d["pressure_pa"])
            self.pub_press.publish(m)
        if "ph" in d:
            self.pub_ph.publish(Float32(data=float(d["ph"])))
        if "soil_moisture_pct" in d:
            self.pub_moist.publish(Float32(data=float(d["soil_moisture_pct"])))


def main():
    rclpy.init()
    node = SensorBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
