"""Line protocol shared by the Jetson bridges and the Teensy firmware.

Each line is:  <payload>*<checksum>\n
payload  = comma-separated fields, first field is the message type
checksum = XOR of all payload bytes, two upper-case hex digits

Jetson -> Teensy
  V,<left_mps>,<right_mps>      wheel side speeds in m/s
  P                             ping (Teensy answers with S)

Teensy -> Jetson
  E,<millis>,<left_ticks>,<right_ticks>                 cumulative encoder ticks per side (averaged)
  I,<qw>,<qx>,<qy>,<qz>,<gx>,<gy>,<gz>,<ax>,<ay>,<az>    IMU: quaternion, rad/s, m/s^2
  S,<kill>,<battery_v>                                  kill=1 when the external kill switch is open
"""


def checksum(payload: str) -> str:
    c = 0
    for b in payload.encode("ascii", errors="ignore"):
        c ^= b
    return f"{c:02X}"


def encode(*fields) -> bytes:
    payload = ",".join(str(f) for f in fields)
    return f"{payload}*{checksum(payload)}\n".encode("ascii")


def decode(line: str):
    """Return the list of fields, or None if the line is malformed or fails the checksum."""
    line = line.strip()
    if "*" not in line:
        return None
    payload, _, cs = line.rpartition("*")
    if checksum(payload) != cs.upper():
        return None
    return payload.split(",")
