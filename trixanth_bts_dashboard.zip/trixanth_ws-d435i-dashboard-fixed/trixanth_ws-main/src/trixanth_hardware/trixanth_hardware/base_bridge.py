"""Serial bridge between ROS 2 and the Teensy 4.1 base controller.

Subscribes  /cmd_vel                (geometry_msgs/Twist)   output of trixanth_comms/command_gate
Publishes   /odom/wheel             (nav_msgs/Odometry)     no TF; the EKF owns odom->base_footprint
            /imu/data               (sensor_msgs/Imu)
            /trixanth/kill_switch   (std_msgs/Bool)         true = motor-bus stop open (see CONNECTIONS.md)
            /trixanth/battery       (sensor_msgs/BatteryState)
"""
import math

import rclpy
import serial
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from sensor_msgs.msg import BatteryState, Imu
from std_msgs.msg import Bool

from trixanth_hardware.protocol import decode, encode


class BaseBridge(Node):
    def __init__(self):
        super().__init__("base_bridge")
        self.declare_parameter("port", "/dev/trixanth_teensy")
        self.declare_parameter("baud", 115200)
        self.declare_parameter("wheel_radius", 0.15)
        self.declare_parameter("track_width", 0.94)      # distance between left and right wheel centres
        self.declare_parameter("ticks_per_rev", 4096.0)  # encoder ticks per WHEEL revolution (after gearbox)
        self.declare_parameter("max_speed", 1.2)         # m/s per side, clamp
        self.declare_parameter("cmd_timeout", 0.3)       # s; send zero if no cmd_vel in this time
        self.declare_parameter("base_frame", "base_footprint")
        self.declare_parameter("imu_frame", "imu_link")

        self.port = self.get_parameter("port").value
        self.baud = self.get_parameter("baud").value
        self.r = self.get_parameter("wheel_radius").value
        self.track = self.get_parameter("track_width").value
        self.tpr = self.get_parameter("ticks_per_rev").value
        self.max_speed = self.get_parameter("max_speed").value
        self.cmd_timeout = self.get_parameter("cmd_timeout").value
        self.base_frame = self.get_parameter("base_frame").value
        self.imu_frame = self.get_parameter("imu_frame").value

        self.ser = None
        self.buf = ""
        self.last_cmd = Twist()
        self.last_cmd_time = self.get_clock().now()
        self.prev_ticks = None
        self.prev_ms = None
        self.x = self.y = self.yaw = 0.0

        self.odom_pub = self.create_publisher(Odometry, "odom/wheel", 20)
        self.imu_pub = self.create_publisher(Imu, "imu/data", 50)
        self.kill_pub = self.create_publisher(Bool, "trixanth/kill_switch", 10)
        self.batt_pub = self.create_publisher(BatteryState, "trixanth/battery", 10)
        self.create_subscription(Twist, "cmd_vel", self.on_cmd, 10)

        self.create_timer(0.05, self.send_cmd)     # 20 Hz to the Teensy
        self.create_timer(0.005, self.poll_serial)  # read as fast as data arrives
        self.create_timer(1.0, self.ensure_open)
        self.ensure_open()

    # ---------- serial ----------
    def ensure_open(self):
        if self.ser is not None and self.ser.is_open:
            return
        try:
            self.ser = serial.Serial(self.port, self.baud, timeout=0)
            self.buf = ""
            self.get_logger().info(f"Opened {self.port}")
        except serial.SerialException as e:
            self.ser = None
            self.get_logger().warn(f"Cannot open {self.port}: {e}", throttle_duration_sec=5.0)

    def write(self, data: bytes):
        if self.ser is None:
            return
        try:
            self.ser.write(data)
        except serial.SerialException as e:
            self.get_logger().error(f"Serial write failed: {e}")
            self.ser = None

    def poll_serial(self):
        if self.ser is None:
            return
        try:
            n = self.ser.in_waiting
            if n:
                self.buf += self.ser.read(n).decode("ascii", errors="ignore")
        except (serial.SerialException, OSError) as e:
            self.get_logger().error(f"Serial read failed: {e}")
            self.ser = None
            return
        while "\n" in self.buf:
            line, self.buf = self.buf.split("\n", 1)
            fields = decode(line)
            if fields:
                self.handle(fields)

    # ---------- commands ----------
    def on_cmd(self, msg: Twist):
        self.last_cmd = msg
        self.last_cmd_time = self.get_clock().now()

    def send_cmd(self):
        age = (self.get_clock().now() - self.last_cmd_time).nanoseconds * 1e-9
        v = self.last_cmd.linear.x if age < self.cmd_timeout else 0.0
        w = self.last_cmd.angular.z if age < self.cmd_timeout else 0.0
        left = v - w * self.track / 2.0
        right = v + w * self.track / 2.0
        # scale both sides down together so the turn radius is kept
        peak = max(abs(left), abs(right), 1e-9)
        if peak > self.max_speed:
            left *= self.max_speed / peak
            right *= self.max_speed / peak
        self.write(encode("V", f"{left:.3f}", f"{right:.3f}"))

    # ---------- incoming ----------
    def handle(self, f):
        kind = f[0]
        try:
            if kind == "E" and len(f) == 4:
                self.on_encoders(int(f[1]), int(f[2]), int(f[3]))
            elif kind == "I" and len(f) == 11:
                self.on_imu([float(v) for v in f[1:]])
            elif kind == "S" and len(f) == 3:
                self.kill_pub.publish(Bool(data=f[1] == "1"))
                b = BatteryState()
                b.header.stamp = self.get_clock().now().to_msg()
                b.voltage = float(f[2])
                b.present = True
                self.batt_pub.publish(b)
        except ValueError:
            self.get_logger().warn(f"Bad fields: {f}", throttle_duration_sec=2.0)

    def on_encoders(self, ms, lt, rt):
        if self.prev_ticks is None:
            self.prev_ticks, self.prev_ms = (lt, rt), ms
            return
        dt = (ms - self.prev_ms) / 1000.0
        if dt <= 0:
            self.prev_ticks, self.prev_ms = (lt, rt), ms
            return
        m_per_tick = 2.0 * math.pi * self.r / self.tpr
        dl = (lt - self.prev_ticks[0]) * m_per_tick
        dr = (rt - self.prev_ticks[1]) * m_per_tick
        self.prev_ticks, self.prev_ms = (lt, rt), ms

        ds = (dl + dr) / 2.0
        dyaw = (dr - dl) / self.track
        self.x += ds * math.cos(self.yaw + dyaw / 2.0)
        self.y += ds * math.sin(self.yaw + dyaw / 2.0)
        self.yaw += dyaw

        o = Odometry()
        o.header.stamp = self.get_clock().now().to_msg()
        o.header.frame_id = "odom"
        o.child_frame_id = self.base_frame
        o.pose.pose.position.x = self.x
        o.pose.pose.position.y = self.y
        o.pose.pose.orientation.z = math.sin(self.yaw / 2.0)
        o.pose.pose.orientation.w = math.cos(self.yaw / 2.0)
        o.twist.twist.linear.x = ds / dt
        o.twist.twist.angular.z = dyaw / dt
        # Skid steer slips a lot on sand: trust velocity loosely, yaw rate even less
        o.twist.covariance[0] = 0.05
        o.twist.covariance[7] = 1e3
        o.twist.covariance[35] = 0.2
        o.pose.covariance[0] = o.pose.covariance[7] = 1e3
        o.pose.covariance[35] = 1e3
        self.odom_pub.publish(o)

    def on_imu(self, v):
        m = Imu()
        m.header.stamp = self.get_clock().now().to_msg()
        m.header.frame_id = self.imu_frame
        m.orientation.w, m.orientation.x, m.orientation.y, m.orientation.z = v[0:4]
        m.angular_velocity.x, m.angular_velocity.y, m.angular_velocity.z = v[4:7]
        m.linear_acceleration.x, m.linear_acceleration.y, m.linear_acceleration.z = v[7:10]
        m.orientation_covariance[0] = m.orientation_covariance[4] = m.orientation_covariance[8] = 0.01
        m.angular_velocity_covariance[0] = m.angular_velocity_covariance[4] = m.angular_velocity_covariance[8] = 0.001
        m.linear_acceleration_covariance[0] = m.linear_acceleration_covariance[4] = m.linear_acceleration_covariance[8] = 0.05
        self.imu_pub.publish(m)

    def stop(self):
        self.write(encode("V", "0.000", "0.000"))


def main():
    rclpy.init()
    node = BaseBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop()
        node.destroy_node()
        rclpy.try_shutdown()
