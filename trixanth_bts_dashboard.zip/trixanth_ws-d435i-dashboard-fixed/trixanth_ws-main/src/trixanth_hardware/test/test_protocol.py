from trixanth_hardware.protocol import checksum, decode, encode


def test_roundtrip():
    line = encode("V", "0.500", "-0.250").decode()
    assert decode(line) == ["V", "0.500", "-0.250"]


def test_bad_checksum_rejected():
    good = checksum("V,1.0,1.0")
    bad = "00" if good != "00" else "FF"
    assert decode(f"V,1.0,1.0*{bad}") is None


def test_missing_checksum_rejected():
    assert decode("V,1.0,1.0") is None
