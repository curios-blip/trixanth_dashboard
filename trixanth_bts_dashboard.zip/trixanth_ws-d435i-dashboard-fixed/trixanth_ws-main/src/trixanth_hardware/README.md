# trixanth_hardware

Jetson-side bridges to the microcontrollers and the GPS driver. Firmware for the boards is in `firmware/` at the repo root. Wiring is in `CONNECTIONS.md`.

## Nodes

### `base_bridge` (Teensy 4.1)

| Direction | Topic | Type | Notes |
| --- | --- | --- | --- |
| Sub | `/cmd_vel` | `geometry_msgs/Twist` | Only `command_gate` publishes this |
| Pub | `/odom/wheel` | `nav_msgs/Odometry` | From encoders; **no TF** (the EKF publishes it) |
| Pub | `/imu/data` | `sensor_msgs/Imu` | BNO085 on the Teensy, 100 Hz |
| Pub | `/trixanth/kill_switch` | `std_msgs/Bool` | `true` = motor-bus contactor open |
| Pub | `/trixanth/battery` | `sensor_msgs/BatteryState` | Voltage only |

Sends wheel speeds at 20 Hz and sends zero if no `/cmd_vel` for `cmd_timeout`. The Teensy also stops by itself after 300 ms without a command. Reconnects automatically if the USB cable is pulled.

| Parameter | Default | Meaning |
| --- | --- | --- |
| `port` | `/dev/trixanth_teensy` | udev symlink |
| `wheel_radius` | `0.15` | m |
| `track_width` | `0.94` | m; calibrate (skid steer needs a larger effective value) |
| `ticks_per_rev` | `4096.0` | per wheel revolution, after the gearbox |
| `max_speed` | `1.2` | m/s per side; both sides scaled together |
| `cmd_timeout` | `0.3` | s |

### `sensor_bridge` (ESP32 science node, ABEx)

Reads one JSON object per line and publishes `/abex/soil_temperature`, `/abex/air_temperature` (`Temperature`), `/abex/humidity` (`RelativeHumidity`, 0–1), `/abex/pressure` (`FluidPressure`, Pa), `/abex/ph` and `/abex/soil_moisture` (`Float32`). Missing keys are skipped.

### GPS

`nmea_navsat_driver` publishes `/gps/fix` with `frame_id: gps_link`. For a u-blox F9P with RTK, swap it for `ublox_gps`.

## Serial protocol

Defined in `trixanth_hardware/protocol.py`. ASCII lines `<fields>*<XOR checksum>`, so you can debug with a terminal:

```
Jetson -> Teensy   V,0.500,0.450*3A        left/right m/s
Teensy -> Jetson   E,<ms>,<left>,<right>   encoder ticks, 50 Hz
                   I,qw,qx,qy,qz,gx,gy,gz,ax,ay,az   IMU, 100 Hz
                   S,<kill>,<battery_v>    status, 2 Hz
```

## Launch

```bash
ros2 launch trixanth_hardware hardware.launch.py                # base + GPS
ros2 launch trixanth_hardware hardware.launch.py science:=true  # + ESP32
```

## Setup

```bash
sudo cp udev/99-trixanth.rules /etc/udev/rules.d/   # edit the serial numbers first
sudo udevadm control --reload && sudo udevadm trigger
ls -l /dev/trixanth_*
```

## Test

```bash
colcon test --packages-select trixanth_hardware        # protocol tests
ros2 topic hz /odom/wheel /imu/data                     # 50 Hz and 100 Hz
python3 -m serial.tools.miniterm /dev/trixanth_teensy 115200   # raw lines (stop the node first)
```

Bench checks B1–B6 in `TESTING.md`: wheel direction, watchdog, motor stop, IMU axes.
