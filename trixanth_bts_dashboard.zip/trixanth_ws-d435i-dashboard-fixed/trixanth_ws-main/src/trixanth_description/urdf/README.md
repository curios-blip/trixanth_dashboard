# Put the rover URDF here

Drop your model in this folder as `trixanth.urdf.xacro`. `launch/description.launch.py` loads that name and passes `use_sim:=true|false` to xacro.

## Frames the rest of the workspace expects

| Frame | Used by | Notes |
| --- | --- | --- |
| `base_footprint` | EKF, Nav2 (robot_base_frame) | On the ground, under the rover centre |
| `base_link` | everything | Child of `base_footprint` |
| `imu_link` | EKF | Must match `frame_id` in `/imu/data` |
| `gps_link` | navsat_transform | Must match `frame_id` in `/gps/fix` |
| `camera_link` | red zone, perception, traversability | RealSense driver publishes the optical frames under it on the real robot |
| `camera_color_optical_frame` | perception, red zone | Needed in the URDF for sim only |
| `arm_mount` | manipulation (optional) | |

`odom -> base_footprint` comes from the local EKF and `map -> odom` from the global EKF, so the URDF must **not** publish either.

## For simulation (`use_sim:=true`)

Add Gazebo Harmonic plugins inside an `<xacro:if value="$(arg use_sim)">` block:

- `gz-sim-diff-drive-system`: subscribe `cmd_vel`, publish odometry on `odom/wheel`, and send its TF to an unused topic (for example `<tf_topic>/gz_unused_tf</tf_topic>`) so it does not fight the EKF.
- `gz-sim-joint-state-publisher-system` on topic `joint_states`.
- An `imu` sensor on `imu_link`, topic `imu/data`.
- A `navsat` sensor on `gps_link`, topic `gps/fix`.
- An `rgbd_camera` sensor on `camera_link`, topic `camera`, `gz_frame_id` `camera_color_optical_frame`.

These topic names match `trixanth_sim/config/gz_bridge.yaml`. If you name them differently, change the bridge file, not the nodes.
