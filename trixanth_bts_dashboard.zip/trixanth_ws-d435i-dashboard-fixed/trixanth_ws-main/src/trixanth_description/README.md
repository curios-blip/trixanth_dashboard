# trixanth_description

The robot model. **The URDF is not in the repo yet**: put it at `urdf/trixanth.urdf.xacro`. The frame names, topic names and Gazebo plugins the rest of the workspace expects are listed in [`urdf/README.md`](urdf/README.md).

## Launch

```bash
ros2 launch trixanth_description description.launch.py              # real robot
ros2 launch trixanth_description description.launch.py use_sim:=true # adds the Gazebo block
```

Starts `robot_state_publisher` with `robot_description` built by xacro. The xacro file receives `use_sim:=true|false`, so wrap the Gazebo plugins in `<xacro:if value="$(arg use_sim)">`.

| Argument | Default | Meaning |
| --- | --- | --- |
| `use_sim` | `false` | Passed to xacro and used as `use_sim_time` |

## Rules for the URDF

- Root link `base_footprint` on the ground; `base_link` its child.
- Do **not** publish `odom → base_footprint` or `map → odom`. The EKFs in `trixanth_localization` own those.
- On the real robot the RealSense driver publishes `camera_link → camera_*_optical_frame`. Only add the optical frames inside the sim block.
- Keep the footprint in `trixanth_navigation/config/nav2_params.yaml` and `trixanth_obstacle_avoidance/config/collision_monitor.yaml` matching the URDF outline, with the arm stowed. IRC limit: 1.5 m x 1.2 m (rule 2.2).

## Check

```bash
xacro urdf/trixanth.urdf.xacro use_sim:=false > /tmp/t.urdf && check_urdf /tmp/t.urdf
ros2 run tf2_tools view_frames      # with the launch running
```
