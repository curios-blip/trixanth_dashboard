"""Nav2 servers started individually so the cmd_vel chain is explicit (see nav2_params.yaml header)."""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

NODES = ["controller_server", "smoother_server", "planner_server", "behavior_server",
         "velocity_smoother", "bt_navigator", "waypoint_follower"]


def generate_launch_description():
    params = LaunchConfiguration("params_file")
    sim = LaunchConfiguration("use_sim_time")
    p = [params, {"use_sim_time": sim}]

    return LaunchDescription([
        DeclareLaunchArgument("use_sim_time", default_value="false"),
        DeclareLaunchArgument("params_file", default_value=PathJoinSubstitution(
            [FindPackageShare("trixanth_navigation"), "config", "nav2_params.yaml"])),

        Node(package="nav2_controller", executable="controller_server", parameters=p, output="screen",
             remappings=[("cmd_vel", "cmd_vel_nav")]),
        Node(package="nav2_smoother", executable="smoother_server", parameters=p, output="screen"),
        Node(package="nav2_planner", executable="planner_server", parameters=p, output="screen"),
        Node(package="nav2_behaviors", executable="behavior_server", parameters=p, output="screen",
             remappings=[("cmd_vel", "cmd_vel_nav")]),
        Node(package="nav2_velocity_smoother", executable="velocity_smoother", parameters=p, output="screen",
             remappings=[("cmd_vel", "cmd_vel_nav"), ("cmd_vel_smoothed", "cmd_vel_smoothed")]),
        Node(package="nav2_bt_navigator", executable="bt_navigator", parameters=p, output="screen"),
        Node(package="nav2_waypoint_follower", executable="waypoint_follower", parameters=p, output="screen"),
        Node(package="nav2_lifecycle_manager", executable="lifecycle_manager", name="lifecycle_manager_navigation",
             parameters=[{"use_sim_time": sim, "autostart": True, "node_names": NODES}], output="screen"),
    ])
