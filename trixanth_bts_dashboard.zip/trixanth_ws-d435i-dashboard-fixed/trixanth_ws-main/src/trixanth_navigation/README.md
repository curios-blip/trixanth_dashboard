# trixanth_navigation

Nav2 for outdoor GPS navigation with no prior map: SMAC Hybrid-A* planner, MPPI controller, rolling costmaps.

## Velocity chain

```
controller_server / behavior_server ──/cmd_vel_nav──► velocity_smoother ──/cmd_vel_smoothed──►
collision_monitor (trixanth_obstacle_avoidance) ──/cmd_vel_auto──► command_gate (trixanth_comms) ──/cmd_vel──► base_bridge
```

The Nav2 servers are started one by one in `launch/navigation.launch.py` (not through `nav2_bringup`) so these remaps are explicit.

## Launch

```bash
ros2 launch trixanth_navigation navigation.launch.py [use_sim_time:=true] [params_file:=...]
```

Starts `controller_server`, `smoother_server`, `planner_server`, `behavior_server`, `velocity_smoother`, `bt_navigator`, `waypoint_follower` and a lifecycle manager.

## Key settings (`config/nav2_params.yaml`)

| Item | Value | Why |
| --- | --- | --- |
| Footprint | 1.2 x 1.1 m **placeholder** | Replace with the real outline; keep in sync with `collision_monitor.yaml` |
| Global costmap | `map`, rolling 60 x 60 m, 0.2 m, unknown = free | No map; long GPS routes still plan |
| Local costmap | `odom`, rolling 12 x 12 m, 0.1 m | |
| Layers | `traversability_layer`, `red_zone_layer`, `inflation_layer` | Inputs from `trixanth_obstacle_avoidance` and `trixanth_red_zone`. Red zones never clear |
| Planner | `SmacPlannerHybrid`, `REEDS_SHEPP`, min turn radius 0.5 m | Use `DUBIN` to forbid reversing |
| Controller | MPPI `DiffDrive`, 0.8 m/s max, 20 Hz | Drop `batch_size` to 1000 if the Orin Nano can't keep 20 Hz |
| Goal tolerance | 1.5 m | GPS-level; the last metres are done by the vision approach in `rado_fsm` |
| Progress checker | 0.3 m in 15 s | Slow progress in sand isn't treated as stuck too early |

## GPS goal tool

```bash
ros2 run trixanth_navigation gps_goal --ros-args -p lat:=12.6610898 -p lon:=77.4496841
```

Converts lat/lon with `/fromLL` and sends `NavigateToPose`. Exits 1 if the goal fails. The same conversion is in `trixanth_navigation/gps_utils.py` (`GpsConverter`, `haversine_m`).

## Test

TESTING.md S3 (GPS goal in sim), S4 (obstacles), S9 (inaccurate GPS), F2 on terrain. Watch both costmaps in RViz with fixed frame `map`.
