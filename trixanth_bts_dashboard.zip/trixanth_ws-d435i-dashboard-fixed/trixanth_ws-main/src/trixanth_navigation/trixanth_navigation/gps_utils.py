"""Turn WGS 84 coordinates into map-frame poses via navsat_transform's /fromLL service."""
import math

from geographic_msgs.msg import GeoPoint
from geometry_msgs.msg import PoseStamped
from robot_localization.srv import FromLL


class GpsConverter:
    def __init__(self, node, service="/fromLL"):
        self.node = node
        self.cli = node.create_client(FromLL, service)

    def wait(self, timeout_s=10.0) -> bool:
        return self.cli.wait_for_service(timeout_sec=timeout_s)

    def to_map_pose(self, lat: float, lon: float, yaw: float = 0.0, timeout_s: float = 3.0):
        """Blocking call; returns PoseStamped in 'map' or None. Call from a node spun in another thread
        or with rclpy.spin_until_future_complete on the same node."""
        import rclpy

        req = FromLL.Request()
        req.ll_point = GeoPoint(latitude=lat, longitude=lon, altitude=0.0)
        fut = self.cli.call_async(req)
        rclpy.spin_until_future_complete(self.node, fut, timeout_sec=timeout_s)
        if not fut.done() or fut.result() is None:
            return None
        p = PoseStamped()
        p.header.frame_id = "map"
        p.header.stamp = self.node.get_clock().now().to_msg()
        p.pose.position = fut.result().map_point
        p.pose.position.z = 0.0
        p.pose.orientation.z = math.sin(yaw / 2.0)
        p.pose.orientation.w = math.cos(yaw / 2.0)
        return p


def haversine_m(lat1, lon1, lat2, lon2):
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))
