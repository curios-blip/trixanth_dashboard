"""Drive to a GPS coordinate. Test tool for the navigation stack.

  ros2 run trixanth_navigation gps_goal --ros-args -p lat:=12.66123 -p lon:=77.45012
"""
import rclpy
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult

from trixanth_navigation.gps_utils import GpsConverter


def main():
    rclpy.init()
    nav = BasicNavigator(node_name="gps_goal")
    nav.declare_parameter("lat", 0.0)
    nav.declare_parameter("lon", 0.0)
    lat = nav.get_parameter("lat").value
    lon = nav.get_parameter("lon").value
    if lat == 0.0 and lon == 0.0:
        nav.get_logger().error("Set -p lat:=... -p lon:=...")
        return

    conv = GpsConverter(nav)
    if not conv.wait():
        nav.get_logger().error("/fromLL not available: is navsat_transform running?")
        return
    goal = conv.to_map_pose(lat, lon)
    if goal is None:
        nav.get_logger().error("fromLL conversion failed")
        return

    nav.waitUntilNav2Active(localizer="robot_localization")
    nav.get_logger().info(f"Goal map ({goal.pose.position.x:.1f}, {goal.pose.position.y:.1f})")
    nav.goToPose(goal)
    while not nav.isTaskComplete():
        fb = nav.getFeedback()
        if fb:
            nav.get_logger().info(f"Distance remaining {fb.distance_remaining:.1f} m", throttle_duration_sec=2.0)
        rclpy.spin_once(nav, timeout_sec=0.1)
    result = nav.getResult()
    nav.get_logger().info(f"Result: {result}")
    if result != TaskResult.SUCCEEDED:
        raise SystemExit(1)
    rclpy.try_shutdown()
