"""Gazebo Harmonic + bridge + robot spawn. Needs your URDF in trixanth_description/urdf (with its sim block)."""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    sim_share = FindPackageShare("trixanth_sim")
    world = LaunchConfiguration("world")
    return LaunchDescription([
        DeclareLaunchArgument("world", default_value=PathJoinSubstitution([sim_share, "worlds", "sproscape_lite.sdf"])),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(PathJoinSubstitution(
                [FindPackageShare("ros_gz_sim"), "launch", "gz_sim.launch.py"])),
            launch_arguments={"gz_args": ["-r ", world]}.items(),
        ),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(PathJoinSubstitution(
                [FindPackageShare("trixanth_description"), "launch", "description.launch.py"])),
            launch_arguments={"use_sim": "true"}.items(),
        ),
        Node(package="ros_gz_sim", executable="create", output="screen",
             arguments=["-topic", "robot_description", "-name", "trixanth", "-x", "0", "-y", "0", "-z", "0.4"]),
        Node(package="ros_gz_bridge", executable="parameter_bridge", output="screen",
             parameters=[{"config_file": PathJoinSubstitution([sim_share, "config", "gz_bridge.yaml"]),
                          "use_sim_time": True}]),
    ])
