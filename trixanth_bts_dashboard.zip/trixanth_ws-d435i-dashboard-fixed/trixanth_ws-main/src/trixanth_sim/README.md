# trixanth_sim

Gazebo Harmonic test field (`worlds/sproscape_lite.sdf`) for testing the RADO stack before hardware. Since venue testing is not allowed, this is where every autonomy change is proven first.

## The world

GPS origin 12.66100, 77.44950 (approximate, near the venue). World x = east, y = north.

| Model | Position (x, y) | Tests |
| --- | --- | --- |
| `ramp_15` | (8, −6) | 15° slope: should be crossed |
| `ramp_32` | (8, 6) | 32° slope: should be refused |
| `plateau_drop` | (−10, 12) | 0.5 m vertical drop on the north edge |
| `boulder_1`, `rock_1`, `rock_2` | various | Rocks to plan around |
| `pebble_ok` | (3, 1) | 10 cm rock: should **not** block |
| `red_cone_1`, `red_cone_2`, `red_rock` | various | Red no-go objects |
| `red_patch` | (−8, 22) | Flat red area with **no collision**: only vision can avoid it |
| `marker_blue` | (20, 10) | Delivery `SIM_BLUE` |
| `marker_green` | (−15, 25) | Delivery `SIM_GREEN`, behind the plateau and the red patch |

GPS positions of the markers are in `config/sim_deliveries.yaml`.

## Bridge

`config/gz_bridge.yaml` maps Gazebo topics to the same ROS names the real rover uses (`/cmd_vel`, `/odom/wheel`, `/imu/data`, `/gps/fix`, `/camera/color/image_raw`, `/camera/aligned_depth_to_color/image_raw`, `/camera/color/camera_info`, `/camera/depth/color/points`, `/clock`), so the rest of the stack runs unchanged with `use_sim_time:=true`. The Gazebo-side names must match the sensor `<topic>` tags in your URDF's sim block (see `trixanth_description/urdf/README.md`).

## Launch

```bash
ros2 launch trixanth_sim sim.launch.py                    # world + robot + bridge only
ros2 launch trixanth_bringup sim_rado.launch.py           # full RADO stack
ros2 run trixanth_comms ground_heartbeat                  # "ground station" in a second terminal
```

Needs the URDF in `trixanth_description` first.

## Make it harder over time

- Shift the delivery GPS in `sim_deliveries.yaml` by 3–5 m (inaccurate coordinates, TESTING.md S9).
- Move red cones onto the straight-line path between start and markers.
- Add a heightmap of real dune or quarry terrain once you have one.
- Lower the ground friction (`mu`) to mimic soft sand.
