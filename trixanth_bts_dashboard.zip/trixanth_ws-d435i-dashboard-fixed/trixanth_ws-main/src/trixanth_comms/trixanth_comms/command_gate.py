"""Single owner of the drive mode and the only node that publishes /cmd_vel.

Inputs   /cmd_vel_teleop (Twist)  from the ground station joystick (via rosbridge)
         /cmd_vel_auto   (Twist)  from Nav2 collision monitor or the FSM approach controller
         /trixanth/kill_switch (Bool) from base_bridge
         /trixanth/link_ok     (Bool) from link_monitor
Service  /set_mode (trixanth_interfaces/SetMode)
Outputs  /cmd_vel (Twist), /trixanth/mode (std_msgs/UInt8, transient local)
         /trixanth/mode_event (std_msgs/String): "ENTER AUTONOMOUS 00:12:31" etc. Dashboard must show
                                                and sound this so the team leader tells the judge (rule 3.3.2).
         /trixanth/autonomy_violations (std_msgs/UInt32): teleop messages received while AUTONOMOUS.
"""
import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile
from std_msgs.msg import Bool, String, UInt8, UInt32

from trixanth_comms import gate_logic as gl
from trixanth_interfaces.srv import SetMode


class CommandGate(Node):
    def __init__(self):
        super().__init__("command_gate")
        self.declare_parameter("teleop_timeout", 0.5)
        self.declare_parameter("auto_timeout", 0.5)
        self.declare_parameter("rate_hz", 20.0)
        self.declare_parameter("initial_mode", gl.IDLE)
        self.teleop_timeout = self.get_parameter("teleop_timeout").value
        self.auto_timeout = self.get_parameter("auto_timeout").value

        self.mode = int(self.get_parameter("initial_mode").value)
        self.kill_open = False
        self.link_ok = False
        self.teleop = (Twist(), None)
        self.auto = (Twist(), None)
        self.violations = 0
        self.start = self.get_clock().now()

        latched = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.pub_cmd = self.create_publisher(Twist, "cmd_vel", 10)
        self.pub_mode = self.create_publisher(UInt8, "trixanth/mode", latched)
        self.pub_event = self.create_publisher(String, "trixanth/mode_event", 10)
        self.pub_viol = self.create_publisher(UInt32, "trixanth/autonomy_violations", latched)

        self.create_subscription(Twist, "cmd_vel_teleop", self.on_teleop, 10)
        self.create_subscription(Twist, "cmd_vel_auto", self.on_auto, 10)
        self.create_subscription(Bool, "trixanth/kill_switch", self.on_kill, 10)
        self.create_subscription(Bool, "trixanth/link_ok", self.on_link, 10)
        self.create_service(SetMode, "set_mode", self.on_set_mode)
        self.create_timer(1.0 / self.get_parameter("rate_hz").value, self.tick)
        self.publish_mode()

    # ---------- inputs ----------
    def on_teleop(self, msg):
        if self.mode == gl.AUTONOMOUS:
            self.violations += 1
            self.pub_viol.publish(UInt32(data=self.violations))
            self.get_logger().warn("Teleop command received in AUTONOMOUS mode: dropped",
                                   throttle_duration_sec=1.0)
            return
        self.teleop = (msg, self.get_clock().now())

    def on_auto(self, msg):
        self.auto = (msg, self.get_clock().now())

    def on_kill(self, msg):
        if msg.data and not self.kill_open:
            self.set_mode(gl.ESTOP, "kill switch opened")
        self.kill_open = msg.data

    def on_link(self, msg):
        if self.link_ok and not msg.data:
            self.get_logger().warn(f"Link lost in {gl.NAMES[self.mode]}")
        self.link_ok = msg.data

    def on_set_mode(self, req, res):
        ok, why = gl.allowed_transition(self.mode, req.mode, self.kill_open)
        if ok:
            self.set_mode(req.mode, "requested")
        res.success, res.message = ok, why or gl.NAMES[self.mode]
        return res

    # ---------- logic ----------
    def fresh(self, stamp, timeout):
        return stamp is not None and (self.get_clock().now() - stamp).nanoseconds * 1e-9 < timeout

    def set_mode(self, mode, reason):
        if mode == self.mode:
            return
        prev = self.mode
        self.mode = mode
        self.teleop = (Twist(), None)
        self.auto = (Twist(), None)
        t = (self.get_clock().now() - self.start).nanoseconds * 1e-9
        stamp = f"{int(t // 3600):02d}:{int(t % 3600 // 60):02d}:{int(t % 60):02d}"
        verb = "ENTER" if mode != gl.IDLE else "EXIT"
        event = f"{verb} {gl.NAMES[mode]} {stamp} (from {gl.NAMES[prev]}, {reason})"
        self.pub_event.publish(String(data=event))
        self.get_logger().info(event)
        self.publish_mode()

    def publish_mode(self):
        self.pub_mode.publish(UInt8(data=self.mode))

    def tick(self):
        src = gl.select(self.mode, self.kill_open, self.link_ok,
                        self.fresh(self.teleop[1], self.teleop_timeout),
                        self.fresh(self.auto[1], self.auto_timeout))
        if src == "teleop":
            self.pub_cmd.publish(self.teleop[0])
        elif src == "auto":
            self.pub_cmd.publish(self.auto[0])
        else:
            self.pub_cmd.publish(Twist())


def main():
    rclpy.init()
    node = CommandGate()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.pub_cmd.publish(Twist())
        node.destroy_node()
        rclpy.try_shutdown()
