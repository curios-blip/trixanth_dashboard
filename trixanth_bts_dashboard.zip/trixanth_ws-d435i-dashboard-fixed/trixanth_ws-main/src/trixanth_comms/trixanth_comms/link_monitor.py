"""Rover side: decides whether the ground link is alive from the ground heartbeat.

Subscribes  /ground/heartbeat (std_msgs/Header) sent by the ground station at ~5 Hz
Publishes   /trixanth/link_ok (Bool), /trixanth/link_age (Float32, seconds since last heartbeat)

The heartbeat is a keep-alive, not a drive command. Confirm with the officials that it may keep running
in autonomous mode (see the questions list); if not, set require_in_auto:=false and stop sending it.
"""
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, Float32, Header


class LinkMonitor(Node):
    def __init__(self):
        super().__init__("link_monitor")
        self.declare_parameter("timeout", 1.0)
        self.timeout = self.get_parameter("timeout").value
        self.last = None
        self.ok = False
        self.pub_ok = self.create_publisher(Bool, "trixanth/link_ok", 10)
        self.pub_age = self.create_publisher(Float32, "trixanth/link_age", 10)
        self.create_subscription(Header, "ground/heartbeat", self.on_hb, 10)
        self.create_timer(0.1, self.tick)

    def on_hb(self, _msg):
        self.last = self.get_clock().now()

    def tick(self):
        age = 1e9 if self.last is None else (self.get_clock().now() - self.last).nanoseconds * 1e-9
        ok = age < self.timeout
        if ok != self.ok:
            self.get_logger().info("Link UP" if ok else f"Link DOWN (no heartbeat for {age:.1f} s)")
        self.ok = ok
        self.pub_ok.publish(Bool(data=ok))
        self.pub_age.publish(Float32(data=float(min(age, 999.0))))


def main():
    rclpy.init()
    node = LinkMonitor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
