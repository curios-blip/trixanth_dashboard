"""Ground-station side heartbeat (5 Hz). Run on the base-station laptop, or send the same message from the
dashboard through rosbridge. Stopping this node simulates a link loss in tests."""
import rclpy
from rclpy.node import Node
from std_msgs.msg import Header


class GroundHeartbeat(Node):
    def __init__(self):
        super().__init__("ground_heartbeat")
        self.declare_parameter("rate_hz", 5.0)
        self.pub = self.create_publisher(Header, "ground/heartbeat", 10)
        self.create_timer(1.0 / self.get_parameter("rate_hz").value, self.tick)

    def tick(self):
        h = Header()
        h.stamp = self.get_clock().now().to_msg()
        h.frame_id = "ground_station"
        self.pub.publish(h)


def main():
    rclpy.init()
    node = GroundHeartbeat()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
