"""Mode and command-source rules (no ROS imports, unit-tested).

IRC 3.3.2: in autonomous mode operators may watch video and telemetry but may not transmit commands.
The gate enforces that on the rover side too: in AUTONOMOUS, teleop commands are dropped and counted.
"""
IDLE, MANUAL, AUTONOMOUS, ESTOP = 0, 1, 2, 3
NAMES = {IDLE: "IDLE", MANUAL: "MANUAL", AUTONOMOUS: "AUTONOMOUS", ESTOP: "ESTOP"}


def select(mode, kill_open, link_ok, teleop_fresh, auto_fresh):
    """Which source drives the wheels: 'teleop', 'auto' or 'zero'."""
    if kill_open or mode in (IDLE, ESTOP):
        return "zero"
    if mode == MANUAL:
        return "teleop" if (link_ok and teleop_fresh) else "zero"
    if mode == AUTONOMOUS:
        return "auto" if auto_fresh else "zero"   # link loss does NOT stop autonomy
    return "zero"


def allowed_transition(current, requested, kill_open):
    if requested not in NAMES:
        return False, "unknown mode"
    if kill_open and requested in (MANUAL, AUTONOMOUS):
        return False, "kill switch open"
    if current == ESTOP and requested == AUTONOMOUS:
        return False, "go through MANUAL or IDLE after an e-stop"
    return True, ""
