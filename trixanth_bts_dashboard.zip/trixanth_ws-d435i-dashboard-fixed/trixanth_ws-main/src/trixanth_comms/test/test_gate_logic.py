from trixanth_comms import gate_logic as gl


def test_kill_switch_always_wins():
    for mode in (gl.IDLE, gl.MANUAL, gl.AUTONOMOUS):
        assert gl.select(mode, True, True, True, True) == "zero"


def test_manual_needs_link_and_fresh_teleop():
    assert gl.select(gl.MANUAL, False, True, True, True) == "teleop"
    assert gl.select(gl.MANUAL, False, False, True, True) == "zero"
    assert gl.select(gl.MANUAL, False, True, False, True) == "zero"


def test_autonomous_survives_link_loss():
    assert gl.select(gl.AUTONOMOUS, False, False, False, True) == "auto"


def test_autonomous_never_uses_teleop():
    assert gl.select(gl.AUTONOMOUS, False, True, True, False) == "zero"


def test_no_autonomy_with_kill_open():
    ok, _ = gl.allowed_transition(gl.MANUAL, gl.AUTONOMOUS, kill_open=True)
    assert not ok


def test_estop_cannot_jump_to_auto():
    ok, _ = gl.allowed_transition(gl.ESTOP, gl.AUTONOMOUS, kill_open=False)
    assert not ok
