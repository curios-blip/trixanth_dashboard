# trixanth_comms

Owns the drive mode and is the only node that publishes `/cmd_vel`. Enforces rule 3.3.2 on the rover: in autonomous mode no command from the ground can move the rover.

## `command_gate`

| Direction | Name | Type |
| --- | --- | --- |
| Sub | `/cmd_vel_teleop` | `Twist` (dashboard joystick) |
| Sub | `/cmd_vel_auto` | `Twist` (collision monitor, `rado_fsm`) |
| Sub | `/trixanth/kill_switch` | `Bool` (from `base_bridge`) |
| Sub | `/trixanth/link_ok` | `Bool` (from `link_monitor`) |
| Service | `/set_mode` | `trixanth_interfaces/SetMode` |
| Pub | `/cmd_vel` | `Twist`, 20 Hz |
| Pub | `/trixanth/mode` | `UInt8`, latched |
| Pub | `/trixanth/mode_event` | `String`, e.g. `ENTER AUTONOMOUS 00:12:31 (from MANUAL, requested)` |
| Pub | `/trixanth/autonomy_violations` | `UInt32`, teleop messages received in AUTONOMOUS |

| Mode | Wheels driven by |
| --- | --- |
| IDLE, ESTOP | nothing (zero) |
| MANUAL | teleop, only while the link is up and teleop is fresh (< 0.5 s) |
| AUTONOMOUS | `/cmd_vel_auto` only; teleop dropped and counted; **link loss does not stop it** |

Kill switch (motor bus) open → ESTOP. Transitions to MANUAL/AUTONOMOUS are refused with the kill open, and ESTOP cannot jump straight to AUTONOMOUS. Rules are in `gate_logic.py` (unit-tested).

**Dashboard:** show `/trixanth/mode_event` with a sound. The team leader must tell the judge every time the rover enters autonomous mode.

## `link_monitor`

Sub `/ground/heartbeat` (`std_msgs/Header`). Pub `/trixanth/link_ok` (`Bool`) and `/trixanth/link_age` (`Float32`, s). Parameter `timeout` (1.0 s).

## `ground_heartbeat`

Publishes `/ground/heartbeat` at 5 Hz. For bench and sim tests. In the field the dashboard sends the same message through rosbridge. Stop it to simulate a link loss.

## Launch

```bash
ros2 launch trixanth_comms comms.launch.py [link_timeout:=1.0]
ros2 run trixanth_comms ground_heartbeat          # ground side
ros2 service call /set_mode trixanth_interfaces/srv/SetMode "{mode: 1}"
```

## Open question for the officials

The heartbeat keeps running in autonomous mode. It is a keep-alive, not a command, but confirm it is allowed (see the questions list in the plan doc).

## Test

```bash
colcon test --packages-select trixanth_comms
```

TESTING.md S7 (link loss in AUTO), S8 (command lockout), B4 (motor stop).
