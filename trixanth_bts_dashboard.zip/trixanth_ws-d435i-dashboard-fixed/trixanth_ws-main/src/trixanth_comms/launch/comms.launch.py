from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    sim = LaunchConfiguration("use_sim_time")
    return LaunchDescription([
        DeclareLaunchArgument("use_sim_time", default_value="false"),
        DeclareLaunchArgument("link_timeout", default_value="1.0"),
        Node(package="trixanth_comms", executable="command_gate", name="command_gate",
             parameters=[{"use_sim_time": sim}], output="screen"),
        Node(package="trixanth_comms", executable="link_monitor", name="link_monitor",
             parameters=[{"use_sim_time": sim, "timeout": LaunchConfiguration("link_timeout")}], output="screen"),
    ])
