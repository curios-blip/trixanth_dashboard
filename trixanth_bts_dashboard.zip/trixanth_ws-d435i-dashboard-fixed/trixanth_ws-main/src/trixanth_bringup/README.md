# trixanth_bringup

One launch file per mission. Each includes the other packages' launch files; there is no code here.

| Launch file | Starts | Use |
| --- | --- | --- |
| `robot.launch.py` | description, hardware bridges + GPS, RealSense (aligned depth, point cloud, 640x480 @ 15), EKFs, command gate + link monitor | Base layer for every mission on the real rover. `science:=true` adds the ESP32 bridge |
| `camera.launch.py` | RealSense D435i only, same settings as robot.launch.py | Laptop testing of the dashboard camera feed, no rover hardware |
| `rado.launch.py` | robot + obstacle avoidance + red zone + Nav2 + perception + mission (rado) + rosbridge | RADO |
| `abex.launch.py` | robot (with science) + obstacle avoidance + red zone + science tools + mission (abex) + rosbridge | ABEx; driving is teleop, hazard layers still warn |
| `idmo.launch.py` | robot + red zone + mission (idmo) + rosbridge | IDMO; arm nodes come from the manipulation team |
| `sim_rado.launch.py` | Gazebo + the RADO stack with `use_sim_time` and the sim deliveries | Simulation testing |

## Arguments

| Launch file | Argument | Default |
| --- | --- | --- |
| `robot` | `science` | `false` |
| `rado`, `abex`, `idmo` | `rosbridge` | `true` (the dashboard launch passes `false`, it owns rosbridge) |
| `rado` | `deliveries_file` | `trixanth_mission/config/rado_deliveries.yaml` |
| `rado` | `model` | `/home/trixanth/models/rado_yolov8n.engine` |
| `sim_rado` | `deliveries_file` | `trixanth_sim/config/sim_deliveries.yaml` |
| `sim_rado` | `detector`, `model`, `device` | `false`, `yolov8n.pt`, `cpu` |

## Mission-day use

```bash
# after the briefing: write the deliveries, then
ros2 launch trixanth_bringup rado.launch.py deliveries_file:=/home/trixanth/rado_today.yaml
```

Before the field judge gives permission, the radio stays off; the rover stack can be running. Start the mission clock when the judge starts theirs:

```bash
ros2 service call /mission/start trixanth_interfaces/srv/StartMission "{mission: rado, points_max: 0}"
```

## Check a launch without hardware

```bash
ros2 launch trixanth_bringup rado.launch.py --show-args
ros2 launch --print trixanth_bringup rado.launch.py | head
```

On the Jetson set `export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST` so DDS stays off the radio; the dashboard connects only through rosbridge on port 9090.
