"""RealSense D435i only, with the topic names the dashboard expects. No rover hardware needed.

  ros2 launch trixanth_bringup camera.launch.py

Same driver settings as robot.launch.py. Topics: /camera/color/image_raw, /camera/depth/image_rect_raw,
/camera/infra1/image_rect_raw (the empty camera_namespace can only be set from a launch file,
`camera_namespace:=` on the command line is rejected).
"""
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    return LaunchDescription([
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(PathJoinSubstitution(
                [FindPackageShare("realsense2_camera"), "launch", "rs_launch.py"])),
            launch_arguments={
                "camera_namespace": "", "camera_name": "camera", "enable_color": "true", "enable_depth": "true",
                "enable_infra1": "false",                      # set "false" if you  
                "rgb_camera.color_profile": "640,480,15",
                "depth_module.depth_profile": "640,480,15",
                "depth_module.infra_profile": "640,480,15",   # this line fixes the mismatch
                "align_depth.enable": "true",
                "pointcloud.enable": "false",  
            }.items()),
    ])

