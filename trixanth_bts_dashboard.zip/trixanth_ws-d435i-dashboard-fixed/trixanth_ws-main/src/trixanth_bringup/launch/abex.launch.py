"""ABEx on the real rover: base layer with science bridge, red-zone and obstacle warnings, science tools.
Driving is teleop; red_zone and traversability still run so the dashboard can warn the driver."""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare
from launch_xml.launch_description_sources import XMLLaunchDescriptionSource


def inc(pkg, file, **args):
    return IncludeLaunchDescription(
        PythonLaunchDescriptionSource(PathJoinSubstitution([FindPackageShare(pkg), "launch", file])),
        launch_arguments=args.items())


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument("rosbridge", default_value="true"),
        inc("trixanth_bringup", "robot.launch.py", science="true"),
        inc("trixanth_obstacle_avoidance", "obstacle_avoidance.launch.py"),
        inc("trixanth_red_zone", "red_zone.launch.py"),
        inc("trixanth_science", "science.launch.py"),
        inc("trixanth_mission", "mission.launch.py", mission="abex"),
        # dashboard.launch.py normally owns rosbridge; pass rosbridge:=false when it is running.
        IncludeLaunchDescription(
            XMLLaunchDescriptionSource(PathJoinSubstitution(
                [FindPackageShare("rosbridge_server"), "launch", "rosbridge_websocket_launch.xml"])),
            condition=IfCondition(LaunchConfiguration("rosbridge"))),
    ])
