"""Full RADO stack in Gazebo. Same nodes as the real rover, with use_sim_time and the sim deliveries.

  ros2 launch trixanth_bringup sim_rado.launch.py              (no YOLO: needs a GPU + model)
  ros2 launch trixanth_bringup sim_rado.launch.py detector:=true model:=yolov8n.pt device:=cpu

Ground side (separate terminal, or the dashboard):  ros2 run trixanth_comms ground_heartbeat
"""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


def inc(pkg, file, **args):
    return IncludeLaunchDescription(
        PythonLaunchDescriptionSource(PathJoinSubstitution([FindPackageShare(pkg), "launch", file])),
        launch_arguments=args.items())


def generate_launch_description():
    sim_deliveries = PathJoinSubstitution([FindPackageShare("trixanth_sim"), "config", "sim_deliveries.yaml"])
    t = "true"
    stack = [
        inc("trixanth_localization", "localization.launch.py", use_sim_time=t),
        inc("trixanth_comms", "comms.launch.py", use_sim_time=t),
        inc("trixanth_obstacle_avoidance", "obstacle_avoidance.launch.py", use_sim_time=t),
        inc("trixanth_red_zone", "red_zone.launch.py", use_sim_time=t),
        inc("trixanth_navigation", "navigation.launch.py", use_sim_time=t),
        inc("trixanth_perception", "perception.launch.py", use_sim_time=t,
            detector=LaunchConfiguration("detector"), model=LaunchConfiguration("model"),
            device=LaunchConfiguration("device")),
        inc("trixanth_mission", "mission.launch.py", use_sim_time=t, mission="rado",
            deliveries_file=LaunchConfiguration("deliveries_file")),
    ]
    return LaunchDescription([
        DeclareLaunchArgument("deliveries_file", default_value=sim_deliveries),
        DeclareLaunchArgument("detector", default_value="false"),
        DeclareLaunchArgument("model", default_value="yolov8n.pt"),
        DeclareLaunchArgument("device", default_value="cpu"),
        inc("trixanth_sim", "sim.launch.py"),
        TimerAction(period=8.0, actions=stack),   # let Gazebo and the bridge come up first
    ])
