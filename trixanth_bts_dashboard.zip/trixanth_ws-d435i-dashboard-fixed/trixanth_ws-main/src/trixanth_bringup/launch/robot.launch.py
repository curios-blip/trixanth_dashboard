"""Base layer on the real rover: model, Teensy/ESP32/GPS bridges, RealSense, EKF, command gate."""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


def inc(pkg, file, **args):
    return IncludeLaunchDescription(
        PythonLaunchDescriptionSource(PathJoinSubstitution([FindPackageShare(pkg), "launch", file])),
        launch_arguments=args.items())


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument("science", default_value="false"),
        inc("trixanth_description", "description.launch.py", use_sim="false"),
        inc("trixanth_hardware", "hardware.launch.py", science=LaunchConfiguration("science")),
        inc("realsense2_camera", "rs_launch.py",
            camera_namespace="", camera_name="camera",
            # enable_infra1: the dashboard's "Infrared IR" button streams /camera/infra1/image_rect_raw.
            **{"align_depth.enable": "true", "pointcloud.enable": "true", "enable_infra1": "true",
               "rgb_camera.color_profile": "640,480,15", "depth_module.depth_profile": "640,480,15"}),
        inc("trixanth_localization", "localization.launch.py"),
        inc("trixanth_comms", "comms.launch.py"),
    ])
