"""RADO on the real rover: base layer + navigation + safety layers + perception + mission + rosbridge.

  ros2 launch trixanth_bringup rado.launch.py deliveries_file:=/home/trixanth/rado_today.yaml
"""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare
from launch_xml.launch_description_sources import XMLLaunchDescriptionSource


def inc(pkg, file, **args):
    return IncludeLaunchDescription(
        PythonLaunchDescriptionSource(PathJoinSubstitution([FindPackageShare(pkg), "launch", file])),
        launch_arguments=args.items())


def generate_launch_description():
    deliveries = PathJoinSubstitution([FindPackageShare("trixanth_mission"), "config", "rado_deliveries.yaml"])
    return LaunchDescription([
        DeclareLaunchArgument("rosbridge", default_value="true"),
        DeclareLaunchArgument("deliveries_file", default_value=deliveries),
        DeclareLaunchArgument("model", default_value="/home/trixanth/models/rado_yolov8n.engine"),
        inc("trixanth_bringup", "robot.launch.py"),
        inc("trixanth_obstacle_avoidance", "obstacle_avoidance.launch.py"),
        inc("trixanth_red_zone", "red_zone.launch.py"),
        inc("trixanth_navigation", "navigation.launch.py"),
        inc("trixanth_perception", "perception.launch.py", model=LaunchConfiguration("model")),
        inc("trixanth_mission", "mission.launch.py", mission="rado",
            deliveries_file=LaunchConfiguration("deliveries_file")),
        # dashboard.launch.py normally owns rosbridge; pass rosbridge:=false when it is running.
        IncludeLaunchDescription(
            XMLLaunchDescriptionSource(PathJoinSubstitution(
                [FindPackageShare("rosbridge_server"), "launch", "rosbridge_websocket_launch.xml"])),
            condition=IfCondition(LaunchConfiguration("rosbridge"))),
    ])
