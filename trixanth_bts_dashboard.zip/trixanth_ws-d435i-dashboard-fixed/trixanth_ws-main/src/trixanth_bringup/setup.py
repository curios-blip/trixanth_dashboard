import os
from glob import glob

from setuptools import find_packages, setup

package_name = "trixanth_bringup"


def data_dir(d):
    files = [f for f in glob(os.path.join(d, "**", "*"), recursive=True) if os.path.isfile(f)]
    out = {}
    for f in files:
        out.setdefault(os.path.join("share", package_name, os.path.dirname(f)), []).append(f)
    return list(out.items())


data_files = [
    ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
    ("share/" + package_name, ["package.xml"]),
]
for d in ['launch', 'config', 'urdf', 'worlds', 'rviz', 'models']:
    if os.path.isdir(d):
        data_files += data_dir(d)

setup(
    name=package_name,
    version="0.1.0",
    packages=find_packages(exclude=["test"]),
    data_files=data_files,
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="Team Trixanth",
    maintainer_email="trixanth@example.com",
    description="Top-level launch files per mission (RADO, ABEx, IDMO) for robot and sim.",
    license="Apache-2.0",
    tests_require=["pytest"],
    entry_points={
        "console_scripts": [

        ],
    },
)
