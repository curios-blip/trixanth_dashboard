"""Red segmentation and depth back-projection, kept free of ROS for unit tests."""
import cv2
import numpy as np


def red_mask(bgr, s_min=110, v_min=60, hue_low=10, hue_high=165, min_area_px=150, open_px=5):
    """Binary mask of red regions. Red wraps around hue 0/180 in OpenCV HSV, so two ranges are combined.
    Small blobs (noise, a teammate's red shirt far away) are dropped by min_area_px."""
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    m1 = cv2.inRange(hsv, (0, s_min, v_min), (hue_low, 255, 255))
    m2 = cv2.inRange(hsv, (hue_high, s_min, v_min), (180, 255, 255))
    mask = cv2.bitwise_or(m1, m2)
    if open_px > 1:
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (open_px, open_px))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    keep = np.zeros_like(mask)
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] >= min_area_px:
            keep[labels == i] = 255
    return keep


def depth_to_metres(depth):
    """Accept 16UC1 (mm, RealSense) or 32FC1 (m, Gazebo)."""
    if depth.dtype == np.uint16:
        return depth.astype(np.float32) / 1000.0
    return depth.astype(np.float32)


def deproject(mask, depth_m, fx, fy, cx, cy, stride=4, max_range=8.0):
    """(N, 3) points in the camera optical frame for masked pixels with valid depth."""
    ys, xs = np.nonzero(mask[::stride, ::stride])
    ys, xs = ys * stride, xs * stride
    z = depth_m[ys, xs]
    ok = np.isfinite(z) & (z > 0.2) & (z < max_range)
    xs, ys, z = xs[ok], ys[ok], z[ok]
    x = (xs - cx) * z / fx
    y = (ys - cy) * z / fy
    return np.stack([x, y, z], axis=1)
