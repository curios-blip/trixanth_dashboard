"""Red no-go zones (IRC rule 3.0: each entry costs 10% of mission points).

Subscribes  colour image, depth image aligned to colour, colour camera_info
Publishes   /red_zone/points  (PointCloud2 in base_footprint) -> lethal in both costmaps + collision monitor
            /red_zone/mask    (sensor_msgs/Image, mono8) for the dashboard / debugging
            /red_zone/visible (std_msgs/Bool) true when any red region is in view

Note: marker colours for RADO delivery are given before the finals. If a delivery marker is red-ish,
narrow the hue range here and test against it, or the rover will refuse to approach its own target.
"""
import message_filters
import numpy as np
import rclpy
from cv_bridge import CvBridge
from rclpy.duration import Duration
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CameraInfo, Image, PointCloud2
from sensor_msgs_py import point_cloud2
from std_msgs.msg import Bool, Header
from tf2_ros import Buffer, TransformException, TransformListener

from trixanth_red_zone.segmentation import deproject, depth_to_metres, red_mask


def quat_to_matrix(x, y, z, w):
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


class RedZone(Node):
    def __init__(self):
        super().__init__("red_zone")
        self.declare_parameter("color_topic", "/camera/color/image_raw")
        self.declare_parameter("depth_topic", "/camera/aligned_depth_to_color/image_raw")
        self.declare_parameter("info_topic", "/camera/color/camera_info")
        self.declare_parameter("target_frame", "base_footprint")
        self.declare_parameter("s_min", 110)
        self.declare_parameter("v_min", 60)
        self.declare_parameter("hue_low", 10)
        self.declare_parameter("hue_high", 165)
        self.declare_parameter("min_area_px", 150)
        self.declare_parameter("stride", 4)
        self.declare_parameter("max_range", 8.0)
        self.declare_parameter("publish_mask", True)

        g = lambda n: self.get_parameter(n).value  # noqa: E731
        self.target = g("target_frame")
        self.seg = dict(s_min=g("s_min"), v_min=g("v_min"), hue_low=g("hue_low"), hue_high=g("hue_high"),
                        min_area_px=g("min_area_px"))
        self.stride = g("stride")
        self.max_range = g("max_range")
        self.publish_mask = g("publish_mask")

        self.bridge = CvBridge()
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.pub_pts = self.create_publisher(PointCloud2, "red_zone/points", 5)
        self.pub_mask = self.create_publisher(Image, "red_zone/mask", 2)
        self.pub_vis = self.create_publisher(Bool, "red_zone/visible", 5)

        subs = [message_filters.Subscriber(self, Image, g("color_topic"), qos_profile=qos_profile_sensor_data),
                message_filters.Subscriber(self, Image, g("depth_topic"), qos_profile=qos_profile_sensor_data),
                message_filters.Subscriber(self, CameraInfo, g("info_topic"), qos_profile=qos_profile_sensor_data)]
        self.sync = message_filters.ApproximateTimeSynchronizer(subs, queue_size=5, slop=0.1)
        self.sync.registerCallback(self.on_frame)

    def on_frame(self, color: Image, depth: Image, info: CameraInfo):
        bgr = self.bridge.imgmsg_to_cv2(color, "bgr8")
        mask = red_mask(bgr, **self.seg)
        visible = bool(mask.any())
        self.pub_vis.publish(Bool(data=visible))
        if self.publish_mask:
            m = self.bridge.cv2_to_imgmsg(mask, "mono8")
            m.header = color.header
            self.pub_mask.publish(m)

        header = Header(stamp=color.header.stamp, frame_id=self.target)
        if not visible:
            self.pub_pts.publish(point_cloud2.create_cloud_xyz32(header, []))
            return

        d = depth_to_metres(self.bridge.imgmsg_to_cv2(depth, "passthrough"))
        if d.shape[:2] != mask.shape[:2]:
            self.get_logger().error("Depth is not aligned to colour (sizes differ). Enable align_depth.",
                                    throttle_duration_sec=5.0)
            return
        fx, fy, cx, cy = info.k[0], info.k[4], info.k[2], info.k[5]
        pts = deproject(mask, d, fx, fy, cx, cy, stride=self.stride, max_range=self.max_range)
        if len(pts) == 0:
            self.pub_pts.publish(point_cloud2.create_cloud_xyz32(header, []))
            return
        try:
            t = self.tf_buffer.lookup_transform(self.target, color.header.frame_id, color.header.stamp,
                                                timeout=Duration(seconds=0.05))
        except TransformException as e:
            self.get_logger().warn(f"TF: {e}", throttle_duration_sec=2.0)
            return
        q, tr = t.transform.rotation, t.transform.translation
        pts = pts @ quat_to_matrix(q.x, q.y, q.z, q.w).T + np.array([tr.x, tr.y, tr.z])
        self.pub_pts.publish(point_cloud2.create_cloud_xyz32(header, pts.astype(np.float32).tolist()))


def main():
    rclpy.init()
    node = RedZone()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
