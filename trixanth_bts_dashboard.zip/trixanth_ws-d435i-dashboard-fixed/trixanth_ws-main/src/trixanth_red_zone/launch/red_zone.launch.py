from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    cfg = PathJoinSubstitution([FindPackageShare("trixanth_red_zone"), "config", "red_zone.yaml"])
    sim = LaunchConfiguration("use_sim_time")
    return LaunchDescription([
        DeclareLaunchArgument("use_sim_time", default_value="false"),
        Node(package="trixanth_red_zone", executable="red_zone_node", name="red_zone",
             parameters=[cfg, {"use_sim_time": sim}], output="screen"),
    ])
