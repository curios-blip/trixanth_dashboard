# trixanth_red_zone

Red objects and areas are no-go zones; entering one costs 10% of the mission's points each time (rule 3.0). This package finds red in the colour image, back-projects it with depth, and puts it in both costmaps and the collision monitor as lethal obstacles.

## `red_zone_node`

| Direction | Topic | Type | Notes |
| --- | --- | --- | --- |
| Sub | `/camera/color/image_raw` | `Image` | |
| Sub | `/camera/aligned_depth_to_color/image_raw` | `Image` | Must be aligned to colour; 16UC1 mm or 32FC1 m |
| Sub | `/camera/color/camera_info` | `CameraInfo` | |
| Pub | `/red_zone/points` | `PointCloud2` in `base_footprint` | Empty cloud when nothing is red |
| Pub | `/red_zone/mask` | `Image` mono8 | For tuning and the dashboard |
| Pub | `/red_zone/visible` | `Bool` | Dashboard warning, also useful in teleop |

## Parameters (`config/red_zone.yaml`)

| Parameter | Default | Meaning |
| --- | --- | --- |
| `hue_low`, `hue_high` | 10, 165 | Red = hue 0..`hue_low` or `hue_high`..180 (OpenCV scale) |
| `s_min` | 110 | Raise if sand or brown rock triggers |
| `v_min` | 60 | |
| `min_area_px` | 150 | Ignore small specks |
| `stride` | 4 | Back-project every Nth pixel |
| `max_range` | 8.0 | m |

Segmentation is in `segmentation.py` (no ROS imports).

## Launch

```bash
ros2 launch trixanth_red_zone red_zone.launch.py [use_sim_time:=true]
ros2 run rqt_image_view rqt_image_view /red_zone/mask
```

## Watch out

- **Midday sun** washes red toward orange and pink. Tune at morning, noon and afternoon (TESTING.md F4).
- **Delivery marker colours** are announced before the finals. If one is red-ish or orange, narrow the hue range and test, or the rover will refuse to approach its own target.
- Red zones are never cleared from the costmap during a run. A false positive stays until the rover drives away from it (the costmaps are rolling).
- This guards autonomy. In teleop, the dashboard should alarm on `/red_zone/visible`.

## Test

```bash
colcon test --packages-select trixanth_red_zone
```

In sim: TESTING.md S5 (two cones, a red rock and a flat red patch with no collision, so only this node can avoid it).
