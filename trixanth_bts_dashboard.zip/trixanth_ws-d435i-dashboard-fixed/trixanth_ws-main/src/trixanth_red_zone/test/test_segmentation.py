import numpy as np

from trixanth_red_zone.segmentation import deproject, depth_to_metres, red_mask


def sand_image():
    img = np.zeros((240, 320, 3), np.uint8)
    img[:] = (90, 160, 200)  # BGR sandy colour
    return img


def test_sand_not_red():
    assert not red_mask(sand_image()).any()


def test_red_cone_detected():
    img = sand_image()
    img[100:160, 140:180] = (20, 20, 210)  # BGR red patch
    assert red_mask(img)[130, 160] == 255


def test_small_speck_ignored():
    img = sand_image()
    img[10:14, 10:14] = (20, 20, 210)
    assert not red_mask(img, min_area_px=150).any()


def test_deproject_centre_pixel():
    mask = np.zeros((240, 320), np.uint8)
    mask[120, 160] = 255
    depth = depth_to_metres(np.full((240, 320), 2000, np.uint16))
    pts = deproject(mask, depth, fx=300, fy=300, cx=160, cy=120, stride=1)
    assert pts.shape == (1, 3)
    assert np.allclose(pts[0], [0.0, 0.0, 2.0])
