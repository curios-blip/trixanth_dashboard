import json

import numpy as np

from trixanth_science.abex_report import build
from trixanth_science.pano_annotate import annotate, compass_heading, crop_to_ratio


def test_compass_heading():
    assert compass_heading(0.0) == 90.0            # facing east
    assert abs(compass_heading(np.pi / 2)) < 1e-9  # facing north


def test_crop_gives_at_least_1_to_3():
    img = np.full((400, 900, 3), 128, np.uint8)
    out = crop_to_ratio(img, 3.0)
    h, w = out.shape[:2]
    assert w / h >= 3.0


def test_annotate_adds_strip_and_footer():
    pano = np.full((200, 900, 3), 100, np.uint8)
    out = annotate(pano, [100, 60, 20, 340], ["line 1", "line 2"], px_per_m=150)
    assert out.shape[0] > 200 and out.shape[1] == 900


def test_report_builds(tmp_path):
    site = {"site": 1, "gps": {"latitude": 12.6, "longitude": 77.4, "elevation_m": 900, "h_accuracy_m": 1.5},
            "readings": [{"time": "10:00:00", "ph": 7.1, "soil_temp_c": 25.0}], "closeups": []}
    (tmp_path / "site_1.json").write_text(json.dumps(site))
    out = build(str(tmp_path), "", {"team": "T"}, str(tmp_path / "r.html"))
    text = open(out).read()
    assert "Site 1" in text and "7.1" in text
