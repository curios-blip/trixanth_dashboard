from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    sim = LaunchConfiguration("use_sim_time")
    return LaunchDescription([
        DeclareLaunchArgument("use_sim_time", default_value="false"),
        DeclareLaunchArgument("closeup_topic", default_value="/camera/color/image_raw"),
        Node(package="trixanth_science", executable="site_logger", output="screen",
             parameters=[{"use_sim_time": sim, "closeup_topic": LaunchConfiguration("closeup_topic")}]),
        Node(package="trixanth_science", executable="panorama", output="screen",
             parameters=[{"use_sim_time": sim}]),
    ])
