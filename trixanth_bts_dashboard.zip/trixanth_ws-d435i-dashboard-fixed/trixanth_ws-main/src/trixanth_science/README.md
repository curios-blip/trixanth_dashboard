# trixanth_science

ABEx tools (rule 3.2): per-site sensor logs, annotated panoramas, close-ups, and the mission report due 30 minutes after the mission.

## `site_logger`

| Service | Does |
| --- | --- |
| `/abex/new_site` | Start site N+1 and store the current GPS |
| `/abex/record` | Snapshot the latest soil temp, moisture, pH, air temp, humidity, pressure |
| `/abex/closeup` | Save a close-up photo with a scale note burned in |

Subscribes to the `/abex/*` topics from `sensor_bridge` and `/gps/fix`. Writes `~/trixanth_logs/abex/<session>/site_<N>.json` and images. Parameters: `closeup_topic` (point it at the arm or close-up camera), `closeup_scale_note` (describe the reference object in frame).

## `panorama`

1. Call `/abex/pano_start`.
2. Rotate the rover (or camera mast) slowly in place, 90–180°.
3. Call `/abex/pano_stop`.

A frame is kept every `step_deg` (12°) of heading. The result is stitched with OpenCV, cropped to at least 1:3 height:width, and annotated with N/E/S/W labels, a 1 m scale bar for objects at `scale_distance_m` (3 m), GPS, elevation, accuracy and time. Saved to `~/trixanth_logs/abex/panoramas/`. Cardinal labels are interpolated from the rover heading, so they are approximate; the report says so.

If stitching fails, turn slower so frames overlap by about a third.

## `abex_report`

Runs without ROS, so it also works on the base-station laptop:

```bash
ros2 run trixanth_science abex_report --session ~/trixanth_logs/abex/<session> \
    --pano-dir ~/trixanth_logs/abex/panoramas --out report.html
```

Open `report.html` in a browser and print to PDF (digital copy) and paper (hard copy). Sections follow the rulebook: on-board test results per site, sampling method (≥ 10 cm, sealed), site selection and documentation, habitability interpretation, then images (which don't count toward the 5-page limit).

**Science team:** write the fixed text before the finals in `config/abex_prewritten.yaml`. After the mission only data and pictures are added, so the report is ready well inside 30 minutes.

## Launch

```bash
ros2 launch trixanth_science science.launch.py [closeup_topic:=/arm_camera/image_raw]
```

## Test

```bash
colcon test --packages-select trixanth_science    # compass heading, 1:3 crop, annotation, report build
```
