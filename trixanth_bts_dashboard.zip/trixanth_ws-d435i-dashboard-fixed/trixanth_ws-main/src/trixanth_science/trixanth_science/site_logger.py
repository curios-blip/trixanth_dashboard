"""ABEx site documentation: one JSON per site with sensor readings, GPS and photos.

Services  /abex/new_site     (std_srvs/Trigger)  start site N+1 (call when the rover arrives at a site)
          /abex/record       (std_srvs/Trigger)  snapshot all latest sensor values into the current site
          /abex/closeup      (std_srvs/Trigger)  save a close-up photo of the sampling spot with a scale note
Output    <output_dir>/<session>/site_<N>.json and images; read by abex_report.
"""
import json
import math
import os
import time

import cv2
import rclpy
from cv_bridge import CvBridge
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import FluidPressure, Image, NavSatFix, RelativeHumidity, Temperature
from std_msgs.msg import Float32
from std_srvs.srv import Trigger


class SiteLogger(Node):
    def __init__(self):
        super().__init__("site_logger")
        self.declare_parameter("output_dir", os.path.expanduser("~/trixanth_logs/abex"))
        self.declare_parameter("closeup_topic", "/camera/color/image_raw")   # point at the arm/close-up camera
        self.declare_parameter("closeup_scale_note", "Scale: sampling scoop width 5 cm (visible in frame)")
        self.dir = os.path.join(self.get_parameter("output_dir").value, time.strftime("%Y%m%d_%H%M%S"))
        os.makedirs(self.dir, exist_ok=True)
        self.bridge = CvBridge()
        self.latest = {}
        self.fix = None
        self.frame = None
        self.site = 0
        self.data = None

        self.create_subscription(NavSatFix, "gps/fix", lambda m: setattr(self, "fix", m), 10)
        self.create_subscription(Image, self.get_parameter("closeup_topic").value,
                                 lambda m: setattr(self, "frame", m), qos_profile_sensor_data)
        self.create_subscription(Temperature, "abex/soil_temperature", lambda m: self.put("soil_temp_c", m.temperature), 10)
        self.create_subscription(Temperature, "abex/air_temperature", lambda m: self.put("air_temp_c", m.temperature), 10)
        self.create_subscription(RelativeHumidity, "abex/humidity",
                                 lambda m: self.put("humidity_pct", m.relative_humidity * 100.0), 10)
        self.create_subscription(FluidPressure, "abex/pressure", lambda m: self.put("pressure_pa", m.fluid_pressure), 10)
        self.create_subscription(Float32, "abex/ph", lambda m: self.put("ph", m.data), 10)
        self.create_subscription(Float32, "abex/soil_moisture", lambda m: self.put("soil_moisture_pct", m.data), 10)
        self.create_service(Trigger, "abex/new_site", self.on_new_site)
        self.create_service(Trigger, "abex/record", self.on_record)
        self.create_service(Trigger, "abex/closeup", self.on_closeup)
        self.get_logger().info(f"ABEx logs in {self.dir}")

    def put(self, key, value):
        self.latest[key] = float(value)

    def gps(self):
        if self.fix is None:
            return None
        cov = self.fix.position_covariance
        acc = math.sqrt(max(cov[0], cov[4], 0.0)) if self.fix.position_covariance_type else None
        return {"latitude": self.fix.latitude, "longitude": self.fix.longitude,
                "elevation_m": self.fix.altitude, "h_accuracy_m": acc}

    def save(self):
        with open(os.path.join(self.dir, f"site_{self.site}.json"), "w") as f:
            json.dump(self.data, f, indent=2)

    def on_new_site(self, _req, res):
        self.site += 1
        self.data = {"site": self.site, "started": time.strftime("%H:%M:%S"), "gps": self.gps(),
                     "readings": [], "closeups": [], "panorama": None}
        self.save()
        res.success, res.message = True, f"site {self.site}"
        return res

    def on_record(self, _req, res):
        if self.data is None:
            res.success, res.message = False, "call /abex/new_site first"
            return res
        self.data["readings"].append({"time": time.strftime("%H:%M:%S"), "gps": self.gps(), **self.latest})
        self.save()
        res.success, res.message = True, json.dumps(self.latest)
        return res

    def on_closeup(self, _req, res):
        if self.data is None or self.frame is None:
            res.success, res.message = False, "no site or no image"
            return res
        img = self.bridge.imgmsg_to_cv2(self.frame, "bgr8").copy()
        note = self.get_parameter("closeup_scale_note").value
        cv2.rectangle(img, (0, img.shape[0] - 36), (img.shape[1], img.shape[0]), (0, 0, 0), -1)
        cv2.putText(img, note, (10, img.shape[0] - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        name = f"site_{self.site}_closeup_{len(self.data['closeups']) + 1}.jpg"
        cv2.imwrite(os.path.join(self.dir, name), img)
        self.data["closeups"].append(name)
        self.save()
        res.success, res.message = True, name
        return res


def main():
    rclpy.init()
    node = SiteLogger()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
