"""Panorama stitching and annotation (no ROS imports, unit-testable).

Rule 3.2: wide-angle panorama, height:width at least 1:3, with cardinal directions, scale, GPS,
elevation and accuracy.
"""
import cv2
import numpy as np


def compass_heading(enu_yaw_rad):
    """ENU yaw (0 = east, CCW) -> compass heading in degrees (0 = north, CW)."""
    return (90.0 - np.degrees(enu_yaw_rad)) % 360.0


def stitch(frames):
    if len(frames) < 2:
        return None
    st = cv2.Stitcher_create(cv2.Stitcher_PANORAMA)
    status, pano = st.stitch(frames)
    return pano if status == cv2.Stitcher_OK else None


def crop_to_ratio(img, min_ratio=3.0):
    """Trim black borders, then cut height so width/height >= min_ratio."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ys, xs = np.nonzero(gray > 0)
    if len(xs):
        img = img[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    h, w = img.shape[:2]
    if w / h < min_ratio:
        new_h = int(w / min_ratio)
        top = (h - new_h) // 2
        img = img[top:top + new_h]
    return img


def annotate(pano, headings_deg, info_lines, px_per_m=None, scale_note=""):
    """Add a compass strip on top and an info box + scale bar at the bottom.

    headings_deg: compass heading of each source frame, in capture order (left to right in the panorama).
    Positions in between are linearly interpolated, so the labels are approximate.
    """
    h, w = pano.shape[:2]
    strip, footer = 40, 26 * (len(info_lines) + 1) + 10
    out = np.zeros((h + strip + footer, w, 3), np.uint8)
    out[strip:strip + h] = pano

    hd = np.unwrap(np.radians(headings_deg))
    xs = np.linspace(w * 0.08, w * 0.92, len(hd))
    for name, target in (("N", 0), ("E", 90), ("S", 180), ("W", 270)):
        t = np.radians(target)
        for k in (-2, -1, 0, 1, 2):
            tt = t + 2 * np.pi * k
            if hd.min() <= tt <= hd.max() or hd.max() <= tt <= hd.min():
                x = int(np.interp(tt, hd, xs) if hd[-1] > hd[0] else np.interp(tt, hd[::-1], xs[::-1]))
                cv2.line(out, (x, strip - 10), (x, strip + 20), (0, 255, 255), 2)
                cv2.putText(out, name, (x - 9, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 255), 2)

    y = strip + h + 26
    for line in info_lines:
        cv2.putText(out, line, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        y += 26
    if px_per_m:
        bar = int(px_per_m)
        x0, y0 = w - bar - 30, strip + h + 30
        cv2.rectangle(out, (x0, y0), (x0 + bar, y0 + 8), (255, 255, 255), -1)
        cv2.putText(out, f"1 m {scale_note}", (x0, y0 + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)
    return out
