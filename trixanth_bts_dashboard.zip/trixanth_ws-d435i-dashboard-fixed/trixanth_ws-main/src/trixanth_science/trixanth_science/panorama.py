"""Capture an annotated panorama at an ABEx site.

  /abex/pano_start (Trigger)  start; then rotate the rover (or camera mast) slowly in place, ~90-180 deg
  /abex/pano_stop  (Trigger)  stitch, crop to >= 1:3, annotate, save to the site folder

A frame is kept every `step_deg` of heading change (from /odometry/global yaw).
Scale bar: 1 m drawn for objects at `scale_distance_m` from the camera (fx / distance px per metre).
"""
import math
import os
import time

import cv2
import rclpy
from cv_bridge import CvBridge
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CameraInfo, Image, NavSatFix
from std_srvs.srv import Trigger

from trixanth_science.pano_annotate import annotate, compass_heading, crop_to_ratio, stitch


class Panorama(Node):
    def __init__(self):
        super().__init__("panorama")
        self.declare_parameter("output_dir", os.path.expanduser("~/trixanth_logs/abex/panoramas"))
        self.declare_parameter("image_topic", "/camera/color/image_raw")
        self.declare_parameter("info_topic", "/camera/color/camera_info")
        self.declare_parameter("step_deg", 12.0)
        self.declare_parameter("scale_distance_m", 3.0)
        self.declare_parameter("site_name", "site")
        self.out = self.get_parameter("output_dir").value
        os.makedirs(self.out, exist_ok=True)

        self.bridge = CvBridge()
        self.capturing = False
        self.frames, self.headings = [], []
        self.yaw = None
        self.last_yaw = None
        self.fix = None
        self.fx = None
        self.create_subscription(Image, self.get_parameter("image_topic").value, self.on_image, qos_profile_sensor_data)
        self.create_subscription(CameraInfo, self.get_parameter("info_topic").value,
                                 lambda m: setattr(self, "fx", m.k[0]), qos_profile_sensor_data)
        self.create_subscription(Odometry, "odometry/global", self.on_odom, 10)
        self.create_subscription(NavSatFix, "gps/fix", lambda m: setattr(self, "fix", m), 10)
        self.create_service(Trigger, "abex/pano_start", self.on_start)
        self.create_service(Trigger, "abex/pano_stop", self.on_stop)

    def on_odom(self, m):
        q = m.pose.pose.orientation
        self.yaw = math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))

    def on_image(self, msg):
        if not self.capturing or self.yaw is None:
            return
        step = math.radians(self.get_parameter("step_deg").value)
        if self.last_yaw is not None:
            d = math.atan2(math.sin(self.yaw - self.last_yaw), math.cos(self.yaw - self.last_yaw))
            if abs(d) < step:
                return
        self.frames.append(self.bridge.imgmsg_to_cv2(msg, "bgr8"))
        self.headings.append(compass_heading(self.yaw))
        self.last_yaw = self.yaw
        self.get_logger().info(f"Frame {len(self.frames)} at heading {self.headings[-1]:.0f} deg")

    def on_start(self, _req, res):
        self.frames, self.headings, self.last_yaw = [], [], None
        self.capturing = True
        res.success, res.message = True, "capturing: rotate slowly"
        return res

    def on_stop(self, _req, res):
        self.capturing = False
        # Rotating left (CCW) moves the view right-to-left; stitched output is left-to-right, so reverse.
        frames, heads = self.frames[::-1], self.headings[::-1]
        pano = stitch(frames)
        if pano is None:
            res.success, res.message = False, f"stitch failed with {len(frames)} frames (need overlap, slower turn)"
            return res
        pano = crop_to_ratio(pano, 3.0)
        lines = [f"{self.get_parameter('site_name').value}  {time.strftime('%Y-%m-%d %H:%M:%S')}"]
        if self.fix:
            cov = self.fix.position_covariance
            acc = math.sqrt(max(cov[0], cov[4], 0.0))
            lines.append(f"GPS {self.fix.latitude:.7f}, {self.fix.longitude:.7f} (WGS 84)  "
                         f"elev {self.fix.altitude:.1f} m  accuracy +/-{acc:.1f} m")
        lines.append("Cardinal labels interpolated from rover heading (approx.)")
        d = self.get_parameter("scale_distance_m").value
        ppm = self.fx / d if self.fx else None
        img = annotate(pano, heads, lines, px_per_m=ppm, scale_note=f"at {d:.0f} m range")
        name = os.path.join(self.out, f"pano_{time.strftime('%H%M%S')}.jpg")
        cv2.imwrite(name, img)
        h, w = pano.shape[:2]
        res.success, res.message = True, f"{name} ({w}x{h}, ratio 1:{w / h:.1f})"
        return res


def main():
    rclpy.init()
    node = Panorama()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
