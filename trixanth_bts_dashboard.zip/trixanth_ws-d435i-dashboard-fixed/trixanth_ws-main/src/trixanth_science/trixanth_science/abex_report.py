"""Build the ABEx mission report (rule 3.2: max 5 pages excluding pictures, due 30 min after the mission).

The science team writes the fixed text before the finals in config/abex_prewritten.yaml.
After the mission, run:
  ros2 run trixanth_science abex_report --session ~/trixanth_logs/abex/<session> \
      --pano-dir ~/trixanth_logs/abex/panoramas --out report.html
Open report.html in a browser and print to PDF (digital copy) and paper (hard copy).
Runs without ROS, so it also works on the base-station laptop after copying the log folder.
"""
import argparse
import glob
import html
import json
import os

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))

CSS = """
body{font-family:Arial,Helvetica,sans-serif;font-size:11pt;margin:18mm;color:#111}
h1{font-size:18pt;margin:0 0 4px}h2{font-size:13pt;border-bottom:1px solid #999;margin-top:18px}
table{border-collapse:collapse;width:100%;font-size:10pt}td,th{border:1px solid #aaa;padding:3px 6px;text-align:left}
img{max-width:100%;margin:6px 0;page-break-inside:avoid}.muted{color:#555;font-size:9pt}
@media print{.pics{page-break-before:always}}
"""

FIELDS = [("soil_temp_c", "Soil temp (C)"), ("soil_moisture_pct", "Soil moisture (%)"), ("ph", "pH"),
          ("air_temp_c", "Air temp (C)"), ("humidity_pct", "Humidity (%)"), ("pressure_pa", "Pressure (Pa)")]


def esc(s):
    return html.escape(str(s)) if s is not None else ""


def load_prewritten(path):
    if path and os.path.exists(path):
        with open(path) as f:
            return yaml.safe_load(f) or {}
    return {}


def site_table(site):
    rows = []
    for r in site.get("readings", []):
        cells = "".join(f"<td>{esc(round(r[k], 2)) if k in r else ''}</td>" for k, _ in FIELDS)
        rows.append(f"<tr><td>{esc(r.get('time'))}</td>{cells}</tr>")
    head = "".join(f"<th>{esc(n)}</th>" for _, n in FIELDS)
    return f"<table><tr><th>Time</th>{head}</tr>{''.join(rows)}</table>" if rows else "<p>No readings recorded.</p>"


def build(session, pano_dir, pre, out):
    sites = []
    for p in sorted(glob.glob(os.path.join(session, "site_*.json"))):
        with open(p) as f:
            sites.append(json.load(f))
    panos = sorted(glob.glob(os.path.join(pano_dir, "*.jpg"))) if pano_dir else []

    parts = [f"<html><head><meta charset='utf-8'><title>ABEx Mission Report</title><style>{CSS}</style></head><body>",
             f"<h1>ABEx Mission Report: {esc(pre.get('team', 'Team Trixanth'))}</h1>",
             f"<p class='muted'>Round: {esc(pre.get('round', ''))} | Sites investigated: {len(sites)}</p>",
             "<h2>1. Results of on-board tests</h2>"]
    for s in sites:
        g = s.get("gps") or {}
        parts.append(f"<h3>Site {s['site']}</h3><p class='muted'>GPS {esc(g.get('latitude'))}, "
                     f"{esc(g.get('longitude'))} | elevation {esc(g.get('elevation_m'))} m | "
                     f"accuracy +/-{esc(g.get('h_accuracy_m'))} m</p>")
        parts.append(site_table(s))
        notes = pre.get("site_notes", {}).get(s["site"], "")
        if notes:
            parts.append(f"<p>{esc(notes)}</p>")
    parts.append(f"<p><b>Life-detection instrument:</b> {esc(pre.get('life_detection', ''))}</p>")
    parts.append(f"<h2>2. Sample collection (depth at least 10 cm, sealed, uncontaminated)</h2><p>{esc(pre.get('sampling_method', ''))}</p>")
    parts.append(f"<h2>3. Site selection and documentation</h2><p>{esc(pre.get('site_selection', ''))}</p>")
    parts.append(f"<h2>4. Habitability, geology and implications for life</h2><p>{esc(pre.get('interpretation', ''))}</p>")
    parts.append("<div class='pics'><h2>Images (not counted in the 5-page limit)</h2>")
    for p in panos:
        parts.append(f"<img src='{esc(os.path.abspath(p))}'><p class='muted'>{esc(os.path.basename(p))}</p>")
    for s in sites:
        for c in s.get("closeups", []):
            parts.append(f"<img src='{esc(os.path.abspath(os.path.join(session, c)))}'><p class='muted'>Site {s['site']} close-up</p>")
    parts.append("</div></body></html>")
    with open(out, "w") as f:
        f.write("\n".join(parts))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--session", required=True, help="folder with site_*.json from site_logger")
    ap.add_argument("--pano-dir", default="")
    ap.add_argument("--prewritten", default=os.path.join(HERE, "..", "config", "abex_prewritten.yaml"))
    ap.add_argument("--out", default="abex_report.html")
    args, _ = ap.parse_known_args()
    pre_path = args.prewritten
    if not os.path.exists(pre_path):
        try:
            from ament_index_python.packages import get_package_share_directory
            pre_path = os.path.join(get_package_share_directory("trixanth_science"), "config", "abex_prewritten.yaml")
        except Exception:
            pass
    print(build(args.session, args.pano_dir, load_prewritten(pre_path), args.out))


if __name__ == "__main__":
    main()
