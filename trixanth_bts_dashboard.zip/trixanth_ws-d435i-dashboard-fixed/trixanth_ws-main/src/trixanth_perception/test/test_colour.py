import numpy as np

from trixanth_perception.colour import PRESETS, largest_blob


def test_blue_marker_found_at_right_place():
    img = np.zeros((240, 320, 3), np.uint8)
    img[:] = (90, 160, 200)
    img[50:90, 200:240] = (200, 60, 20)  # BGR blue
    blob = largest_blob(img, PRESETS["blue"])
    assert blob is not None
    cx, cy, area, _ = blob
    assert abs(cx - 219.5) < 2 and abs(cy - 69.5) < 2 and area > 1000


def test_no_marker_on_sand():
    img = np.zeros((240, 320, 3), np.uint8)
    img[:] = (90, 160, 200)
    assert largest_blob(img, PRESETS["blue"]) is None
