"""Colour blob finding for delivery markers. No ROS imports (unit-testable)."""
import cv2
import numpy as np

# OpenCV HSV (H 0..180). Starting points only: re-tune with the official marker colours once released.
PRESETS = {
    "blue":   [((100, 120, 60), (130, 255, 255))],
    "green":  [((40, 80, 50), (85, 255, 255))],
    "yellow": [((20, 120, 100), (35, 255, 255))],
    "orange": [((10, 150, 120), (20, 255, 255))],
    "white":  [((0, 0, 200), (180, 40, 255))],
}


def largest_blob(bgr, ranges, min_area_px=200):
    """Return (cx, cy, area_px, mask) of the largest blob within any of the HSV ranges, or None."""
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    mask = np.zeros(hsv.shape[:2], np.uint8)
    for lo, hi in ranges:
        mask |= cv2.inRange(hsv, lo, hi)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k)
    n, labels, stats, cents = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if n <= 1:
        return None
    i = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    area = int(stats[i, cv2.CC_STAT_AREA])
    if area < min_area_px:
        return None
    return float(cents[i][0]), float(cents[i][1]), area, (labels == i)


def median_depth(depth_m, region_mask):
    vals = depth_m[region_mask]
    vals = vals[np.isfinite(vals) & (vals > 0.2)]
    return float(np.median(vals)) if vals.size else float("nan")
