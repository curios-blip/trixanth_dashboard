"""YOLOv8n object detector for RADO objects (tools, containers, rocks).

Subscribes  /camera/color/image_raw, optional aligned depth + camera_info for 3D position
Publishes   /perception/detections (trixanth_interfaces/DetectionArray)
            /perception/annotated  (sensor_msgs/Image) when publish_annotated is true

Model: start from a model fine-tuned on generic tool/container/rock classes; retrain on the official
object photos the week they are released (see TESTING.md, perception section).
On the Orin Nano export to TensorRT for speed:  yolo export model=best.pt format=engine half=True
"""
import math

import numpy as np
import rclpy
from cv_bridge import CvBridge
from geometry_msgs.msg import Point
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CameraInfo, Image

from trixanth_interfaces.msg import Detection, DetectionArray
from trixanth_perception.colour import median_depth


class ObjectDetector(Node):
    def __init__(self):
        super().__init__("object_detector")
        self.declare_parameter("model", "yolov8n.pt")        # path to .pt or .engine
        self.declare_parameter("confidence", 0.45)
        self.declare_parameter("image_size", 640)
        self.declare_parameter("device", "0")                # "0" = first CUDA GPU, "cpu" for laptops
        self.declare_parameter("max_rate_hz", 10.0)
        self.declare_parameter("color_topic", "/camera/color/image_raw")
        self.declare_parameter("depth_topic", "/camera/aligned_depth_to_color/image_raw")
        self.declare_parameter("info_topic", "/camera/color/camera_info")
        self.declare_parameter("use_depth", True)
        self.declare_parameter("publish_annotated", True)

        g = lambda n: self.get_parameter(n).value  # noqa: E731
        self.conf, self.imgsz, self.device = g("confidence"), g("image_size"), g("device")
        self.min_period = 1.0 / max(g("max_rate_hz"), 0.1)
        self.publish_annotated = g("publish_annotated")
        self.bridge = CvBridge()
        self.last_t = 0.0
        self.depth = None
        self.info = None

        try:
            from ultralytics import YOLO
            self.model = YOLO(g("model"))
            self.get_logger().info(f"Loaded {g('model')}")
        except Exception as e:  # missing package or model file
            self.model = None
            self.get_logger().error(f"YOLO unavailable ({e}). pip install ultralytics; check model path.")

        self.pub = self.create_publisher(DetectionArray, "perception/detections", 10)
        self.pub_img = self.create_publisher(Image, "perception/annotated", 2)
        self.create_subscription(Image, g("color_topic"), self.on_image, qos_profile_sensor_data)
        if g("use_depth"):
            self.create_subscription(Image, g("depth_topic"), self.on_depth, qos_profile_sensor_data)
            self.create_subscription(CameraInfo, g("info_topic"), self.on_info, qos_profile_sensor_data)

    def on_depth(self, msg):
        d = self.bridge.imgmsg_to_cv2(msg, "passthrough")
        self.depth = d.astype(np.float32) / 1000.0 if d.dtype == np.uint16 else d.astype(np.float32)

    def on_info(self, msg):
        self.info = msg

    def on_image(self, msg: Image):
        if self.model is None:
            return
        now = self.get_clock().now().nanoseconds * 1e-9
        if now - self.last_t < self.min_period:
            return
        self.last_t = now

        bgr = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        res = self.model.predict(bgr, conf=self.conf, imgsz=self.imgsz, device=self.device, verbose=False)[0]
        out = DetectionArray()
        out.header = msg.header
        names = res.names
        for box in res.boxes:
            x1, y1, x2, y2 = (int(v) for v in box.xyxy[0].tolist())
            d = Detection()
            d.label = names[int(box.cls[0])]
            d.confidence = float(box.conf[0])
            d.x, d.y, d.w, d.h = x1, y1, x2 - x1, y2 - y1
            d.position = self.position(x1, y1, x2, y2)
            out.detections.append(d)
        self.pub.publish(out)

        if self.publish_annotated:
            img = self.bridge.cv2_to_imgmsg(res.plot(), "bgr8")
            img.header = msg.header
            self.pub_img.publish(img)

    def position(self, x1, y1, x2, y2):
        nan = Point(x=math.nan, y=math.nan, z=math.nan)
        if self.depth is None or self.info is None or self.depth.shape[:2][::-1] != (self.info.width, self.info.height):
            return nan
        # centre 50% of the box to avoid background pixels
        cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
        hw, hh = max(1, (x2 - x1) // 4), max(1, (y2 - y1) // 4)
        region = np.zeros(self.depth.shape[:2], bool)
        region[max(0, cy - hh):cy + hh, max(0, cx - hw):cx + hw] = True
        z = median_depth(self.depth, region)
        if not math.isfinite(z):
            return nan
        k = self.info.k
        return Point(x=(cx - k[2]) * z / k[0], y=(cy - k[5]) * z / k[4], z=z)


def main():
    rclpy.init()
    node = ObjectDetector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
