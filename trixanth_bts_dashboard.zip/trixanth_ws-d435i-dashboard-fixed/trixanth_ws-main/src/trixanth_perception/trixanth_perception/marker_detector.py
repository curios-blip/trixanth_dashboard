"""Finds the coloured delivery marker for the final-metres approach in RADO.

Subscribes  colour image, aligned depth (optional), camera_info
Publishes   /perception/marker (trixanth_interfaces/MarkerObservation)

Change the target colour at runtime (the FSM does this per delivery):
  ros2 param set /marker_detector colour blue
Or give custom HSV ranges with hsv_lo / hsv_hi (overrides the preset).
"""
import math

import numpy as np
import rclpy
from cv_bridge import CvBridge
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CameraInfo, Image

from trixanth_interfaces.msg import MarkerObservation
from trixanth_perception.colour import PRESETS, largest_blob, median_depth


class MarkerDetector(Node):
    def __init__(self):
        super().__init__("marker_detector")
        self.declare_parameter("colour", "blue")
        self.declare_parameter("hsv_lo", [0, 0, 0])
        self.declare_parameter("hsv_hi", [0, 0, 0])
        self.declare_parameter("min_area_px", 200)
        self.declare_parameter("color_topic", "/camera/color/image_raw")
        self.declare_parameter("depth_topic", "/camera/aligned_depth_to_color/image_raw")
        self.declare_parameter("info_topic", "/camera/color/camera_info")

        g = lambda n: self.get_parameter(n).value  # noqa: E731
        self.bridge = CvBridge()
        self.depth = None
        self.info = None
        self.pub = self.create_publisher(MarkerObservation, "perception/marker", 10)
        self.create_subscription(Image, g("color_topic"), self.on_image, qos_profile_sensor_data)
        self.create_subscription(Image, g("depth_topic"), self.on_depth, qos_profile_sensor_data)
        self.create_subscription(CameraInfo, g("info_topic"), self.on_info, qos_profile_sensor_data)

    def ranges(self):
        lo = list(self.get_parameter("hsv_lo").value)
        hi = list(self.get_parameter("hsv_hi").value)
        if any(hi):
            return [(tuple(lo), tuple(hi))]
        colour = self.get_parameter("colour").value
        if colour not in PRESETS:
            self.get_logger().error(f"Unknown colour '{colour}'. Presets: {list(PRESETS)}",
                                    throttle_duration_sec=5.0)
            return []
        return PRESETS[colour]

    def on_depth(self, msg):
        d = self.bridge.imgmsg_to_cv2(msg, "passthrough")
        self.depth = d.astype(np.float32) / 1000.0 if d.dtype == np.uint16 else d.astype(np.float32)

    def on_info(self, msg):
        self.info = msg

    def on_image(self, msg: Image):
        bgr = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        obs = MarkerObservation()
        obs.header = msg.header
        obs.colour = self.get_parameter("colour").value
        obs.range_m = math.nan
        ranges = self.ranges()
        blob = largest_blob(bgr, ranges, self.get_parameter("min_area_px").value) if ranges else None
        if blob is None:
            obs.visible = False
            self.pub.publish(obs)
            return
        cx, _, area, region = blob
        h, w = bgr.shape[:2]
        fx = self.info.k[0] if self.info else w / (2 * math.tan(0.6))   # fallback ~69 deg HFOV
        ppx = self.info.k[2] if self.info else w / 2
        obs.visible = True
        obs.bearing_rad = float(-math.atan2(cx - ppx, fx))   # image right = negative (REP 103)
        obs.area_ratio = area / float(w * h)
        if self.depth is not None and self.depth.shape[:2] == (h, w):
            obs.range_m = median_depth(self.depth, region)
        self.pub.publish(obs)


def main():
    rclpy.init()
    node = MarkerDetector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
