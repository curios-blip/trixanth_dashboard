# trixanth_perception

Object detection for RADO recon and the delivery-marker finder for the final approach.

## `object_detector` (YOLOv8n)

| Direction | Topic | Type |
| --- | --- | --- |
| Sub | `/camera/color/image_raw` | `Image` |
| Sub | `/camera/aligned_depth_to_color/image_raw`, `/camera/color/camera_info` | optional, for 3D position |
| Pub | `/perception/detections` | `trixanth_interfaces/DetectionArray` |
| Pub | `/perception/annotated` | `Image` with boxes |

| Parameter | Default | Meaning |
| --- | --- | --- |
| `model` | `yolov8n.pt` (config: `/home/trixanth/models/rado_yolov8n.engine`) | `.pt` or TensorRT `.engine` |
| `confidence` | 0.45 | |
| `device` | `"0"` | `"cpu"` on a laptop |
| `max_rate_hz` | 10 | Caps GPU load |
| `use_depth` | true | Position = median depth of the box centre |

If `ultralytics` or the model file is missing, the node logs an error and publishes nothing; the rest of the stack still runs.

**Model plan:** train now on generic tool, container and rock images on sand and gravel (300+ labelled images). Official object photos are released before the finals; retrain within 48 hours of release. On the Orin Nano export to TensorRT:

```bash
yolo export model=best.pt format=engine half=True
```

## `marker_detector`

| Direction | Topic | Type |
| --- | --- | --- |
| Sub | colour, aligned depth, camera_info | |
| Pub | `/perception/marker` | `trixanth_interfaces/MarkerObservation` |

Finds the largest blob of the target colour and reports bearing (+ left), area ratio and depth range. `rado_fsm` sets the colour per delivery:

```bash
ros2 param set /marker_detector colour green
```

Presets in `colour.py`: `blue`, `green`, `yellow`, `orange`, `white`. For a colour that isn't a preset, set `hsv_lo` and `hsv_hi` (OpenCV HSV, H 0–180). **Retune these once the official marker colours are released.**

## Launch

```bash
ros2 launch trixanth_perception perception.launch.py model:=/path/model.engine
ros2 launch trixanth_perception perception.launch.py detector:=false     # marker only
```

## Test

```bash
colcon test --packages-select trixanth_perception
ros2 topic hz /perception/detections     # ≥ 15 Hz target on the Orin Nano with Nav2 running (TESTING.md B7)
```
