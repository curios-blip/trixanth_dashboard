from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    cfg = PathJoinSubstitution([FindPackageShare("trixanth_perception"), "config", "perception.yaml"])
    sim = LaunchConfiguration("use_sim_time")
    return LaunchDescription([
        DeclareLaunchArgument("use_sim_time", default_value="false"),
        DeclareLaunchArgument("detector", default_value="true"),
        DeclareLaunchArgument("model", default_value="/home/trixanth/models/rado_yolov8n.engine"),
        DeclareLaunchArgument("device", default_value="0"),
        Node(package="trixanth_perception", executable="object_detector", name="object_detector",
             parameters=[cfg, {"use_sim_time": sim, "model": LaunchConfiguration("model"),
                               "device": LaunchConfiguration("device")}],
             condition=IfCondition(LaunchConfiguration("detector")), output="screen"),
        Node(package="trixanth_perception", executable="marker_detector", name="marker_detector",
             parameters=[cfg, {"use_sim_time": sim}], output="screen"),
    ])
