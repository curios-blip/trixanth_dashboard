# Connections

What plugs into what on Trixanth, and why. Parts marked **(assumed)** are placeholders; swap the part and update the matching config file listed in the last column.

## Overview

```
                               ROVER                                              BASE STATION (within 3 m)
 ┌──────────────────────────────────────────────────────────────────┐
 │  BATTERY ──► EXTERNAL KILL SWITCH ──► MAIN FUSE ──► DISTRIBUTION  │
 │  (rule 2.2: cuts ALL power, outside, visible)        │            │
 │                     ┌──────────────┬───────────────┬─┴──────────┐ │
 │                     ▼              ▼               ▼            ▼ │
 │             MOTOR CONTACTOR   DC-DC for Jetson  DC-DC 12V   DC-DC for radio
 │                     │              │            (arm, misc)  (or passive PoE)
 │                     ▼              ▼                            │ │
 │             MOTOR DRIVERS ◄─PWM/DIR─ TEENSY 4.1 ◄─USB─┐          │ │
 │             (L side, R side)   │  ▲  BNO085 IMU (I2C) │          │ │
 │                     │          │  └─ encoders (L, R)  │          │ │
 │                     ▼          └─ contactor sense     │          │ │
 │              6 WHEEL MOTORS                     JETSON ORIN NANO   │ │      ┌────────────┐   ┌─────────┐
 │                                                 │  │  │  │  │    │ │      │ BASE RADIO │   │ LAPTOP  │
 │       ESP32 science node ──USB──────────────────┘  │  │  │  │    │ │      │ on mast    │──►│ dashboard│
 │       (soil temp, pH, BME280, moisture)            │  │  │  │    │ │      │ ≤ 3 m high │PoE│ rosbridge│
 │       GPS receiver ──USB───────────────────────────┘  │  │  │    │ │      └─────▲──────┘   └─────────┘
 │       RealSense D435i ──USB 3────────────────────────┘  │  │    │ │            │
 │       Rover radio ──Ethernet─────────────────────────────┘  │    │ │      5.8 GHz link
 │       Arm controller (manipulation team) ──USB/CAN──────────┘    │ │            │
 │                                                                  ◄──────────────┘
 └──────────────────────────────────────────────────────────────────┘
```

## Power

| From | To | Notes |
| --- | --- | --- |
| Battery + | External kill switch | Rated for full motor current (stall current of all 6 motors). Mounted outside, red, reachable by runners (rule 2.2). |
| Kill switch | Main fuse, then distribution bus | Everything downstream dies when the switch is hit, including the Jetson. That is what the rule asks for. |
| Bus | Motor contactor (relay) → motor drivers | A second, motor-only stop. Lets you cut wheels while keeping the Jetson logging. Its auxiliary NC contact goes to Teensy pin 10. |
| Bus | DC-DC → Jetson Orin Nano | Match your carrier board's input (the dev kit barrel jack takes 19 V). Use an isolated, ≥ 60 W converter; motor surges brown out cheap ones. |
| Bus | DC-DC 12 V → arm, fans, lights | Keep the arm on its own converter. |
| Bus | Rover radio | Passive PoE injector or DC-DC to the radio's spec **(assumed 24 V passive PoE)**. |
| Jetson USB | Teensy, ESP32 | Both powered over USB. Do **not** also feed 5 V to the Teensy VIN unless you cut its VIN/VUSB pad. |

Grounds: Teensy GND, motor-driver logic GND and Jetson GND must be common, or PWM/DIR signals float.

## Jetson Orin Nano ports

| Port | Device | Linux name (udev) | Config |
| --- | --- | --- | --- |
| USB 3 (blue) | Intel RealSense D435i **(assumed)** | handled by librealsense | `trixanth_bringup/launch/robot.launch.py` |
| USB 2 | Teensy 4.1 | `/dev/trixanth_teensy` | `trixanth_hardware/config/hardware.yaml` |
| USB 2 | ESP32 science node | `/dev/trixanth_esp32_science` | same |
| USB 2 | GPS, u-blox **(assumed)** | `/dev/trixanth_gps` | `trixanth_hardware/launch/hardware.launch.py` |
| Ethernet | Rover radio | `eth0`, static IP | see network below |

Install the udev rules from `src/trixanth_hardware/udev/99-trixanth.rules` first (instructions inside the file). Put the RealSense on its own USB 3 port, not a hub; it drops frames on a shared hub.

## Teensy 4.1 pins (matches `firmware/teensy_base/teensy_base.ino`)

| Pin | Connects to | Notes |
| --- | --- | --- |
| 2 | Left driver PWM | 20 kHz |
| 3 | Left driver DIR | |
| 4 | Right driver PWM | |
| 5 | Right driver DIR | |
| 6, 7 | Left encoder A, B | 3.3 V logic only. Use a level shifter if the encoder is 5 V. |
| 8, 9 | Right encoder A, B | Right side is mirrored in firmware |
| 10 | Motor contactor aux NC contact (other side to GND) | Internal pull-up; HIGH = motor bus off |
| 18 (SDA), 19 (SCL) | BNO085 IMU **(assumed)** | Mount near the rover centre, away from motors and power cables |
| A0 (14) | Battery voltage divider | 100 k / 10 k gives 11:1; keep the pin under 3.3 V at full charge |
| USB | Jetson | Serial at 115200 |

**Assumption:** three motors per side share one command. If each motor has its own driver channel, wire all three PWM/DIR inputs per side together or extend the firmware.

## ESP32 science node pins (matches `firmware/esp32_science/esp32_science.ino`)

| GPIO | Sensor | Notes |
| --- | --- | --- |
| 4 | DS18B20 soil temperature probe | 4.7 k pull-up to 3.3 V |
| 21 (SDA), 22 (SCL) | BME280: air temperature, humidity, pressure | Address 0x76 or 0x77 |
| 34 | pH probe analog board | ADC1 only; calibrate in pH 4 and 7 buffers |
| 35 | Capacitive soil moisture | Calibrate dry and wet values |
| USB | Jetson | Wi-Fi and Bluetooth are turned off in firmware (no extra RF in the arena) |

## Network and radio

| Device | IP | Notes |
| --- | --- | --- |
| Base laptop | 192.168.10.10 | Runs the dashboard |
| Base radio | 192.168.10.21 | On a mast ≤ 3 m high, within 3 m of the command station, no camera on it (rule 2.3) |
| Rover radio | 192.168.10.20 | **(assumed)** 5.8 GHz bridge pair |
| Rover Jetson | 192.168.10.2 | |

- **Only rosbridge (one WebSocket, port 9090) crosses the radio.** Set `export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST` on the Jetson so DDS discovery traffic never floods the link. The dashboard talks to the rover only through rosbridge.
- The dashboard page publishes `/ground/heartbeat` (`std_msgs/Header`, 5 Hz) through rosbridge while it is open (not in demo mode). That is what `link_monitor` uses to decide the link is up.
- Radio settings to lock **before Dec 5** (they go in the communications declaration): band, channel list, channel width, encryption (WPA2/AES at minimum), and how auto channel selection is limited to the declared channels. Operating outside the declaration means immediate disqualification.
- The radio must stay **off** until the field judge gives permission. Power it from a separate switch on the base side, not from the laptop's boot.

## Topics between packages

```
 teleop (dashboard) ──/cmd_vel_teleop──►┐
                                        │
 Nav2 ──/cmd_vel_nav──► velocity_smoother ──/cmd_vel_smoothed──► collision_monitor ──/cmd_vel_auto──►│
 rado_fsm (search/approach/backoff) ──────────────────────────────────────────────/cmd_vel_auto──►│
                                                                                                   ▼
                                                              command_gate ──/cmd_vel──► base_bridge ──serial──► Teensy
 base_bridge ──/odom/wheel, /imu/data──► ekf_local ──► ekf_global ◄── navsat_transform ◄── /gps/fix
 RealSense ──/camera/depth/color/points──► traversability ──/traversability/obstacles──► costmaps, collision_monitor
 RealSense ──colour + aligned depth──► red_zone ──/red_zone/points──► costmaps, collision_monitor
 RealSense ──colour──► object_detector ──/perception/detections──► recon_logger
 RealSense ──colour──► marker_detector ──/perception/marker──► rado_fsm
```
