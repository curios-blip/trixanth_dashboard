// Trixanth base controller - Teensy 4.1
//
// ASSUMPTIONS (change to match the real build):
//  - Skid steer: all 3 left motors share one driver channel command, all 3 right motors share another.
//    Drivers in PWM + DIR mode (e.g. Cytron MDDS30 / MD30C). If each motor has its own driver,
//    drive all three left pins from the same value.
//  - One quadrature encoder per side (front wheels).
//  - BNO085 IMU on I2C (Wire, pins 18/19).
//  - The IRC kill switch (rule 2.2) cuts ALL battery power, so nothing can "sense" it. KILL_SENSE_PIN instead
//    reads the motor-bus contactor/relay (a secondary motor-only stop, see CONNECTIONS.md): HIGH = motor
//    bus dead. The rover then reports kill=1 and the Jetson drops to ESTOP while still logging.
//  - Battery voltage through a divider into BATT_PIN.
//
// Libraries: Encoder (PJRC, bundled with Teensyduino), Adafruit BNO08x.
// Protocol: see src/trixanth_hardware/trixanth_hardware/protocol.py

#include <Encoder.h>
#include <Wire.h>
#include <Adafruit_BNO08x.h>

// ---------- pins ----------
const int L_PWM = 2,  L_DIR = 3;
const int R_PWM = 4,  R_DIR = 5;
Encoder encL(6, 7);
Encoder encR(8, 9);
const int KILL_SENSE_PIN = 10;  // HIGH when the motor-bus contactor is OPEN (aux NC contact to GND, pull-up)
const int BATT_PIN = A0;        // pin 14
const float BATT_DIVIDER = 11.0;  // (R1+R2)/R2, e.g. 100k/10k

// ---------- robot ----------
const float WHEEL_RADIUS = 0.15f;
const float TICKS_PER_REV = 4096.0f;
const float M_PER_TICK = 2.0f * 3.14159265f * WHEEL_RADIUS / TICKS_PER_REV;
const uint32_t CMD_TIMEOUT_MS = 300;

// ---------- PI speed control ----------
const float KP = 180.0f, KI = 600.0f, KFF = 200.0f;  // tune on the stand; KFF = PWM per (m/s)
const int PWM_MAX = 255;
float targetL = 0, targetR = 0, integL = 0, integR = 0;
long prevTicksL = 0, prevTicksR = 0;
uint32_t lastCmdMs = 0, lastCtrlMs = 0, lastEncMs = 0, lastImuMs = 0, lastStatusMs = 0;

Adafruit_BNO08x bno(-1);
sh2_SensorValue_t sv;
float q[4] = {1, 0, 0, 0}, gyro[3] = {0, 0, 0}, accel[3] = {0, 0, 0};
bool imuOk = false;

String rx;

// ---------- protocol ----------
uint8_t checksum(const String &p) {
  uint8_t c = 0;
  for (unsigned i = 0; i < p.length(); i++) c ^= (uint8_t)p[i];
  return c;
}
void sendLine(const String &payload) {
  char cs[3];
  snprintf(cs, sizeof(cs), "%02X", checksum(payload));
  Serial.print(payload);
  Serial.print('*');
  Serial.println(cs);
}
void handleLine(String line) {
  line.trim();
  int star = line.lastIndexOf('*');
  if (star < 0) return;
  String payload = line.substring(0, star);
  String cs = line.substring(star + 1);
  char expect[3];
  snprintf(expect, sizeof(expect), "%02X", checksum(payload));
  if (!cs.equalsIgnoreCase(expect)) return;

  if (payload.startsWith("V,")) {
    int c1 = payload.indexOf(',', 2);
    if (c1 < 0) return;
    targetL = payload.substring(2, c1).toFloat();
    targetR = payload.substring(c1 + 1).toFloat();
    lastCmdMs = millis();
  } else if (payload == "P") {
    lastStatusMs = 0;  // force a status line
  }
}

// ---------- motors ----------
void drive(int pwmPin, int dirPin, float u) {
  int pwm = constrain((int)fabsf(u), 0, PWM_MAX);
  digitalWrite(dirPin, u >= 0 ? HIGH : LOW);
  analogWrite(pwmPin, pwm);
}
bool killed() { return digitalRead(KILL_SENSE_PIN) == HIGH; }

void setup() {
  Serial.begin(115200);
  pinMode(L_DIR, OUTPUT); pinMode(R_DIR, OUTPUT);
  pinMode(KILL_SENSE_PIN, INPUT_PULLUP);
  analogWriteFrequency(L_PWM, 20000);
  analogWriteFrequency(R_PWM, 20000);
  drive(L_PWM, L_DIR, 0); drive(R_PWM, R_DIR, 0);

  Wire.begin();
  imuOk = bno.begin_I2C();
  if (imuOk) {
    bno.enableReport(SH2_ROTATION_VECTOR, 10000);       // 100 Hz
    bno.enableReport(SH2_GYROSCOPE_CALIBRATED, 10000);
    bno.enableReport(SH2_ACCELEROMETER, 10000);
  }
}

void loop() {
  uint32_t now = millis();

  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') { handleLine(rx); rx = ""; }
    else if (rx.length() < 64) rx += c;
    else rx = "";
  }

  // Watchdog: no command -> stop. Kill switch -> stop and clear integrators.
  if (now - lastCmdMs > CMD_TIMEOUT_MS || killed()) {
    targetL = targetR = 0;
  }

  // 100 Hz speed control
  if (now - lastCtrlMs >= 10) {
    float dt = (now - lastCtrlMs) / 1000.0f;
    lastCtrlMs = now;
    long tL = encL.read(), tR = -encR.read();  // right side mirrored
    float vL = (tL - prevTicksL) * M_PER_TICK / dt;
    float vR = (tR - prevTicksR) * M_PER_TICK / dt;
    prevTicksL = tL; prevTicksR = tR;

    if (targetL == 0 && targetR == 0) {
      integL = integR = 0;
      drive(L_PWM, L_DIR, 0); drive(R_PWM, R_DIR, 0);
    } else {
      float eL = targetL - vL, eR = targetR - vR;
      integL = constrain(integL + eL * dt, -0.5f, 0.5f);
      integR = constrain(integR + eR * dt, -0.5f, 0.5f);
      drive(L_PWM, L_DIR, KFF * targetL + KP * eL + KI * integL);
      drive(R_PWM, R_DIR, KFF * targetR + KP * eR + KI * integR);
    }
  }

  // IMU
  if (imuOk && bno.getSensorEvent(&sv)) {
    switch (sv.sensorId) {
      case SH2_ROTATION_VECTOR:
        q[0] = sv.un.rotationVector.real; q[1] = sv.un.rotationVector.i;
        q[2] = sv.un.rotationVector.j;    q[3] = sv.un.rotationVector.k; break;
      case SH2_GYROSCOPE_CALIBRATED:
        gyro[0] = sv.un.gyroscope.x; gyro[1] = sv.un.gyroscope.y; gyro[2] = sv.un.gyroscope.z; break;
      case SH2_ACCELEROMETER:
        accel[0] = sv.un.accelerometer.x; accel[1] = sv.un.accelerometer.y; accel[2] = sv.un.accelerometer.z; break;
    }
  }

  if (now - lastEncMs >= 20) {  // 50 Hz encoders
    lastEncMs = now;
    sendLine("E," + String(now) + "," + String(encL.read()) + "," + String(-encR.read()));
  }
  if (imuOk && now - lastImuMs >= 10) {  // 100 Hz IMU
    lastImuMs = now;
    String s = "I";
    for (int i = 0; i < 4; i++) s += "," + String(q[i], 5);
    for (int i = 0; i < 3; i++) s += "," + String(gyro[i], 4);
    for (int i = 0; i < 3; i++) s += "," + String(accel[i], 3);
    sendLine(s);
  }
  if (now - lastStatusMs >= 500) {  // 2 Hz status
    lastStatusMs = now;
    float v = analogRead(BATT_PIN) * (3.3f / 1023.0f) * BATT_DIVIDER;
    sendLine("S," + String(killed() ? 1 : 0) + "," + String(v, 2));
  }
}
