// Trixanth ABEx science node - ESP32
//
// ASSUMPTIONS (change to match the real build):
//  - DS18B20 soil temperature probe on GPIO 4 (OneWire, 4.7k pull-up to 3.3 V)
//  - BME280 (air temperature, humidity, pressure) on I2C, GPIO 21/22
//  - Analog pH probe board on GPIO 34 (ADC1 only; ADC2 is unusable while Wi-Fi is on)
//  - Capacitive soil moisture sensor on GPIO 35
//  Wi-Fi and Bluetooth stay OFF: the link is USB serial to the Jetson.
//
// Libraries: OneWire, DallasTemperature, Adafruit BME280.
// Output: one JSON line per second at 115200 baud (see sensor_bridge.py).

#include <OneWire.h>
#include <DallasTemperature.h>
#include <Wire.h>
#include <Adafruit_BME280.h>
#include <WiFi.h>

const int SOIL_T_PIN = 4;
const int PH_PIN = 34;
const int MOIST_PIN = 35;

// pH calibration: measure the probe voltage in pH 7 and pH 4 buffers, enter here.
const float PH7_V = 1.50f;
const float PH4_V = 2.03f;
// Moisture calibration: raw ADC in air (dry) and in water (wet).
const int MOIST_DRY = 3300;
const int MOIST_WET = 1300;

OneWire ow(SOIL_T_PIN);
DallasTemperature soilT(&ow);
Adafruit_BME280 bme;
bool bmeOk = false;

float readVolts(int pin, int samples = 20) {
  long sum = 0;
  for (int i = 0; i < samples; i++) { sum += analogReadMilliVolts(pin); delay(2); }
  return sum / (float)samples / 1000.0f;
}

void setup() {
  WiFi.mode(WIFI_OFF);
  btStop();
  Serial.begin(115200);
  soilT.begin();
  Wire.begin(21, 22);
  bmeOk = bme.begin(0x76) || bme.begin(0x77);
}

void loop() {
  soilT.requestTemperatures();
  float soil = soilT.getTempCByIndex(0);

  float phV = readVolts(PH_PIN);
  float slope = (7.0f - 4.0f) / (PH7_V - PH4_V);
  float ph = 7.0f + (phV - PH7_V) * slope;

  int raw = analogRead(MOIST_PIN);
  float moist = constrain(100.0f * (MOIST_DRY - raw) / (float)(MOIST_DRY - MOIST_WET), 0.0f, 100.0f);

  Serial.print("{");
  if (soil > -100) { Serial.print("\"soil_temp_c\":"); Serial.print(soil, 2); Serial.print(","); }
  if (bmeOk) {
    Serial.print("\"air_temp_c\":");   Serial.print(bme.readTemperature(), 2); Serial.print(",");
    Serial.print("\"humidity_pct\":"); Serial.print(bme.readHumidity(), 1);    Serial.print(",");
    Serial.print("\"pressure_pa\":");  Serial.print(bme.readPressure(), 0);    Serial.print(",");
  }
  Serial.print("\"soil_moisture_pct\":"); Serial.print(moist, 1); Serial.print(",");
  Serial.print("\"ph\":"); Serial.print(ph, 2);
  Serial.println("}");

  delay(1000);
}
