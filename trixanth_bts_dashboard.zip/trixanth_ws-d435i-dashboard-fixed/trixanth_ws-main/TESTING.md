# Test plan

Venue testing is not allowed (rule 1.8), so testing climbs four levels: **sim → bench → analogue terrain → timed rehearsal**. Do not move a package up a level until it passes the gate for its level. Record a bag for every run above level 0 (see the end).

## Level 0: build and unit tests (every commit)

```bash
cd ~/trixanth_ws
rosdep install --from-paths src --ignore-src -y
colcon build --symlink-install
colcon test && colcon test-result --verbose
```

Unit tests cover the pure logic that must never regress:

| Test file | What it proves |
| --- | --- |
| `trixanth_hardware/test/test_protocol.py` | Serial lines round-trip; corrupted lines are rejected |
| `trixanth_obstacle_avoidance/test/test_grid.py` | Flat ground and 10° slopes are free; rocks and holes are obstacles |
| `trixanth_red_zone/test/test_segmentation.py` | Sand is not red; red cones are; small specks are ignored; depth back-projection is right |
| `trixanth_perception/test/test_colour.py` | Marker found at the right pixel; no false marker on sand |
| `trixanth_comms/test/test_gate_logic.py` | Kill wins; teleop never drives in AUTONOMOUS; autonomy survives link loss |
| `trixanth_mission/test/test_mission_clock.py` | 7-min abort, exactly-30% stops at 15 min, comms penalty, RADO stage switch, approach stops at the marker |
| `trixanth_science/test/test_pano.py` | Panorama crop is ≥ 1:3; report builds from site logs |

## Level 1: simulation (needs your URDF with the sim block)

```bash
ros2 launch trixanth_bringup sim_rado.launch.py
ros2 run trixanth_comms ground_heartbeat            # second terminal: the "ground station"
rviz2                                               # fixed frame: map; add both costmaps and /red_zone/points
```

| ID | Test | How | Pass |
| --- | --- | --- | --- |
| S1 | TF and topics | `ros2 run tf2_tools view_frames`; `ros2 topic hz /odometry/global /camera/depth/color/points` | `map→odom→base_footprint→base_link→camera_link` single tree; odometry ≥ 25 Hz |
| S2 | Localisation | Teleop a 20 m square back to start (`ros2 service call /set_mode trixanth_interfaces/srv/SetMode "{mode: 1}"`, then `teleop_twist_keyboard` remapped to `/cmd_vel_teleop`) | Closing error < 2 m in `/odometry/global` |
| S3 | GPS goal | `ros2 run trixanth_navigation gps_goal --ros-args -p lat:=12.6610898 -p lon:=77.4496841 -p use_sim_time:=true` | Reaches within 1.5 m, 5 of 5 |
| S4 | Obstacles | Send goals across `ramp_15`, `ramp_32`, `boulder_1`, the plateau's north edge | Crosses the 15° ramp; plans around the 32° ramp, the boulder and the drop, 10 of 10 |
| S5 | Red zones | Goals whose straight line passes `red_cone_1`, `red_cone_2` and the flat `red_patch` | Zero red entries in 20 runs (watch `/red_zone/points` in the costmap) |
| S6 | Full delivery | `ros2 service call /set_mode ... "{mode: 1}"` then `ros2 service call /rado/start_delivery std_srvs/srv/Trigger` | 17 of 20 succeed with no further command; `/rado/status` ends in DONE |
| S7 | Link loss in AUTO | Kill `ground_heartbeat` during NAVIGATE | Delivery still completes; `/trixanth/link_ok` goes false |
| S8 | Command lockout | During AUTO, publish to `/cmd_vel_teleop` | Rover ignores it; `/trixanth/autonomy_violations` counts up |
| S9 | Inaccurate GPS | Shift each delivery in `sim_deliveries.yaml` by 3–5 m | SEARCH finds the marker; ≥ 8 of 10 still succeed |
| S10 | Mission clock | `ros2 service call /mission/start trixanth_interfaces/srv/StartMission "{mission: rado, points_max: 100}"`; log no points | `/mission/alert` warns at 5:00 and aborts at 7:00 |

Gate to Level 2: S1–S10 pass on two separate days.

## Level 2: bench (rover on stands, wheels free)

| ID | Test | How | Pass |
| --- | --- | --- | --- |
| B1 | Teensy link | `ros2 launch trixanth_hardware hardware.launch.py`; `ros2 topic hz /odom/wheel /imu/data` | 50 Hz encoders, 100 Hz IMU, no "Bad fields" warnings |
| B2 | Wheel direction | MANUAL mode, `/cmd_vel_teleop` linear 0.2 | All six wheels turn forward; `/odom/wheel` x increases |
| B3 | Watchdog | Unplug the Teensy USB while wheels turn | Wheels stop within 0.3 s |
| B4 | Motor stop | Open the motor contactor | `/trixanth/kill_switch` true; gate goes ESTOP; refuses AUTONOMOUS |
| B5 | External kill switch | Hit it | Everything loses power, including the Jetson (rule 2.2) |
| B6 | IMU axes | Tilt nose down, roll left, turn left | Pitch +, roll −, yaw + (REP 103). If not, fix mounting or firmware axes |
| B7 | Compute budget | Full `rado.launch.py`; `sudo tegrastats` | CPU < 80%, YOLO ≥ 15 FPS (`ros2 topic hz /perception/detections`), MPPI keeps 20 Hz |
| B8 | Science sensors | `ros2 launch trixanth_hardware hardware.launch.py science:=true`; `ros2 topic echo /abex/ph` | pH within ±0.2 in pH 4 and 7 buffers; DS18B20 matches a reference thermometer ±0.5 °C |
| B9 | Radio | Laptop ↔ rover through the radios at 2 m | Dashboard video + telemetry live; channel switch < 5 s when the channel is jammed |

## Level 3: analogue terrain (sand, gravel, quarry or a construction site)

| ID | Test | How | Pass |
| --- | --- | --- | --- |
| F1 | Odometry calibration | Drive 20 m straight, then 10 turns in place | Tune `ticks_per_rev` until distance error < 3%; tune `track_width` until yaw error < 5% (it ends up larger than the real track on skid steer) |
| F2 | GPS + EKF | Drive a 30 m loop | Closing error < 3 m; `yaw_offset` and declination correct (heading on dashboard matches a phone compass) |
| F3 | Traversability tuning | Drive at real rocks, a ditch and a slope; watch `/traversability/obstacles` | Set `step_max`, `drop_max`, `slope_max_deg` so real hazards mark and loose sand does not |
| F4 | Red in sunlight | Red cones and red cloth at 1–8 m, morning, noon and afternoon; `rqt_image_view /red_zone/mask` | Detected at all distances and times; no sand/brown rock false positives. Tune `s_min`, `hue_low/high` |
| F5 | Delivery accuracy | 10 deliveries with real markers and objects | ≥ 8 placed within 0.5 m of the marker |
| F6 | RF in a crowd | Run B9 at 200–500 m in a crowded RF spot (college fest, mall car park); log spectrum scans | Link holds; auto channel change stays inside the declared list |
| F7 | Perception data | Capture 300+ images of objects on sand and rock, label, train | mAP50 ≥ 0.7 on held-out images. When official object photos arrive, retrain within 48 h |

## Level 4: timed mission rehearsals

Closed tent as the base station, 5 operators, 2 runners, 1 mock judge with a stopwatch and the rulebook.

- Three full 25-minute runs per mission. Mock judge enforces 30-minute early arrival, 8-minute setup, 5-minute pack-up, the 7-minute rule and the 30%-by-15 gate.
- Operator logs points as the judge awards them: `ros2 topic pub --once /mission/score trixanth_interfaces/msg/ScoreEvent "{task: recon_obj1, points: 10}"` (or the dashboard button).
- Team leader announces every AUTONOMOUS entry to the mock judge (driven by `/trixanth/mode_event`).

**Fault drills (run each at least twice):**

| ID | Drill | Pass |
| --- | --- | --- |
| D1 | Cut the link for 60 s during autonomous delivery | Delivery completes |
| D2 | Jam the primary channel with a second radio | Switch to a declared backup channel in < 5 s |
| D3 | Red cones and a red rock placed on the planned path | No entry |
| D4 | Drop GPS offset by 5 m | Marker found by SEARCH; delivery completes |
| D5 | Rover stuck in soft sand | Nav2 recovery frees it, or operators recover without an intervention |
| D6 | Full intervention: operator to intervention circle, repair, return rover to the exact pose, clock running | Under 4 min; the repairing operator does not re-enter the base station |

Gate for the finals: no aborts and no red entries in the last three rehearsals of each mission.

## Recording every run

```bash
ros2 bag record -o ~/bags/$(date +%Y%m%d_%H%M)_<mission>_<run> \
  /tf /tf_static /odometry/local /odometry/global /gps/fix /imu/data /odom/wheel \
  /cmd_vel /cmd_vel_auto /cmd_vel_teleop /trixanth/mode /trixanth/mode_event /trixanth/link_ok \
  /mission/state /mission/alert /rado/status /perception/detections /perception/marker \
  /red_zone/points /traversability/obstacles /local_costmap/costmap
```

Skip raw camera topics unless you are debugging perception; they fill the Jetson's disk quickly. One row per run in the team sheet: date, level, test ID, pass/fail, time, estimated points, failure cause, bag name.
